/*
	Copyright 2008 Huseyin Kozan (posta@huseyinkozan.com.tr)

	This file is part of Medaq.

	Medaq is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Medaq is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with Medaq.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "DeviceSensor.h"
#include <QString>
#include <QStringList>
#include <QByteArray>
#include <QMap>
#include <QMessageBox>

#include <NIDAQmx.h>

DeviceSensor::DeviceSensor(){

}

DeviceSensor::~DeviceSensor(){

}

QStringList DeviceSensor::getDeviceNames(){
	QByteArray ba(1024,0);
    DAQmxGetSysDevNames(ba.data(), 1024);
    QString devices(ba);
	QStringList deviceList = devices.split(",");
	for(int i=0; i<deviceList.size(); ++i){
		deviceList[i] = deviceList[i].trimmed();
	}
	return deviceList;
}

QStringList DeviceSensor::getAIChannelNames(QString deviceName){
	QByteArray ba(1024,0);
	DAQmxGetDevAIPhysicalChans(deviceName.toAscii().constData(), ba.data(), 1024);
	QString channels(ba);
	QStringList channelList = channels.split(",");
	for(int i=0; i<channelList.size(); ++i){
		channelList[i] = channelList[i].trimmed();
	}
	return channelList;
}

QStringList DeviceSensor::getAOChannelNames(QString deviceName){
	QByteArray ba(1024,0);
	DAQmxGetDevAOPhysicalChans(deviceName.toAscii().constData(), ba.data(), 1024);
	QString channels(ba);
	QStringList channelList = channels.split(",");
	for(int i=0; i<channelList.size(); ++i){
		channelList[i] = channelList[i].trimmed();
	}
	return channelList;
}

QStringList DeviceSensor::getDOLines(QString deviceName){
	QByteArray ba(1024,0);
	DAQmxGetDevDOLines(deviceName.toAscii().constData(), ba.data(), 1024);
	QString lines(ba);
	QStringList lineList = lines.split(",");
	for(int i=0; i<lineList.size(); ++i){
		lineList[i] = lineList[i].trimmed();
	}
	return lineList;
}

QStringList DeviceSensor::getAITerminalConfigurations(QString deviceName){
	QStringList conf;
	conf << "Referenced Single-Ended." 
		 << "Non-Referenced Single-Ended." 
		 << "Differential." 
		 << "Pseudodifferential.";
	return conf;
}

bool DeviceSensor::isSimulated(QString deviceName){
	bool32 b;
	DAQmxGetDevIsSimulated(deviceName.toAscii().constData(), &b);
	return b;
}

double DeviceSensor::getDOMaxRate(QString deviceName){
	float64 rate = 0;
	DAQmxGetDevDOMaxRate(deviceName.toAscii().constData(), &rate);
	return rate;
}

double DeviceSensor::getAIMinSampleRate(QString deviceName){
	float64 rate = 0;
	DAQmxGetDevAIMinRate(deviceName.toAscii().constData(), &rate);
	return rate;
}

double DeviceSensor::getAIMaxSampleRate(QString deviceName){
	float64 rate = 0;
	DAQmxGetDevAIMaxSingleChanRate(deviceName.toAscii().constData(), &rate);
	return rate;
}

double DeviceSensor::getAOMinSampleRate(QString deviceName){
	float64 rate = 0;
	DAQmxGetDevAOMinRate(deviceName.toAscii().constData(), &rate);
	return rate;
}

double DeviceSensor::getAOMaxSampleRate(QString deviceName){
	float64 rate = 0;
	DAQmxGetDevAOMaxRate(deviceName.toAscii().constData(), &rate);
	return rate;
}

double DeviceSensor::getAIMinVoltage(QString deviceName){
	float64 marray[100] = {0};
	DAQmxGetDevAIVoltageRngs(deviceName.toAscii().constData(), marray, 100);
	float64 min = 0;
	for (int i=0; i<100; i++)
	{
		if (min > marray[i]) min = marray[i];
	}
	return min;
}

double DeviceSensor::getAIMaxVoltage(QString deviceName){
	float64 marray[100] = {0};
	DAQmxGetDevAIVoltageRngs(deviceName.toAscii().constData(), marray, 100);
	float64 max = 0;
	for (int i=0; i<100; i++)
	{
		if (max < marray[i]) max = marray[i];
	}
	return max;
}

double DeviceSensor::getAOMinVoltage(QString deviceName){
	float64 marray[100] = {0};
	DAQmxGetDevAOVoltageRngs(deviceName.toAscii().constData(), marray, 100);
	float64 min = 0;
	for (int i=0; i<100; i++)
	{
		if (min > marray[i]) min = marray[i];
	}
	return min;
}

double DeviceSensor::getAOMaxVoltage(QString deviceName){
	float64 marray[100] = {0};
	DAQmxGetDevAOVoltageRngs(deviceName.toAscii().constData(), marray, 100);
	float64 max = 0;
	for (int i=0; i<100; i++)
	{
		if (max < marray[i]) max = marray[i];
	}
	return max;
}

QString DeviceSensor::getLongDeviceName(QString deviceName){

	QMap<QString, int> names;
    names.insert("NI PCI-DIO-96",	0x0160	);
    names.insert("NI PCI-MIO-16XE-50",	0x0162	);
    names.insert("NI DAQCard-6036E",	0x0245	);
    names.insert("NI DAQCard-6062E",	0x02C4	);
    names.insert("NI SCXI-1126",	0x0301	);
    names.insert("NI SCXI-1121",	0x0302	);
    names.insert("NI SCXI-1129",	0x0303	);
    names.insert("NI SCXI-1120",	0x0304	);
    names.insert("NI SCXI-1100",	0x0306	);
    names.insert("NI SCXI-1140",	0x0308	);
    names.insert("NI SCXI-1122",	0x030A	);
    names.insert("NI SCXI-1160",	0x030C	);
    names.insert("NI SCXI-1125",	0x030D	);
    names.insert("NI SCXI-1161",	0x030E	);
    names.insert("NI SCXI-1162",	0x0310	);
    names.insert("NI SCXI-1163",	0x0312	);
    names.insert("NI SCXI-1124",	0x0314	);
    names.insert("NI SCXI-1162HV",	0x0318	);
    names.insert("NI SCXI-1163R",	0x031C	);
    names.insert("NI SCXI-1102",	0x031E	);
    names.insert("NI SCXI-1102B",	0x031F	);
    names.insert("NI SCXI-1141",	0x0320	);
    names.insert("NI SCXI-1112",	0x0321	);
    names.insert("NI SCXI-1191",	0x0322	);
    names.insert("NI SCXI-1190",	0x0323	);
    names.insert("NI SCXI-1192",	0x0324	);
    names.insert("NI SCXI-1600",	0x0329	);
    names.insert("NI SCXI-1104",	0x032D	);
    names.insert("NI SCXI-1104C",	0x032F	);
    names.insert("NI SCXI-1531",	0x0330	);
    names.insert("NI SCXI-1540",	0x0331	);
    names.insert("NI SCXI-1530",	0x0332	);
    names.insert("NI SCXI-1102C",	0x033E	);
    names.insert("NI SCXI-1143",	0x0340	);
    names.insert("NI SCXI-1120D",	0x0344	);
    names.insert("NI SCXI-1127",	0x0345	);
    names.insert("NI SCXI-1128",	0x0346	);
    names.insert("NI SCXI-1142",	0x0360	);
    names.insert("NI SCXI-1500",	0x038F	);
    names.insert("NI SCXI-1520",	0x0407	);
    names.insert("NI SCXI-1581",	0x048B	);
    names.insert("NI SCC-A10",	0x04AC	);
    names.insert("NI SCC-CI20",	0x04AD	);
    names.insert("NI SCC-FT01",	0x04AE	);
    names.insert("NI SCC-TC01",	0x04B2	);
    names.insert("NI SCC-TC02",	0x04B3	);
    names.insert("NI SCC-FV01",	0x04B4	);
    names.insert("NI SCC-DI01",	0x04B6	);
    names.insert("NI SCC-DO01",	0x04B7	);
    names.insert("NI SCC-LP01",	0x04B8	);
    names.insert("NI SCC-LP02",	0x04B9	);
    names.insert("NI SCC-LP03",	0x04BA	);
    names.insert("NI SCC-LP04",	0x04BC	);
    names.insert("NI SCC-RTD01",	0x04BD	);
    names.insert("NI SCC-SG01",	0x04BE	);
    names.insert("NI SCC-CO20",	0x04BF	);
    names.insert("NI SCC-AI01",	0x04DA	);
    names.insert("NI SCC-AI02",	0x04DB	);
    names.insert("NI SCC-AI03",	0x04DC	);
    names.insert("NI SCC-AI04",	0x04DD	);
    names.insert("NI SCC-AI05",	0x04DE	);
    names.insert("NI SCC-AI06",	0x04DF	);
    names.insert("NI SCC-AI07",	0x04E0	);
    names.insert("NI SCC-AI13",	0x04E1	);
    names.insert("NI SCC-AI14",	0x04E2	);
    names.insert("NI SCC-SG02",	0x04E3	);
    names.insert("NI SCC-SG03",	0x04E4	);
    names.insert("NI SCC-SG04",	0x04E5	);
    names.insert("NI SCC-SG11",	0x04E6	);
    names.insert("NI SCC-ACC01",	0x04EA	);
    names.insert("NI SCC-RLY01",	0x04F0	);
    names.insert("NI SCC-AO10",	0x04F6	);
    names.insert("NI DAQCard-DIO-24",	0x075C	);
    names.insert("NI DAQCard-6024E",	0x075E	);
    names.insert("NI DAQCard-6715",	0x075F	);
    names.insert("NI PCI-DIO-32HS",	0x1150	);
    names.insert("NI PCI-MIO-16XE-10",	0x1170	);
    names.insert("NI PCI-MIO-16E-1",	0x1180	);
    names.insert("NI PCI-MIO-16E-4",	0x1190	);
    names.insert("NI PXI-6070E",	0x11B0	);
    names.insert("NI PXI-6040E",	0x11C0	);
    names.insert("NI PXI-6030E",	0x11D0	);
    names.insert("NI PCI-6032E",	0x1270	);
    names.insert("NI PCI-6704",	0x1290	);
    names.insert("NI PCI-6534",	0x12B0	);
    names.insert("NI PCI-6602",	0x1310	);
    names.insert("NI PXI-6533",	0x1320	);
    names.insert("NI PCI-6031E",	0x1330	);
    names.insert("NI PCI-6033E",	0x1340	);
    names.insert("NI PCI-6071E",	0x1350	);
    names.insert("NI PXI-6602",	0x1360	);
    names.insert("NI PXI-6508",	0x13C0	);
    names.insert("NI PXI-6534",	0x1490	);
    names.insert("NI PCI-6110",	0x14E0	);
    names.insert("NI PCI-6111",	0x14F0	);
    names.insert("NI PXI-6031E",	0x1580	);
    names.insert("NI PXI-6071E",	0x15B0	);
    names.insert("NI PXI-6509",	0x1710	);
    names.insert("NI PCI-6503",	0x17D0	);
    names.insert("NI PCI-6713",	0x1870	);
    names.insert("NI PCI-6711",	0x1880	);
    names.insert("NI PCI-6052E",	0x18B0	);
    names.insert("NI PXI-6052E",	0x18C0	);
    names.insert("NI PXI-6704",	0x1920	);
    names.insert("NI 6040E",	0x1930	);
    names.insert("NI PCI-6133",	0x1AD0	);
    names.insert("NI PXI-6133",	0x1AE0	);
    names.insert("NI PCI-6624",	0x1E30	);
    names.insert("NI PXI-6624",	0x1E40	);
    names.insert("NI PCI-6733",	0x2410	);
    names.insert("NI PXI-6733",	0x2420	);
    names.insert("NI PCI-6731",	0x2430	);
    names.insert("NI PXI-4200",	0x24B0	);
    names.insert("NI PXI-4472",	0x24F0	);
    names.insert("NI PCI-4472",	0x2510	);
    names.insert("NI PCI-4474",	0x2520	);
    names.insert("NI PCI-6123",	0x27A0	);
    names.insert("NI PXI-6123",	0x27B0	);
    names.insert("NI PCI-6036E",	0x2890	);
    names.insert("NI PXI-4461",	0x28A0	);
    names.insert("NI PCI-6013",	0x28B0	);
    names.insert("NI PCI-6014",	0x28C0	);
    names.insert("NI PCI-6023E",	0x2A60	);
    names.insert("NI PCI-6024E",	0x2A70	);
    names.insert("NI PCI-6025E",	0x2A80	);
    names.insert("NI PXI-6025E",	0x2AB0	);
    names.insert("NI PXI-6527",	0x2B10	);
    names.insert("NI PCI-6527",	0x2B20	);
    names.insert("NI PXI-6713",	0x2B80	);
    names.insert("NI PXI-6711",	0x2B90	);
    names.insert("NI PCI-6601",	0x2C60	);
    names.insert("NI PCI-6035E",	0x2C80	);
    names.insert("NI PCI-6703",	0x2C90	);
    names.insert("NI PCI-6034E",	0x2CA0	);
    names.insert("NI PXI-6608",	0x2CC0	);
    names.insert("NI PXI-6115",	0x2EC0	);
    names.insert("NI PCI-6115",	0x2ED0	);
    names.insert("NI PXI-6120",	0x2EE0	);
    names.insert("NI PCI-6120",	0x2EF0	);
    names.insert("NI PXI-2593",	0x7023	);
    names.insert("NI SCXI-1193",	0x7024	);
    names.insert("NI SCXI-1166",	0x703D	);
    names.insert("NI SCXI-1167",	0x703E	);
    names.insert("NI PXI-2566",	0x703F	);
    names.insert("NI PXI-2567",	0x7040	);
    names.insert("NI SCXI-1130",	0x704B	);
    names.insert("NI PXI-2530",	0x704C	);
    names.insert("NI PXI-4220",	0x704F	);
    names.insert("NI PXI-4204",	0x7050	);
    names.insert("NI PXI-2529",	0x7067	);
    names.insert("NI PCI-6723",	0x7073	);
    names.insert("NI PXI-4462",	0x707E	);
    names.insert("NI PCI-6509",	0x7085	);
    names.insert("NI PXI-6528",	0x7086	);
    names.insert("NI PCI-6515",	0x7087	);
    names.insert("NI PCI-6514",	0x7088	);
    names.insert("NI PXI-2568",	0x708C	);
    names.insert("NI PXI-2569",	0x708D	);
    names.insert("NI SCXI-1169",	0x7090	);
    names.insert("NI SCC-SG24",	0x7099	);
    names.insert("NI USB-9421",	0x709F	);
    names.insert("NI USB-9472",	0x70A1	);
    names.insert("NI USB-9481",	0x70A2	);
    names.insert("NI WLS-9211",	0x70A3738E	);
    names.insert("NI ENET-9211",	0x70A3738F	);
    names.insert("NI USB-9201",	0x70A4	);
    names.insert("NI USB-9221",	0x70A5	);
    names.insert("NI WLS-9215",	0x70A6738E	);
    names.insert("NI ENET-9215",	0x70A6738F	);
    names.insert("NI USB-9263",	0x70A7	);
    names.insert("NI USB-9233",	0x70A8	);
    names.insert("NI PCI-6528",	0x70A9	);
    names.insert("NI PCI-6229",	0x70AA	);
    names.insert("NI PCI-6259",	0x70AB	);
    names.insert("NI PCI-6289",	0x70AC	);
    names.insert("NI PXI-6251",	0x70AD	);
    names.insert("NI PXI-6220",	0x70AE	);
    names.insert("NI PCI-6221",	0x70AF	);
    names.insert("NI PCI-6220",	0x70B0	);
    names.insert("NI PXI-6229",	0x70B1	);
    names.insert("NI PXI-6259",	0x70B2	);
    names.insert("NI PXI-6289",	0x70B3	);
    names.insert("NI PCI-6250",	0x70B4	);
    names.insert("NI PXI-6221",	0x70B5	);
    names.insert("NI PCI-6280",	0x70B6	);
    names.insert("NI PCI-6254",	0x70B7	);
    names.insert("NI PCI-6251",	0x70B8	);
    names.insert("NI PXI-6250",	0x70B9	);
    names.insert("NI PXI-6254",	0x70BA	);
    names.insert("NI PXI-6280",	0x70BB	);
    names.insert("NI PCI-6284",	0x70BC	);
    names.insert("NI PCI-6281",	0x70BD	);
    names.insert("NI PXI-6284",	0x70BE	);
    names.insert("NI PXI-6281",	0x70BF	);
    names.insert("NI PCI-6143",	0x70C0	);
    names.insert("NI PCI-6511",	0x70C3	);
    names.insert("NI PCI-6513",	0x70C8	);
    names.insert("NI PXI-6515",	0x70C9	);
    names.insert("NI PCI-6512",	0x70CC	);
    names.insert("NI PXI-6514",	0x70CD	);
    names.insert("NI PXI-2570",	0x70D0	);
    names.insert("NI PXI-6513",	0x70D1	);
    names.insert("NI PXI-6512",	0x70D2	);
    names.insert("NI PXI-6511",	0x70D3	);
    names.insert("NI PCI-6722",	0x70D4	);
    names.insert("NI PXI-2532",	0x70E1	);
    names.insert("NI PCI-6224",	0x70F2	);
    names.insert("NI PXI-6224",	0x70F3	);
    names.insert("NI DAQPad-6015",	0x70FA	);
    names.insert("NI DAQPad-6016",	0x70FB	);
    names.insert("NI PXI-6723",	0x70FF	);
    names.insert("NI PXI-6722",	0x7100	);
    names.insert("NI SCXI-1521",	0x7103	);
    names.insert("NI PXI-6143",	0x710D	);
    names.insert("NI PCI-6510",	0x7124	);
    names.insert("NI PCI-6516",	0x7125	);
    names.insert("NI PCI-6517",	0x7126	);
    names.insert("NI PCI-6518",	0x7127	);
    names.insert("NI PCI-6519",	0x7128	);
    names.insert("NI USB-9421 (DSUB)",	0x712E	);
    names.insert("NI USB-9472 (DSUB)",	0x7132	);
    names.insert("NI WLS-9215 (BNC)",	0x7135738E	);
    names.insert("NI ENET-9215 (BNC)",	0x7135738F	);
    names.insert("NI PXI-2575",	0x7137	);
    names.insert("NI PXI-2585",	0x713C	);
    names.insert("NI PXI-2586",	0x713D	);
    names.insert("NI SCXI-1175",	0x713F	);
    names.insert("NI PXI-4224",	0x7142	);
    names.insert("NI SCXI-1521B",	0x7143	);
    names.insert("NI PCI-6132",	0x7146	);
    names.insert("NI PXI-6132",	0x7147	);
    names.insert("NI PCI-6122",	0x7148	);
    names.insert("NI PXI-6122",	0x7149	);
    names.insert("NI PXI-2564",	0x7150	);
    names.insert("NI 9221",	0x715F	);
    names.insert("NI 9421",	0x7160	);
    names.insert("NI 9421 (DSUB)",	0x7161	);
    names.insert("NI 9472",	0x7162	);
    names.insert("NI 9472 (DSUB)",	0x7163	);
    names.insert("NI 9481",	0x7164	);
    names.insert("NI 9401",	0x7165	);
    names.insert("NI PCI-6230",	0x716B	);
    names.insert("NI PCI-6225",	0x716C	);
    names.insert("NI PXI-6225",	0x716D	);
    names.insert("NI PCI-4461",	0x716F	);
    names.insert("NI PCI-4462",	0x7170	);
    names.insert("NI PCI-6010",	0x7171	);
    names.insert("NI DAQPad-6015 (Mass Termination)",	0x7172	);
    names.insert("NI DAQPad-6015 (BNC)",	0x7173	);
    names.insert("NI PXI-6230",	0x7177	);
    names.insert("NI USB-6008",	0x717A	);
    names.insert("NI USB-6009",	0x717B	);
    names.insert("NI PCIe-6251",	0x717D	);
    names.insert("NI PCIe-6259",	0x717F	);
    names.insert("NI USB-6501",	0x718A	);
    names.insert("NI PCI-6521",	0x718B	);
    names.insert("NI PXI-6521",	0x718C	);
    names.insert("NI PCI-6154",	0x7191	);
    names.insert("NI USB-9201 (DSUB)",	0x71A1	);
    names.insert("NI USB-9221 (DSUB)",	0x71A2	);
    names.insert("NI PXI-2594",	0x71A5	);
    names.insert("NI SCXI-1194",	0x71A6	);
    names.insert("NI PXI-2595",	0x71A7	);
    names.insert("NI SCXI-1195",	0x71A8	);
    names.insert("NI PXI-2596",	0x71A9	);
    names.insert("NI PXI-2597",	0x71AA	);
    names.insert("NI PXI-2598",	0x71AB	);
    names.insert("NI PXI-2599",	0x71AC	);
    names.insert("NI 9211",	0x71B0	);
    names.insert("NI 9215",	0x71B1	);
    names.insert("NI 9215 (BNC)",	0x71B2	);
    names.insert("NI 9205 (DSUB)",	0x71B3	);
    names.insert("NI 9263",	0x71B4	);
    names.insert("NI PXI-2584",	0x71BB	);
    names.insert("NI PCI-6221 (37-pin)",	0x71BC	);
    names.insert("NI USB-9239",	0x71C2	);
    names.insert("NI USB-9237",	0x71C3	);
    names.insert("NI WLS-9237",	0x71C3738E	);
    names.insert("NI ENET-9237",	0x71C3738F	);
    names.insert("NI PCI-6520",	0x71C5	);
    names.insert("NI PXI-2576",	0x71C6	);
    names.insert("NI USB-9211A",	0x71D9	);
    names.insert("NI USB-9215A",	0x71DA	);
    names.insert("NI USB-9215A (BNC)",	0x71DB	);
    names.insert("NI USB-6525",	0x71DF	);
    names.insert("NI PCI-6255",	0x71E0	);
    names.insert("NI PXI-6255",	0x71E1	);
    names.insert("NI 9233",	0x71E7	);
    names.insert("NI SCXI-1502",	0x71E8	);
    names.insert("NI PCI-6233",	0x7209	);
    names.insert("NI PXI-6233",	0x720A	);
    names.insert("NI PCI-6238",	0x720B	);
    names.insert("NI PXI-6238",	0x720C	);
    names.insert("NI USB-6251",	0x7252	);
    names.insert("NI USB-6259",	0x7253	);
    names.insert("NI 9234",	0x7263	);
    names.insert("NI 9206",	0x7264	);
    names.insert("NI 9205",	0x7265	);
    names.insert("NI SCXI-1503",	0x726A	);
    names.insert("NI SCC-CTR01",	0x726E	);
    names.insert("NI USB-6210",	0x726F	);
    names.insert("NI USB-6211",	0x7270	);
    names.insert("NI USB-6215",	0x7271	);
    names.insert("NI USB-6218",	0x7272	);
    names.insert("NI PXI-4461",	0x7273	);
    names.insert("NI PXI-4462",	0x7274	);
    names.insert("NI PCI-6232",	0x7279	);
    names.insert("NI PXI-6232",	0x727A	);
    names.insert("NI PCI-6239",	0x727B	);
    names.insert("NI PXI-6239",	0x727C	);
    names.insert("NI PCI-6236",	0x7281	);
    names.insert("NI PXI-6236",	0x7282	);
    names.insert("NI PXI-2554",	0x7283	);
    names.insert("NI 9237",	0x7285	);
    names.insert("NI USB-6251 (Mass Termination)",	0x72A0	);
    names.insert("NI USB-6259 (Mass Termination)",	0x72A1	);
    names.insert("NI USB-9234",	0x72B5	);
    names.insert("NI WLS-9234",	0x72B5738E	);
    names.insert("NI ENET-9234",	0x72B5738F	);
    names.insert("NI 9411",	0x72B9	);
    names.insert("NI 9422",	0x72BA	);
    names.insert("NI 9423",	0x72BB	);
    names.insert("NI 9435",	0x72BC	);
    names.insert("NI 9474",	0x72BD	);
    names.insert("NI 9485",	0x72BE	);
    names.insert("NI 9403",	0x72BF	);
    names.insert("NI 9425",	0x72C0	);
    names.insert("NI 9476",	0x72C1	);
    names.insert("NI 9477",	0x72C2	);
    names.insert("NI 9264",	0x72C3	);
    names.insert("NI 9265",	0x72C4	);
    names.insert("NI 9201",	0x72C5	);
    names.insert("NI 9201 (DSUB)",	0x72C6	);
    names.insert("NI 9221 (DSUB)",	0x72C7	);
    names.insert("NI 9203",	0x72C8	);
    names.insert("NI 9217",	0x72C9	);
    names.insert("NI 9219",	0x72CA	);
    names.insert("NI 9239",	0x72CB	);
    names.insert("NI SensorDAQ",	0x72CC	);
    names.insert("NI PXI-2545",	0x72D0	);
    names.insert("NI PXI-2546",	0x72D1	);
    names.insert("NI PXI-2547",	0x72D2	);
    names.insert("NI PXI-2548",	0x72D3	);
    names.insert("NI PXI-2549",	0x72D4	);
    names.insert("NI PXI-2555",	0x72D5	);
    names.insert("NI PXI-2556",	0x72D6	);
    names.insert("NI PXI-2557",	0x72D7	);
    names.insert("NI PXI-2558",	0x72D8	);
    names.insert("NI PXI-2559",	0x72D9	);
    names.insert("NI USB-6221",	0x72DC	);
    names.insert("NI USB-6229",	0x72DE	);
    names.insert("NI PXI-4498",	0x72EF	);
    names.insert("NI PXI-4496",	0x72F0	);
    names.insert("NI USB-6005 VSA",	0x72F3	);
    names.insert("NI 9229",	0x72FA	);
    names.insert("NI USB-9229",	0x72FD	);
    names.insert("NI USB-6509",	0x72FF	);
    names.insert("NI USB-9219",	0x730C	);
    names.insert("NI WLS-9219",	0x730C738E	);
    names.insert("NI ENET-9219",	0x730C738F	);
    names.insert("NI USB-4431",	0x7318	);
    names.insert("NI PXI-2535",	0x731C	);
    names.insert("NI PXI-2536",	0x731D	);
    names.insert("NI PXIe-6124",	0x7322	);
    names.insert("NI PXI-6529",	0x7327	);
    names.insert("NI USB-6255",	0x732D	);
    names.insert("NI USB-6255 (Mass Termination)",	0x732E	);
    names.insert("NI USB-6225",	0x732F	);
    names.insert("NI USB-6225 (Mass Termination)",	0x7330	);
    names.insert("NI PXI-2533",	0x7335	);
    names.insert("NI PXI-2534",	0x7336	);
    names.insert("NI 9402",	0x7337	);
    names.insert("NI USB-6212",	0x7339	);
    names.insert("NI USB-6216",	0x733B	);
    names.insert("NI USB-6281",	0x733F	);
    names.insert("NI USB-6281 (Mass Termination)",	0x7340	);
    names.insert("NI PXI-4461",	0x7342	);
    names.insert("NI USB-6289",	0x7343	);
    names.insert("NI USB-6289 (Mass Termination)",	0x7344	);
    names.insert("NI USB-6221 (BNC)",	0x7345	);
    names.insert("NI USB-6229 (BNC)",	0x7346	);
    names.insert("NI USB-6251 (BNC)",	0x7347	);
    names.insert("NI USB-6259 (BNC)",	0x7348	);
    names.insert("NI PXI-4495",	0x7359	);
    names.insert("NI USB-9239 (BNC)",	0x7367	);
    names.insert("NI USB-9229 (BNC)",	0x7368	);
    names.insert("NI USB-9263 (BNC)",	0x7369	);
    names.insert("NI PXI-4461",	0x7370	);
    names.insert("NI 9229 (BNC)",	0x737A	);
    names.insert("NI 9239 (BNC)",	0x737B	);
    names.insert("NI 9263 (BNC)",	0x737C	);
    names.insert("NI 9235",	0x7381	);
    names.insert("NI 9236",	0x7382	);
    names.insert("NI 9225",	0x7388	);
    names.insert("NI USB-6212 (Mass Termination)",	0x7389	);
    names.insert("NI USB-6216 (Mass Termination)",	0x738A	);
    names.insert("NI PXIe-4498",	0x73A1	);
    names.insert("NI PXIe-4496",	0x73A2	);
    names.insert("NI USB-9213",	0x73A3	);
    names.insert("NI ELVIS II",	0x73A6	);
    names.insert("NI PXIe-2527",	0x73C5	);
    names.insert("NI PXIe-2529",	0x73C6	);
    names.insert("NI PXIe-2530",	0x73C8	);
    names.insert("NI PXIe-2532",	0x73C9	);
    names.insert("NI PXIe-2569",	0x73CA	);
    names.insert("NI PXIe-2575",	0x73CB	);
    names.insert("NI PXIe-2593",	0x73CC	);
    names.insert("NI USB-4432",	0x73D1	);
    names.insert("NI 9213",	0x73E2	);
    names.insert("NI 9426",	0x73E3	);
    names.insert("NI 9475",	0x73E4	);
    names.insert("NI 9478",	0x73E5	);
    names.insert("NI 9237 (DSUB)",	0x73E6	);
    names.insert("NI PXI-2501",	0x9020	);
    names.insert("NI PXI-2503",	0x9030	);
    names.insert("NI PXI-2527",	0x9040	);
    names.insert("NI PXI-2565",	0x9050	);
    names.insert("NI PXI-2590",	0x9060	);
    names.insert("NI PXI-2591",	0x9070	);

	uInt32 productNumber;
	DAQmxGetDevProductNum(deviceName.toAscii().constData(), &productNumber);
	return names.key(productNumber);
}