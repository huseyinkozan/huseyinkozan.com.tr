/*
	Copyright 2008 Huseyin Kozan (posta@huseyinkozan.com.tr)

	This file is part of Medaq.

	Medaq is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Medaq is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with Medaq.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QtGui>
#include <QSettings>
#include "NewSamplingDialog.h"
#include "DeviceSensor.h"

NewSamplingDialog::NewSamplingDialog(QWidget * parent) : 
	QDialog(parent)
	//channelName(""),
	//terminalConfiguration(0),
	//minVoltage(0),
	//maxVoltage(0),
	//visibleDuration(0),
	//samplingRate(0),
	//startRecordImmediately(false)
{
    /*setAttribute(Qt::WA_DeleteOnClose);*/
    setupUi(this);

	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("NewSamplingDialog");
	channelName = settings.value("channelName", QString()).toString();
    terminalConfiguration = settings.value("terminalConfiguration", 0).toInt();
	minVoltage = settings.value("minVoltage", 0.0).toDouble();
	maxVoltage = settings.value("maxVoltage", 0.0).toDouble();
	visibleDuration = settings.value("visibleDuration", 0).toUInt();
	samplingRate = settings.value("samplingRate", 0).toUInt();
	startRecordImmediately = settings.value("startRecordImmediately", 0).toBool();
	settings.endGroup();

	settings.beginGroup("Settings");
	QString currentDevice = settings.value("currentDevice", QString("")).toString();
	settings.endGroup();

	deviceEdit->setText(currentDevice + " : " + DeviceSensor::getLongDeviceName(currentDevice));

	minSpin->setMinimum(DeviceSensor::getAIMinVoltage(currentDevice));
	minSpin->setMaximum(DeviceSensor::getAIMaxVoltage(currentDevice));
	maxSpin->setMinimum(DeviceSensor::getAIMinVoltage(currentDevice));
	maxSpin->setMaximum(DeviceSensor::getAIMaxVoltage(currentDevice));

	rateSpin->setMinimum(DeviceSensor::getAIMinSampleRate(currentDevice));
	rateSpin->setMaximum(DeviceSensor::getAIMaxSampleRate(currentDevice));
	
	// fill channel list and select saved
	channelList = DeviceSensor::getAIChannelNames(currentDevice);
	foreach(QString chan, channelList){
		channelCombo->addItem(chan);
    }
	int count = -1;
	int index = -1;
	foreach(QString chan, channelList){
		count++;
		if(channelName == chan)
			index = count;
    }
	if(index != -1){
		channelCombo->setCurrentIndex(index);
	}

	// fill terminalconf list and select saved
	terminalList = DeviceSensor::getAITerminalConfigurations(currentDevice);
	foreach(QString term, terminalList){
		terminalCombo->addItem(term);
    }
	terminalCombo->setCurrentIndex(terminalConfiguration);

		
	minSpin->setValue(minVoltage);
	maxSpin->setValue(maxVoltage);
	rateSpin->setValue(samplingRate);
	visibleSpin->setValue(visibleDuration);
	startRecordCheck->setChecked(startRecordImmediately);

	connect(buttonBox, SIGNAL(accepted()), this, SLOT(saveValues()));
	
}

void NewSamplingDialog::saveValues()
{
	channelName = channelList.at(channelCombo->currentIndex());
	terminalConfiguration = terminalCombo->currentIndex();
	minVoltage = minSpin->value();
	maxVoltage = maxSpin->value();
	visibleDuration = visibleSpin->value();
	samplingRate = rateSpin->value();
	startRecordImmediately = startRecordCheck->isChecked();

	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("NewSamplingDialog");
	settings.setValue("channelName", channelName);
	settings.setValue("terminalConfiguration", terminalConfiguration);
	settings.setValue("minVoltage", minVoltage);
	settings.setValue("maxVoltage", maxVoltage);
	settings.setValue("visibleDuration", visibleDuration);
	settings.setValue("samplingRate", samplingRate);
	settings.setValue("startRecordImmediately", startRecordImmediately);
	settings.endGroup();
}

