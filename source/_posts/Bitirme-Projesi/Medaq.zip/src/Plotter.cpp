/*
	Copyright 2008 Huseyin Kozan (posta@huseyinkozan.com.tr)

	This file is part of Medaq.

	Medaq is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Medaq is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with Medaq.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <qwt_plot.h>
#include <qwt_plot_curve.h>
#include <qwt_scale_widget.h>
#include <qwt_plot_picker.h>
#include "Plotter.h"
#include "TimeScale.h"
#include <qmath.h>
#include <QSettings>
#include <QDir>
#include <QDebug>
#include <QTime>



Plotter::Plotter(QWidget * parent) :
	QwtPlot(parent), 
	ready(false),
	recordTime(0)
{
	setCanvasBackground(Qt::white);


}


void Plotter::prepareForPlot(unsigned int visibleDuration, unsigned int samplingRate) 
{

	this->visibleDuration = visibleDuration;
	this->samplingRate = samplingRate;

	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("Settings");
		unsigned int maxVisiblePoint	= settings.value("maxVisiblePoint", 1000).toInt();
		plotSplitCount					= settings.value("plotSplitCount", 50).toInt();
	settings.endGroup();

	unsigned int size;
	if ( visibleDuration * samplingRate > maxVisiblePoint )
	{
		size = maxVisiblePoint;
	}
	else
	{
		size = visibleDuration * samplingRate;
	}
	
	plotData.fill(0.0, size);
	plotBottomData.resize(size);

	for(int i=0; i<plotBottomData.size(); ++i){
		plotBottomData[i] = i;
	}

	samplingCurve = new QwtPlotCurve(tr("Sampling"));
	samplingCurve->setPen(QPen(Qt::black));
	samplingCurve->attach(this);
	samplingCurve->setRawData(plotBottomData.data(), plotData.data(), size);

	// time scale
	TimeScaleDraw * tsd = new TimeScaleDraw(QTime(0,0), samplingRate);
	setAxisScaleDraw(QwtPlot::xBottom, tsd );
    setAxisScale(QwtPlot::xBottom, 0, size);
    setAxisLabelRotation(QwtPlot::xBottom, -50.0);
    setAxisLabelAlignment(QwtPlot::xBottom, Qt::AlignLeft | Qt::AlignBottom);
	// To avoid this "jumping canvas" effect, we add a permanent margin.
	QwtScaleWidget *scaleWidget = axisWidget(QwtPlot::xBottom);
    const int fmh = QFontMetrics(scaleWidget->font()).height();
    scaleWidget->setMinBorderDist(0, fmh / 2);

	ready = true;
}


void Plotter::prepareForScroll()
{
	if(!ready)
		return;

	unsigned int size = visibleDuration * samplingRate;
	plotData.fill(0.0, size);
	plotBottomData.resize(size);
	for(int i=0; i<plotBottomData.size(); ++i){
		plotBottomData[i] = i;
	}

	samplingCurve->setRawData(plotBottomData.data(), plotData.data(), size);

	setAxisScale(QwtPlot::xBottom, 0, size);

	QwtPlotPicker * d_picker = new QwtPlotPicker(QwtPlot::xBottom, QwtPlot::yLeft,
		QwtPicker::PointSelection | QwtPicker::DragSelection, 
		QwtPlotPicker::CrossRubberBand, QwtPicker::AlwaysOn, 
		canvas());
	d_picker->setRubberBandPen(QColor(Qt::green));
	d_picker->setRubberBand(QwtPicker::CrossRubberBand);
	d_picker->setTrackerPen(QColor(Qt::blue));



}


void Plotter::plot(double * buff, unsigned int size)
{
	if(!ready)
		return;

	unsigned int plotSize = plotData.size();

	if( size < plotSize ) // size is smaller than plot size
	{
		if((visibleDuration*samplingRate) > plotSize)		// take by jump
		{
			unsigned int stepLength = qFloor((visibleDuration*samplingRate) / plotSize);
			unsigned int newSize = qFloor(size / stepLength);

			memmove(&(plotData.data()[0]), &(plotData.data()[newSize]), (plotSize-newSize) * sizeof(double)); // shift
			memset(&(plotData.data()[(plotSize-newSize)]),0, newSize * sizeof(double)); // clear shifted place
			
			unsigned int plotIndex = plotSize-1;
			for(int j=size-1; j>=0 && plotIndex >= (plotSize-newSize); j-=stepLength)
			{
				plotData[plotIndex] = buff[j];
				plotIndex--;
			}
		}
		else		// take original
		{
			memmove(&(plotData.data()[0]), &(plotData.data()[size]), (plotSize-size) * sizeof(double)); // shift
			memcpy(&(plotData.data()[(plotSize-size)]), &(buff[0]), size * sizeof(double));
		}
	}
	else			// size is bigger than plot size or equal
	{
		if((visibleDuration*samplingRate) > plotSize)		 // take by jump
		{
			unsigned int stepLength = qFloor((visibleDuration*samplingRate) / plotSize);
			unsigned int newSize = qFloor(size / stepLength);

			if(newSize < plotSize)
			{
				memmove(&(plotData.data()[0]), &(plotData.data()[newSize]), (plotSize-newSize) * sizeof(double)); // shift
				memset(&(plotData.data()[(plotSize-newSize)]),0, newSize * sizeof(double)); // clear shifted place
			}
			else
			{
				memset(&(plotData.data()[0]),0, plotSize * sizeof(double)); // clear all
			}

			int plotIndex = plotSize-1;
			for(int j=size-1; j>=0 && plotIndex >= 0; j-=stepLength)
			{
				plotData[plotIndex] = buff[j];
				plotIndex--;
			}
		}
		else		// take original
		{
			memcpy(&(plotData.data()[0]), &(buff[size-plotSize]), plotSize * sizeof(double));
		}
	}
}


void Plotter::recordAndPlot(double * buff, unsigned int size){
	if(!ready)
		return;

	int last = recordData.size();
	recordData.resize(recordData.size()+size); // initialize new emelents 0 by qt
	memcpy(&(recordData.data()[last]), &(buff[0]), size * sizeof(double));

	int sec = qFloor( recordData.size() / samplingRate );
	if( sec >= recordTime )
	{
		recordTime = sec;
		emit recordTimeChanged(recordTime);
	}

	plot(buff, size);
}


void Plotter::scrollTime(int step){
	if( ! ready )
		return;

	int sourceIndex = 0;
	if( recordData.size() <= plotData.size() ) // stopped before signel filled the plot screen
	{
		plotData.fill(0.0, plotData.size());
		memcpy(&(plotData.data()[0]), &(recordData.data()[0]), recordData.size() * sizeof(double));
	}
	else
	{
		if( step > getMaxScrollStep() )		// if step is out of scope return
			return;

		sourceIndex = step*(plotData.size()/plotSplitCount);
		memcpy(&(plotData.data()[0]), &(recordData.data()[sourceIndex]), plotData.size() * sizeof(double));
	}

	unsigned int plotSize = plotBottomData.size();
	double * d = plotBottomData.data();
	QwtValueList vlist_y[3];
	for ( unsigned int i = 0 ; i < plotSize ; ++i )
	{
		register int x = sourceIndex + i; 
		d[i] = x;
		if( 0 == x % samplingRate )
			vlist_y[0] << d[i];
	}
	setAxisScale(QwtPlot::xBottom, plotBottomData[0], plotBottomData[plotSize - 1]);
	QwtScaleDiv scdiv_y(plotBottomData.at(0), plotBottomData.at(plotBottomData.size()-1), vlist_y);
	scdiv_y.setTicks(QwtScaleDiv::MajorTick, vlist_y[0]);
	setAxisScaleDiv(QwtPlot::xBottom, scdiv_y);

	replot();
}


int Plotter::getMaxScrollStep(){
	if(!ready)
		return 0;
	
	if(recordData.size()<=plotData.size())
		return 0;

	int piece = qFloor(plotData.size()/plotSplitCount);
	if(piece<1)
		piece = 1;
	return qFloor( (recordData.size()-plotData.size()) / piece);
}


void Plotter::clearPlotter(){

	ready = false;

	plotData.fill(0.0, plotData.size());
	plotData.clear();
	recordData.clear();

	clear();

	replot();
}



void Plotter::setScale(double min, double max, bool autoScale)
{
	if(autoScale)
	{
		setAxisAutoScale(QwtPlot::yLeft);
	}
	else
	{
		setAxisScale(QwtPlot::yLeft, min, max);
	}
	replot();
}



