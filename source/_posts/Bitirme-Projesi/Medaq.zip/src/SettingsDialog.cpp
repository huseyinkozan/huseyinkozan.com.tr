/*
	Copyright 2008 Huseyin Kozan (posta@huseyinkozan.com.tr)

	This file is part of Medaq.

	Medaq is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Medaq is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with Medaq.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QtGui>
#include <QString>
#include <QStringList>
#include "SettingsDialog.h"
#include "DeviceSensor.h"

SettingsDialog::SettingsDialog(QWidget * parent) : QDialog(parent)
{
    setAttribute(Qt::WA_DeleteOnClose);
    setupUi(this);

	deviceCombo->clear();
	deviceList = DeviceSensor::getDeviceNames();
	
	foreach(QString dev, deviceList){
		deviceCombo->addItem(dev + " : " + DeviceSensor::getLongDeviceName(dev));
    }
	
	connect(deviceCombo,SIGNAL(currentIndexChanged(int)), this, SLOT(deviceComboChanged(int)));
	connect(analogOutCombo,SIGNAL(currentIndexChanged(int)), this, SLOT(analogOutComboChanged(int)));
	connect(digitalOutCombo,SIGNAL(currentIndexChanged(int)), this, SLOT(digitalOutComboChanged(int)));
	connect(saveButton,SIGNAL(clicked()), this, SLOT(saveButtonClicked()));
	connect(revertButton,SIGNAL(clicked()), this, SLOT(revertButtonClicked()));
	connect(closeButton,SIGNAL(clicked()), this, SLOT(close()));
	
	deviceComboChanged(0);
	revertButtonClicked();

}

void SettingsDialog::deviceComboChanged(int index){
	if(index < deviceList.size())
	{
		selectedDevice = deviceList.at(index);
	
		if( ! selectedDevice.isEmpty())
		{
			analogOutCombo->clear();
			channelList = DeviceSensor::getAOChannelNames(selectedDevice);
			foreach(QString chan, channelList){
				analogOutCombo->addItem(chan);
			}

			digitalOutCombo->clear();
			lineList = DeviceSensor::getDOLines(selectedDevice);
			foreach(QString line, lineList){
				digitalOutCombo->addItem(line);
			}
		}
	}
}


void SettingsDialog::analogOutComboChanged(int index){
	if(index < channelList.size() && index >= 0 )
		selectedAOChannel = channelList.at(index);
}


void SettingsDialog::digitalOutComboChanged(int index){
	if(index < lineList.size() && index >= 0 )
		selectedDOLine = lineList.at(index);
}


void SettingsDialog::saveButtonClicked(){

	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("Settings");
	settings.setValue("currentDevice", deviceList.at(deviceCombo->currentIndex()));
	settings.setValue("currentAOChannel", channelList.at(analogOutCombo->currentIndex()));
	settings.setValue("currentDOLine", lineList.at(digitalOutCombo->currentIndex()));
	settings.setValue("maxVisiblePoint", maxVisiblePointSpin->value());
	settings.setValue("plotSplitCount", plotSplitCountSpin->value());
	settings.setValue("fifoSize", fifoSizeSpin->value());
	settings.setValue("refreshRate", refreshRateSpin->value());
	settings.setValue("analogOutStep", analogOutStepSpin->value());
	settings.endGroup();

}

void SettingsDialog::revertButtonClicked(){

	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("Settings");
	QString currentDevice = settings.value("currentDevice", QString("")).toString();
	QString currentAOChannel = settings.value("currentAOChannel", QString("")).toString();
	QString currentDOLine = settings.value("currentDOLine", QString("")).toString();
	unsigned int maxVisiblePoint = settings.value("maxVisiblePoint", 1000).toUInt();
	unsigned int plotSplitCount = settings.value("plotSplitCount", 50).toUInt();
	unsigned int fifoSize = settings.value("fifoSize", 1000000).toUInt();
	unsigned int refreshRate = settings.value("refreshRate", 20).toUInt();
	double analogOutStep = settings.value("analogOutStep", 0.1).toDouble();
	settings.endGroup();

	// for device combo
	int count = -1;
	int index = -1;
	foreach(QString dev, deviceList){
		count++;
		if(currentDevice == dev)
			index = count;
    }
	if(index != -1){
		deviceCombo->setCurrentIndex(index);
	}

	// for channel combo
	count = -1;
	index = -1;
	foreach(QString chan, channelList){
		count++;
		if(currentAOChannel == chan)
			index = count;
    }
	if(index != -1){
		analogOutCombo->setCurrentIndex(index);
	}

	// for line combo
	count = -1;
	index = -1;
	foreach(QString line, lineList){
		count++;
		if(currentDOLine == line)
			index = count;
    }
	if(index != -1){
		digitalOutCombo->setCurrentIndex(index);
	}

	maxVisiblePointSpin->setValue(maxVisiblePoint);
	plotSplitCountSpin->setValue(plotSplitCount);
	fifoSizeSpin->setValue(fifoSize);
	refreshRateSpin->setValue(refreshRate);
	analogOutStepSpin->setValue(analogOutStep);

}
