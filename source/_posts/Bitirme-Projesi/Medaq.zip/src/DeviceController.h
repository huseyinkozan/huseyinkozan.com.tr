/*
	Copyright 2008 Huseyin Kozan (posta@huseyinkozan.com.tr)

	This file is part of Medaq.

	Medaq is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Medaq is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with Medaq.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DEVICECONTROLLER_H
#define DEVICECONTROLLER_H

#include <QObject>
#include <NIDAQmx.h>

#include <QVector>
QT_BEGIN_NAMESPACE
class QTimer;
QT_END_NAMESPACE


class Plotter;

class DeviceController : public QObject
{
    Q_OBJECT

public:
    DeviceController(Plotter * plotter);
	virtual ~DeviceController();

	QString getLastError(){ return lastError; }
	int		getState(){ return state; }
	bool newSampling( QString channelName, int terminalConfiguration, 
						double minVoltage, double maxVoltage, 
						unsigned int visibleDuration, unsigned int samplingRate, 
						bool startRecordImmediately = false );
	static int32 CVICALLBACK callback_Wrapper( TaskHandle taskHandle, 
												int32 everyNsamplesEventType, 
												uInt32 nSamples, void *callbackData);
	int32 CVICALLBACK callback( TaskHandle taskHandle, 
								int32 everyNsamplesEventType, 
								uInt32 nSamples, void *callbackData);
	bool startAnalogOut(double value);
	bool stopAnalogOut();
	bool updateAnalogOut(double value);
	bool startDigitalOut(int frequency);
	bool stopDigitalOut();
	bool updateDigitalOut(int frequency);

signals:
	void stateChanged(int state);
	void logMessage(QString message);

public slots:
	void timerFunction();
	void startRecording(); // to recording
	void pauseRecording(); // to plotting
	void stopRecording(); // to scrolling
	void clearSampling(); // to waiting	
	void stopSampling();

public:
	enum State {NoDevice, Waiting, Plotting, Recording, Scrolling, Paused} state;

private:
	void saveLastError(QString errorPrefix);

private:
	QVector<double>	fifo;
	unsigned int	fifo_r;
	unsigned int	fifo_w;
	unsigned int	fifo_size;
	volatile bool	overflow;
	QAtomicInt		fifo_count;

	QString			lastError;
	TaskHandle		taskHandle;
	TaskHandle		taskHandleAnalogOut;
	TaskHandle		taskHandleDigitalOut;
	unsigned int	refreshRate;
	QTimer			* timer;
	Plotter			* plotter;

};

#endif
