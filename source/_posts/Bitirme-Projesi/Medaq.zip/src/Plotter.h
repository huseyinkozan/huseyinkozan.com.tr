/*
	Copyright 2008 Huseyin Kozan (posta@huseyinkozan.com.tr)

	This file is part of Medaq.

	Medaq is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Medaq is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with Medaq.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef PLOTTER_H
#define PLOTTER_H

#include <qwt_plot.h>

class QwtPlotCurve;
class QwtPlotItem;

class Plotter : public QwtPlot
{
    Q_OBJECT

public:
    Plotter(QWidget * parent = 0);
	~Plotter()
	{
	}

	void prepareForPlot(unsigned int visibleDuration, unsigned int sampingRate);
	void prepareForScroll();
	void plot(double * buff, unsigned int size);
	void recordAndPlot(double * buff, unsigned int size);
	int getMaxScrollStep();
	void setScale(double min, double max, bool autoScale = false);
	unsigned int getVisibleDuration() { return visibleDuration; }
	unsigned int getSamplingRate() {return samplingRate; }

signals:
	void recordTimeChanged(int);

public slots:
	void scrollTime(int step);
	void clearPlotter();

public:
	QVector<double> recordData;
	
private:
	QVector<double> plotData, plotBottomData;

	QwtPlotCurve * samplingCurve;

	unsigned int visibleDuration;
	unsigned int samplingRate;
	unsigned int plotSplitCount;
	bool		ready;
	int			recordTime;
	
};

#endif
