/*
	Copyright 2008 Huseyin Kozan (posta@huseyinkozan.com.tr)

	This file is part of Medaq.

	Medaq is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Medaq is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with Medaq.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QtGui>
#include <QString>
#include <QStringList>
#include "InfoDialog.h"
#include "DeviceSensor.h"

InfoDialog::InfoDialog(QWidget * parent) : QDialog(parent)
{
    setAttribute(Qt::WA_DeleteOnClose);
    setupUi(this);

	deviceCombo->clear();
	deviceList = DeviceSensor::getDeviceNames();
	
	foreach(QString dev, deviceList){
		deviceCombo->addItem(DeviceSensor::getLongDeviceName(dev) + " : " + dev);
    }
	
	connect(deviceCombo,SIGNAL(currentIndexChanged(int)), this, SLOT(deviceComboChanged(int)));
	
	deviceComboChanged(0);
}

void InfoDialog::deviceComboChanged(int index){
	QString text;
	QStringList strList;

	QString deviceName = DeviceSensor::getLongDeviceName(deviceList.at(index));
	
	text += "<h2>" + deviceName + " : " + deviceList.at(index) + "</h2>";
	if(DeviceSensor::isSimulated(deviceList.at(index))){
		text += tr("<p><strong>Simulated Device</strong><br>Note that; some values may not consistent !</p>") + "<br>";
	}
	text += tr("<strong>Sample Rates :</strong>") + "<br>";
	text += tr("Analog Input Min : ");
	text += QString::number(DeviceSensor::getAIMinSampleRate(deviceList.at(index))) + "<br>";
	text += tr("Analog Input Max : ");
	text += QString::number(DeviceSensor::getAIMaxSampleRate(deviceList.at(index))) + "<br>";
	text += tr("Analog Output Min : "); 
	text += QString::number(DeviceSensor::getAOMinSampleRate(deviceList.at(index))) + "<br>";
	text += tr("Analog Output Max : "); 
	text += QString::number(DeviceSensor::getAOMaxSampleRate(deviceList.at(index))) + "<br>";
	text += tr("Digital Output Max : "); 
	text += QString::number(DeviceSensor::getDOMaxRate(deviceList.at(index))) + "<br>";

	text += tr("<strong>Voltage Ranges :</strong>") + "<br>";
	text += tr("Analog Input Min : ");
	text += QString::number(DeviceSensor::getAIMinVoltage(deviceList.at(index))) + "<br>";
	text += tr("Analog Input Max : ");
	text += QString::number(DeviceSensor::getAIMaxVoltage(deviceList.at(index))) + "<br>";
	text += tr("Analog Output Min : "); 
	text += QString::number(DeviceSensor::getAOMinVoltage(deviceList.at(index))) + "<br>";
	text += tr("Analog Output Max : "); 
	text += QString::number(DeviceSensor::getAOMaxVoltage(deviceList.at(index))) + "<br>";
	
	//text += tr("<strong>Terminal Configurations :</strong>") + "<br>";
	//strList = DeviceSensor::getAITerminalConfigurations(deviceList.at(index));
	//foreach(QString str, strList){
	//	text += str + "<br>";
	//}
	strList.clear();
	text += tr("<strong>Analog Input Channels :</strong>") + "<br>";
	strList = DeviceSensor::getAIChannelNames(deviceList.at(index));
	foreach(QString str, strList){
		text += str + "<br>";
	}
	strList.clear();
	text += tr("<strong>Analog Output Channels :</strong>") + "<br>";
	strList = DeviceSensor::getAOChannelNames(deviceList.at(index));
	foreach(QString str, strList){
		text += str + "<br>";
	}
	strList.clear();
	text += tr("<strong>Digital Output Lines :</strong>") + "<br>";
	strList = DeviceSensor::getDOLines(deviceList.at(index));
	foreach(QString str, strList){
		text += str + "<br>";
	}

	infoEdit->setText(text);
}
