/*
	Copyright 2008 Huseyin Kozan (posta@huseyinkozan.com.tr)

	This file is part of Medaq.

	Medaq is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Medaq is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with Medaq.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DEVICESENSOR_H
#define DEVICESENSOR_H

#include <QObject>

#include <NIDAQmx.h>

class QString;
class QStringList;

class DeviceSensor : public QObject
{
    Q_OBJECT

public:
    DeviceSensor();
	virtual ~DeviceSensor();

	static QStringList	getDeviceNames(void);
	static QString		getLongDeviceName(QString deviceName);

	static QStringList	getAIChannelNames(QString deviceName);
	static QStringList	getAOChannelNames(QString deviceName);
	static QStringList	getDOLines(QString deviceName);

	static QStringList	getAITerminalConfigurations(QString deviceName);
	
	static bool			isSimulated(QString deviceName);
	
	static double		getAIMinSampleRate(QString deviceName);
	static double		getAIMaxSampleRate(QString deviceName);
	static double		getAOMinSampleRate(QString deviceName);
	static double		getAOMaxSampleRate(QString deviceName);
	static double		getDOMaxRate(QString deviceName);

	static double		getAIMinVoltage(QString deviceName);
	static double		getAIMaxVoltage(QString deviceName);
	static double		getAOMinVoltage(QString deviceName);
	static double		getAOMaxVoltage(QString deviceName);

	enum			TerminalConfigurations {
						AIDefault = DAQmx_Val_Cfg_Default,
						AIReferenced = DAQmx_Val_RSE,
						AINonReferenced = DAQmx_Val_NRSE,
						AIDifferential = DAQmx_Val_Diff,
						AIPseudoDifferential = DAQmx_Val_PseudoDiff,
						AOReferenced = DAQmx_Val_RSE,
						AODifferential = DAQmx_Val_Diff,
						AOPseudoDifferential = DAQmx_Val_PseudoDiff
					};
};

#endif
