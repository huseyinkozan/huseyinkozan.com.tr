/*
	Copyright 2008 Huseyin Kozan (posta@huseyinkozan.com.tr)

	This file is part of Medaq.

	Medaq is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Medaq is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with Medaq.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "DeviceController.h"

#include <NIDAQmx.h>

#include <QVector>
#include <QSettings>
#include <QDir>
#include <QDebug>
#include "Plotter.h"
#include <QTimer>
#include "DeviceSensor.h"


DeviceController::DeviceController(Plotter * plotter) : 
	taskHandle( NULL ),
	taskHandleAnalogOut( NULL ),
	taskHandleDigitalOut( NULL ),
	fifo_r(0),
	fifo_w(0),
	overflow(false),
	fifo_count(0),
	plotter(plotter),
	state(Waiting)
{
	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("Settings");
	QString currentDevice = settings.value("currentDevice", QString("")).toString();
	fifo_size = settings.value("fifoSize", 1000000).toUInt();
	refreshRate = settings.value("refreshRate", 20).toUInt();
	settings.endGroup();

	fifo.resize(fifo_size);

	if(currentDevice.isEmpty())
		state = NoDevice;
	emit stateChanged(state);

	timer = new QTimer(this);
	connect(timer, SIGNAL(timeout()), this, SLOT(timerFunction()));

}



DeviceController::~DeviceController()
{
	clearSampling();
	stopAnalogOut();
	stopDigitalOut();
}



bool DeviceController::newSampling( QString channelName, int terminalConfiguration, 
						double minVoltage, double maxVoltage, 
						unsigned int visibleDuration, unsigned int samplingRate, 
						bool startRecordImmediately )
{
	if( state == NoDevice )
	{
		lastError = tr("No device");
		emit logMessage(lastError);
		return false;
	}

	if( state == Plotting || state == Recording )
	{
		lastError = tr("A sampling is already running. First stop sampling than retry again.");
		emit logMessage(lastError);
		return false;
	}

	if( 0 != DAQmxCreateTask( "", &taskHandle) )
								{ saveLastError(tr("While creating the analog in task:\n")); return false; }

	if( 0 != DAQmxCreateAIVoltageChan( taskHandle, channelName.toAscii().constData(), "", 
										terminalConfiguration, minVoltage, maxVoltage, DAQmx_Val_Volts, NULL ) )
								{ saveLastError(tr("While creating the analog in voltage channel:\n")); return false; }

	if( 0 != DAQmxCfgSampClkTiming( taskHandle, NULL /* OnboardClock */, samplingRate /* per second per channel */,
									DAQmx_Val_Rising, DAQmx_Val_ContSamps, fifo_size /* buffer size */ ) )
								{ saveLastError(tr("While configuring the clock timing:\n")); return false; }

	if( 0 != DAQmxRegisterEveryNSamplesEvent( taskHandle, DAQmx_Val_Acquired_Into_Buffer /* for input */,
												samplingRate/refreshRate /* nSamples */, 0, &callback_Wrapper,
												reinterpret_cast<void*>(this) ) )
								{ saveLastError(tr("While registering the callback function:\n")); return false; }

	if( 0 != DAQmxStartTask( taskHandle ) )
								{ saveLastError(tr("While starting the analog in task:\n")); return false; }

	
	plotter->prepareForPlot(visibleDuration, samplingRate);

	if( startRecordImmediately )
	{
		startRecording();
	}
	else
	{
		state = Plotting;
		emit stateChanged(state);
	}

	timer->start(1000/refreshRate);

	return true;
}



/* static wrapper function be able to reach to the class members */
int32 CVICALLBACK DeviceController::callback_Wrapper( TaskHandle taskHandle, 
														   int32 everyNsamplesEventType, 
														   uInt32 nSamples, void *callbackData)
{
	DeviceController * dc = reinterpret_cast<DeviceController * >(callbackData);
    dc->callback( taskHandle,  everyNsamplesEventType,  nSamples, NULL);
    return 0;
}


int32 CVICALLBACK DeviceController::callback( TaskHandle taskHandle, 
											 int32 everyNsamplesEventType, 
											 uInt32 nSamples, void *callbackData)
{
	Q_UNUSED(callbackData)
	Q_UNUSED(everyNsamplesEventType)
	/*
        The array to read samples into, organized according to fillMode.
            DAQmx_Val_GroupByChannel = Group by channel (non-interleaved)
                nSamples from channel 1, than nSamples from channel 2, ...
            DAQmx_Val_GroupByScanNumber   Group by scan number (interleaved) 
                1 sample from channel 1, than 1 sample from channel 2, ...
        
        ! nSamples for each channel => channel count x nSamples = buffer size

		got only one channel
    */
	int32 read = 0;
	double * buff = new double[nSamples];

	if( 0 != DAQmxReadAnalogF64( taskHandle, DAQmx_Val_Auto /* read all available sample */,
									DAQmx_Val_WaitInfinitely, DAQmx_Val_GroupByScanNumber, 
									buff /* read array */, nSamples /* arraySizeInSamps */,
									&read, NULL ) )
    {
        saveLastError(tr("While reading the sampling values:\n"));
		return false;
    }

	if( ( fifo_count + nSamples ) > fifo_size )
	{
		overflow = true;
		qDebug() << "overflow in callback";
	}
	else
	{
		if( fifo_w + nSamples < fifo_size )
		{
			memcpy(&(fifo.data()[fifo_w]), buff, nSamples*sizeof(double));
			fifo_w += nSamples;
		}
		else
		{
			unsigned int first = fifo_size - fifo_w;
			unsigned int second = nSamples - first;
			memcpy(&(fifo.data()[fifo_w]), &(buff[0]), first*sizeof(double));
			memcpy(&(fifo.data()[0]), &(buff[first]), second*sizeof(double));
			fifo_w = second;
		}
		fifo_count.fetchAndAddOrdered(nSamples);
	}

	delete [] buff;

	return 0;
}


void DeviceController::saveLastError(QString errorPrefix)
{
	char errBuff[2048]={'\0'};
	lastError.clear();
	DAQmxGetExtendedErrorInfo(errBuff,2048);
	lastError = QString("<p><font color='#FF0000'>") +  errorPrefix + QString("</p></font>") + QString::fromAscii(errBuff);
	emit logMessage(lastError);
}


void DeviceController::timerFunction()
{
	if( overflow )
	{
		fifo_r = fifo_w;
		overflow = false;
		fifo_count.fetchAndStoreOrdered(0);
		qDebug() << "overflow occured";
		return;
	}
	
	if( state == Waiting || state == Scrolling )
	{
		qDebug() << "Entered timer fnc while state is waiting or scrolling.";
		if(fifo_count > 0)
		{
			fifo_r = fifo_w;
			fifo_count.fetchAndStoreOrdered(0);
		}
		return;
	}

	// get data from fifo
	unsigned int count = fifo_count;

	if(count == 0)
		return;

	double * buff = new double[count];

	if( fifo_r + count < fifo_size )
	{
		memcpy(&(buff[0]), &(fifo.data()[fifo_r]), count*sizeof(double));
		fifo_r += count;
	}
	else
	{
		unsigned int first = fifo_size - fifo_r;
		unsigned int second = count - first;
		memcpy(&(buff[0]), &(fifo.data()[fifo_r]), first*sizeof(double));
		memcpy(&(buff[first]), &(fifo.data()[0]), second*sizeof(double));
		fifo_r = second;
	}
	fifo_count.fetchAndAddOrdered(-count);

	// pump data to either plot or record

	if( state == Plotting )
	{
		plotter->plot(buff, count);
		plotter->replot();
	}
	else if( state == Recording )
	{
		plotter->recordAndPlot(buff, count);
		plotter->replot();
	}

	delete [] buff;
}


void DeviceController::startRecording()
{
	if( state == NoDevice )
	{
		lastError = tr("No device");
		emit logMessage(lastError);
		return;
	}

	state = Recording;
	emit stateChanged(state);
}


void DeviceController::pauseRecording()
{
	state = Paused;
	emit stateChanged(state);
}


void DeviceController::stopRecording()
{
	if(timer->isActive())
		timer->stop();

	state = Scrolling;
	emit stateChanged(state);
}

void DeviceController::stopSampling()
{
	if(timer->isActive())
		timer->stop();

	if( 0 != DAQmxClearTask(taskHandle))
			{ saveLastError(tr("While clearing the analog out task:\n")); }
}

void DeviceController::clearSampling()
{
	if(timer->isActive())
		timer->stop();

	if( 0 != DAQmxClearTask(taskHandle))
			{ saveLastError(tr("While clearing the analog out task:\n")); }

	// clear buffer
	fifo_w = fifo_r = 0;
	fifo_count = 0;
	overflow = false;

	state = Waiting;
	emit stateChanged(state);
}


bool DeviceController::startAnalogOut(double value){

	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("Settings");
	QString currentDevice = settings.value("currentDevice", QString("")).toString();
	QString currentAOChannel = settings.value("currentAOChannel", QString("")).toString();
	settings.endGroup();


	if( 0 != DAQmxCreateTask( "", &taskHandleAnalogOut) )
								{ saveLastError(tr("While creating the analog out task:\n")); return false; }

	if( 0 != DAQmxCreateAOVoltageChan( taskHandleAnalogOut, 
										currentAOChannel.toAscii().constData(), 
										"", 
										DeviceSensor::getAOMinVoltage(currentDevice), 
										DeviceSensor::getAOMaxVoltage(currentDevice), 
										DAQmx_Val_Volts, 
										NULL ) )
								{ saveLastError(tr("While creating the analog out voltage channel:\n")); return false; }
	if( 0 != DAQmxStartTask( taskHandleAnalogOut ) )
								{ saveLastError(tr("While starting the analog out task:\n")); return false; }

	updateAnalogOut(value);
	
	return true;
}


bool DeviceController::stopAnalogOut(){
	if(taskHandleAnalogOut)
	{
		if( 0 != DAQmxClearTask(taskHandleAnalogOut))
			{ saveLastError(tr("While clearing the analog out task:\n")); return false; }
		return true;
	}
	return false;
}


bool DeviceController::updateAnalogOut(double value){
	if(taskHandleAnalogOut)
	{
		float64 data[1] = {0.0};
		data[0] = value;
		if( 0 != DAQmxWriteAnalogF64(taskHandleAnalogOut,1,1,2.0,DAQmx_Val_GroupByChannel,data,NULL,NULL))
								{ saveLastError(tr("While writing the analog out value:\n")); return false; }
		return true;
	}
	return false;
}




bool DeviceController::startDigitalOut(int frequency){

	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("Settings");
	QString currentDevice = settings.value("currentDevice", QString("")).toString();
	QString currentDigitalLine = settings.value("currentDigitalLine", QString("")).toString();
	settings.endGroup();


	if( 0 != DAQmxCreateTask( "", &taskHandleDigitalOut) )
								{ saveLastError(tr("While creating the digital out task:\n")); return false; }

	if( 0 != DAQmxCreateDOChan( taskHandleDigitalOut, currentDigitalLine.toAscii().constData(), "", DAQmx_Val_ChanForAllLines ) )
								{ saveLastError(tr("While creating the digital out line:\n")); return false; }
	if( 0 != DAQmxCfgSampClkTiming( taskHandleDigitalOut, NULL, frequency, DAQmx_Val_Rising, DAQmx_Val_ContSamps, 2 ) )
								{ saveLastError(tr("While configuring the digital out clock timing:\n")); return false; }
	if( 0 != DAQmxStartTask( taskHandleDigitalOut ) )
								{ saveLastError(tr("While starting the digital out task:\n")); return false; }

	updateDigitalOut(frequency);
	
	return true;
}


bool DeviceController::stopDigitalOut(){
	if(taskHandleDigitalOut)
	{
		if( 0 != DAQmxClearTask(taskHandleDigitalOut))
			{ saveLastError(tr("While clearing the digital out task:\n")); return false; }
		return true;
	}
	return false;
}


bool DeviceController::updateDigitalOut(int frequency){
	if(taskHandleDigitalOut)
	{
		uInt8 data[2] = {0x00, 0x01};
		if( 0 != DAQmxCfgSampClkTiming( taskHandleDigitalOut, NULL, frequency, DAQmx_Val_Rising, DAQmx_Val_ContSamps, 2 ) )
								{ saveLastError(tr("While updating the configuration of digital out clock timing:\n")); return false; }
		if( 0 != DAQmxWriteDigitalLines(taskHandleDigitalOut,2,1,2.0,DAQmx_Val_GroupByChannel,data,NULL,NULL))
								{ saveLastError(tr("While writing the digital out value:\n")); return false; }
		return true;
	}
	return false;
}


