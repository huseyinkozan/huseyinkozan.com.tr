/*
	Copyright 2008 Huseyin Kozan (posta@huseyinkozan.com.tr)

	This file is part of Medaq.

	Medaq is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Medaq is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with Medaq.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QtGui>
#include <QStatusBar>
#include "MainWindow.h"
#include "InfoDialog.h"
#include "SettingsDialog.h"
#include "DeviceController.h"
#include "DeviceSensor.h"
#include "NewSamplingDialog.h"
#include <qwt_plot.h>
#include <qwt_plot_curve.h>
#include "fftw3.h"
#include <QVector>
#include "math.h"
#include "TimeScale.h"
#include <qwt_scale_widget.h>
#include <qwt_plot_picker.h>


MainWindow::MainWindow(){

    setupUi(this);

	
	QFile file(QDir::currentPath() + "/pagefold.qss");
    if(file.open(QFile::ReadOnly))
	{
		QApplication::setStyle(QStyleFactory::create("Plastique"));
		QString styleSheet = QLatin1String(file.readAll());
		qApp->setStyleSheet(styleSheet);
	}

    connections();
    readSettings();
    
}


void MainWindow::connections(){

	menuView->insertAction(actionStatusBar, parametersDock->toggleViewAction());
	menuHelp->addAction(QWhatsThis::createAction());
	
	samplingRateLabel = new QLabel;
	samplingRateLabel->setFrameStyle(QFrame::StyledPanel | QFrame::Sunken);
	statusBar()->insertPermanentWidget(0, samplingRateLabel);

	visibleDurationLabel = new QLabel;
	visibleDurationLabel->setFrameStyle(QFrame::StyledPanel | QFrame::Sunken);
	statusBar()->insertPermanentWidget(0, visibleDurationLabel);
	
	dc = new DeviceController(plotter);

	// device controller
	connect(dc, SIGNAL(stateChanged(int)), this, SLOT(handleStateChanges(int)));
	connect(dc, SIGNAL(logMessage(QString)), this, SLOT(handleLogMessages(QString)));
	
	// button
	connect(recordButton, SIGNAL(clicked()), dc, SLOT(startRecording()));
	connect(pauseButton, SIGNAL(clicked()), dc, SLOT(pauseRecording()));
	connect(stopButton, SIGNAL(clicked()), dc, SLOT(stopRecording()));
	connect(clearButton, SIGNAL(clicked()), dc, SLOT(clearSampling()));
	connect(clearButton, SIGNAL(clicked()), samplingRateLabel, SLOT(clear()));
	connect(clearButton, SIGNAL(clicked()), visibleDurationLabel, SLOT(clear()));

	// action
	connect(actionExit, SIGNAL(triggered()), this, SLOT(close()));
	connect(actionStatusBar, SIGNAL(toggled(bool)), this, SLOT(showStatusbar(bool)));
    connect(actionInfo, SIGNAL(triggered()), this, SLOT(infoDialog()));
    connect(actionSettings, SIGNAL(triggered()), this, SLOT(settingsDialog()));
    connect(actionAbout, SIGNAL(triggered()), this, SLOT(aboutDialog()));
    connect(actionHelp, SIGNAL(triggered()), this, SLOT(helpDialog()));
	connect(actionStart_Record, SIGNAL(triggered()), dc, SLOT(startRecording()));
	connect(actionPause, SIGNAL(triggered()), dc, SLOT(pauseRecording()));
	connect(actionStop, SIGNAL(triggered()), dc, SLOT(stopRecording()));
	connect(actionClear, SIGNAL(triggered()), dc, SLOT(clearSampling()));
	connect(actionClear, SIGNAL(clicked()), samplingRateLabel, SLOT(clear()));
	connect(actionClear, SIGNAL(clicked()), visibleDurationLabel, SLOT(clear()));
	connect(actionNew, SIGNAL(triggered()), this, SLOT(newSamplingDialog()));
	connect(actionSave, SIGNAL(triggered()), this, SLOT(saveRecord()));
	connect(actionOpen, SIGNAL(triggered()), this, SLOT(openRecord()));

	// scroll
	connect(timeScroll, SIGNAL(valueChanged(int)), plotter, SLOT(scrollTime(int)));
	connect(timeScroll, SIGNAL(valueChanged(int)), this, SLOT(scrollAverageFilter(int)));

	// scale
	connect(manualScaleCheck, SIGNAL(stateChanged(int)), this, SLOT(toggleManualScale()));
	connect(minScaleSpin, SIGNAL(valueChanged(double)), this, SLOT(toggleManualScale()));
	connect(maxScaleSpin, SIGNAL(valueChanged(double)), this, SLOT(toggleManualScale()));

	// filter
	connect(fftCheck, SIGNAL(stateChanged(int)), this, SLOT(toggleFFTFilter()));
	connect(fftMinSpin, SIGNAL(valueChanged(int)), this, SLOT(fftMinSpinChanged(int)) );
	connect(fftMaxSpin, SIGNAL(valueChanged(int)), this, SLOT(fftMaxSpinChanged(int)) );
	connect(fftMinSpin, SIGNAL(valueChanged(int)), this, SLOT(updateFFTFilter()) );
	connect(fftMaxSpin, SIGNAL(valueChanged(int)), this, SLOT(updateFFTFilter()) );
	connect(averageCheck, SIGNAL(stateChanged(int)), this, SLOT(toggleAverageFilter()));
	connect(averageSpin, SIGNAL(valueChanged(int)), this, SLOT(updateAverageFilter()) );

	// out
	connect(analogOutCheck, SIGNAL(stateChanged(int)), this, SLOT(toggleAnalogOutCheck()));
	connect(analogOutSpin, SIGNAL(valueChanged(double)), dc, SLOT(updateAnalogOut(double)));
	connect(digitalOutCheck, SIGNAL(stateChanged(int)), this, SLOT(toggleDigitalOutCheck()));
	connect(digitalOutSpin, SIGNAL(valueChanged(int)), dc, SLOT(updateDigitalOut(int)));

	// plotter
	connect(plotter, SIGNAL(recordTimeChanged(int)), this, SLOT(recordTimeChanged(int)));


	
	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("Settings");
	QString currentDevice = settings.value("currentDevice", QString("")).toString();
	double analogOutStep = settings.value("analogOutStep", 0.1).toDouble();
	settings.endGroup();

	analogOutSpin->setSingleStep(analogOutStep);

	if( ! currentDevice.isEmpty())
	{
		analogOutSpin->setMinimum(DeviceSensor::getAOMinVoltage(currentDevice));
		analogOutSpin->setMaximum(DeviceSensor::getAOMaxVoltage(currentDevice));
	}
	else
	{
		QMessageBox::warning(this, tr("First Start"),
			tr("<p><strong>There is no active device !</strong></p>"
			"<p>It seems this is your first start or you did not select any device at settings."
			"If you do not select and save a device you cannot acquire data from your device !</p>"
			"<p>I will open settings, please select a device and "
			"<strong><font size=\"+1\">save the settings</font></strong>. "
			"<br>If you change other settings you may <strong><font size=\"+1\">restart</font></strong> the application.<br>"
			"<font size=\"-1\"><strong>Hint :</strong> Wait tooltip on controls or use \"what is this\" mode from title bar.</font></p>"),
			QMessageBox::Ok,QMessageBox::Ok);
		QTimer::singleShot(500, actionSettings, SLOT(trigger()));
	}
	
	if(dc->getState() != DeviceController::NoDevice)
		handleStateChanges(DeviceController::Waiting);
	else
		handleStateChanges(DeviceController::NoDevice);
}

void MainWindow::closeEvent(QCloseEvent *event){

	writeSettings();
	event->accept();
	
}

void MainWindow::settingsDialog(){
	
	SettingsDialog * sd = new SettingsDialog(this);
	if (sd->exec() == QDialog::Accepted)
	{
		QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
		settings.beginGroup("Settings");
		double analogOutStep = settings.value("analogOutStep", 0.1).toDouble();
		settings.endGroup();

		analogOutSpin->setSingleStep(analogOutStep);
	}
}

void MainWindow::infoDialog(){

    InfoDialog * id = new InfoDialog(this);
    id->show();

}

void MainWindow::aboutDialog(){

   QMessageBox::about(this, tr("About MEDAQ"),
            tr("<p>The <b>MEDAQ</b>, <b>M</b>edical <b>E</b>xperimentation <b>D</b>ata <b>A</b>c<b>Q</b>uisition was created "
				"by Huseyin Kozan for an experimentation which collects data from an Neural Recording Board with a "
				"National Instruments Data Acquisition Card at Istanbul University.</p>"
				"<p>Huseyin Kozan - <a href='http://huseyinkozan.com.tr'>http://huseyinkozan.com.tr</a></p>"));
}

void MainWindow::helpDialog(){

    QMessageBox::warning(this, tr("Attention!"),tr("Not implemented, yet !"));
}

void MainWindow::readSettings(){

    QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	
	settings.beginGroup("MainWindow");
    QPoint pos = settings.value("pos", QPoint(0, 0)).toPoint();
    QSize size = settings.value("size", QSize(640, 480)).toSize();
	QByteArray mainWindowState = settings.value("State").toByteArray();
	double minScale = settings.value("minScale", 0.0).toDouble();
	double maxScale = settings.value("maxScale", 0.0).toDouble();
	bool manualScale = settings.value("manualScale", false).toBool();
	double analogOut = settings.value("analogOut", 0.0).toDouble();
	int digitalOut = settings.value("digitalOut", 0.0).toInt();
	settings.endGroup();
	
    move(pos);
    resize(size);
	restoreState(mainWindowState);
	minScaleSpin->setValue(minScale);
	maxScaleSpin->setValue(maxScale);
	manualScaleCheck->setChecked(manualScale);
	analogOutSpin->setValue(analogOut);
	digitalOutSpin->setValue(digitalOut);
}

void MainWindow::writeSettings()
{
    QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	
	settings.beginGroup("MainWindow");
    settings.setValue("pos", pos());
    settings.setValue("size", size());
	settings.setValue("State", saveState());
	settings.setValue("minScale", minScaleSpin->value());
	settings.setValue("maxScale", maxScaleSpin->value());
	settings.setValue("manualScale", manualScaleCheck->isChecked());
	settings.setValue("analogOut", analogOutSpin->value());
	settings.setValue("digitalOut", digitalOutSpin->value());
	settings.endGroup();
	
}


void MainWindow::handleStateChanges(int state)
{
	switch(state)
	{
		case DeviceController::NoDevice:

			actionNew->setEnabled(false);
			actionOpen->setEnabled(true);
			actionSave->setEnabled(false);

			actionStart_Record->setEnabled(false);
			actionPause->setEnabled(false);
			actionStop->setEnabled(false);
			actionClear->setEnabled(false);

			recordButton->setEnabled(false);
			pauseButton->setEnabled(false);
			stopButton->setEnabled(false);
			clearButton->setEnabled(false);
			timeScroll->setEnabled(false);

			fftCheck->setEnabled(false);
			averageCheck->setEnabled(false);
			averageSpin->setEnabled(false);
			fftMinSpin->setEnabled(false);
			fftMaxSpin->setEnabled(false);
			
			break;
		case DeviceController::Waiting:

			actionNew->setEnabled(true);
			actionOpen->setEnabled(true);
			actionSave->setEnabled(false);

			actionStart_Record->setEnabled(false);
			actionPause->setEnabled(false);
			actionStop->setEnabled(false);
			actionClear->setEnabled(false);

			recordButton->setEnabled(false);
			pauseButton->setEnabled(false);
			stopButton->setEnabled(false);
			clearButton->setEnabled(false);
			timeScroll->setEnabled(false);

			fftCheck->setEnabled(false);
			averageCheck->setEnabled(false);
			averageSpin->setEnabled(false);
			fftMinSpin->setEnabled(false);
			fftMaxSpin->setEnabled(false);

			plotter->clearPlotter();

			fftMagnitudeData.clear();
			fftPhaseData.clear();
			psdData.clear();
			fftBottomData.clear();
			averageData.clear();
			averageRecordData.clear();
			averageBottomData.clear();
			
			break;
		case DeviceController::Plotting:

			actionNew->setEnabled(true);
			actionOpen->setEnabled(true);
			actionSave->setEnabled(false);

			actionStart_Record->setEnabled(true);
			actionPause->setEnabled(false);
			actionStop->setEnabled(false);
			actionClear->setEnabled(true);

			recordButton->setEnabled(true);
			pauseButton->setEnabled(false);
			stopButton->setEnabled(false);
			clearButton->setEnabled(true);
			timeScroll->setEnabled(false);

			fftCheck->setEnabled(false);
			averageCheck->setEnabled(false);
			averageSpin->setEnabled(false);
			fftMinSpin->setEnabled(false);
			fftMaxSpin->setEnabled(false);

			break;
		case DeviceController::Paused:

			actionNew->setEnabled(true);
			actionOpen->setEnabled(true);
			actionSave->setEnabled(false);

			actionStart_Record->setEnabled(true);
			actionPause->setEnabled(false);
			actionStop->setEnabled(true);
			actionClear->setEnabled(true);

			recordButton->setEnabled(true);
			pauseButton->setEnabled(false);
			stopButton->setEnabled(true);
			clearButton->setEnabled(true);
			timeScroll->setEnabled(false);

			fftCheck->setEnabled(false);
			averageCheck->setEnabled(false);
			averageSpin->setEnabled(false);
			fftMinSpin->setEnabled(false);
			fftMaxSpin->setEnabled(false);

			break;
		case DeviceController::Recording:

			actionNew->setEnabled(true);
			actionOpen->setEnabled(true);
			actionSave->setEnabled(false);

			actionStart_Record->setEnabled(false);
			actionPause->setEnabled(true);
			actionStop->setEnabled(true);
			actionClear->setEnabled(true);

			recordButton->setEnabled(false);
			pauseButton->setEnabled(true);
			stopButton->setEnabled(true);
			clearButton->setEnabled(true);
			timeScroll->setEnabled(false);

			fftCheck->setChecked(false);
			averageCheck->setChecked(false);

			fftCheck->setEnabled(false);
			averageCheck->setEnabled(false);
			averageSpin->setEnabled(false);
			fftMinSpin->setEnabled(false);
			fftMaxSpin->setEnabled(false);

			break;
		case DeviceController::Scrolling:

			actionNew->setEnabled(true);
			actionOpen->setEnabled(true);
			actionSave->setEnabled(true);

			actionStart_Record->setEnabled(false);
			actionPause->setEnabled(false);
			actionStop->setEnabled(false);
			actionClear->setEnabled(true);

			recordButton->setEnabled(false);
			pauseButton->setEnabled(false);
			stopButton->setEnabled(false);
			clearButton->setEnabled(true);
			timeScroll->setEnabled(true);

			fftCheck->setEnabled(true);
			averageCheck->setChecked(false);
			averageCheck->setEnabled(true);
			averageSpin->setEnabled(true);
			fftMinSpin->setEnabled(true);
			fftMaxSpin->setEnabled(true);

			dc->stopSampling();

			plotter->prepareForScroll();
			timeScroll->setMaximum(plotter->getMaxScrollStep());

			plotter->scrollTime(0);

			fftMinSpin->setMinimum(0);
			fftMinSpin->setMaximum(0);
			fftMaxSpin->setMinimum(1);
			fftMaxSpin->setMaximum( qFloor( plotter->recordData.size() / plotter->getSamplingRate() ) );

			break;
	}
}


void MainWindow::handleLogMessages(QString message)
{
	loggerEdit->append(message);
}



void MainWindow::newSamplingDialog()
{
	NewSamplingDialog d(this);
	if( d.exec() == QDialog::Accepted )
	{
		dc->clearSampling();
		samplingRateLabel->clear();
		visibleDurationLabel->clear();
		QString channelName = d.channelName;
		int terminalConfiguration;
		if(d.terminalConfiguration == 0)
			terminalConfiguration = DeviceSensor::AIReferenced;
		else if(d.terminalConfiguration == 1)
			terminalConfiguration = DeviceSensor::AINonReferenced;
		else if(d.terminalConfiguration == 2)
			terminalConfiguration = DeviceSensor::AIDifferential;
		else if(d.terminalConfiguration == 3)
			terminalConfiguration = DeviceSensor::AIPseudoDifferential;
		double minVoltage = d.minVoltage;
		double maxVoltage = d.maxVoltage;
		unsigned int visibleDuration = d.visibleDuration;
		unsigned int samplingRate = d.samplingRate;
		bool startRecordImmediately = d.startRecordImmediately;

		samplingRateLabel->setText(tr("Sampling Rate : %1 S/s").arg(samplingRate));
		visibleDurationLabel->setText(tr("Visible Duration : %1 s").arg(visibleDuration));

		dc->newSampling( channelName, terminalConfiguration, 
							minVoltage, maxVoltage, 
							visibleDuration, samplingRate, startRecordImmediately);
	}
}


void MainWindow::toggleManualScale()
{
	if(manualScaleCheck->isChecked())
	{
		plotter->setScale(minScaleSpin->value(), maxScaleSpin->value());
	}
	else
	{
		plotter->setScale(0,0,true);
	}
}



void MainWindow::toggleAnalogOutCheck()
{
	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("Settings");
	QString currentAOChannel = settings.value("currentAOChannel", QString("")).toString();
	settings.endGroup();

	if( ! currentAOChannel.isEmpty())
	{
		if(analogOutCheck->isChecked())
		{
			dc->startAnalogOut(analogOutSpin->value());
		}
		else
		{
			dc->stopAnalogOut();
		}
	}
}



void MainWindow::toggleDigitalOutCheck()
{
	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("Settings");
	QString currentDOLine = settings.value("currentDOLine", QString("")).toString();
	settings.endGroup();

	if( ! currentDOLine.isEmpty())
	{
		if(digitalOutCheck->isChecked())
		{
			dc->startDigitalOut(digitalOutSpin->value());
		}
		else
		{
			dc->stopDigitalOut();
		}
	}
}



void MainWindow::saveRecord()
{
	QString saveName = QFileDialog::getSaveFileName(this,
								tr("Save File"), "", tr("Medaq File (*.medaq)"));
	if( ! saveName.isNull()){
		QFile file(saveName);
		file.open(QIODevice::WriteOnly);
		QDataStream out(&file);

		quint32 visibleDuration = plotter->getVisibleDuration();
		quint32 samplingRate = plotter->getSamplingRate();

		QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
		settings.beginGroup("Settings");
		QString currentDevice = settings.value("currentDevice", QString("")).toString();
		settings.endGroup();

		qreal minScale = DeviceSensor::getAIMinVoltage(currentDevice);
		qreal maxScale = DeviceSensor::getAIMaxVoltage(currentDevice);

		// Write a header with a "magic number" and a version
		out << (quint32) 0x11111111; // magic number, this file is medaq file
		out << (quint32) 100; //1.00, internal version
		out << visibleDuration;
		out << samplingRate;
		out << minScale;
		out << maxScale;

		// Write the data
		for(int i=0; i<plotter->recordData.size(); ++i){
			out << plotter->recordData.at(i);
		}
	}
}


void MainWindow::openRecord()
{
	QString openName = QFileDialog::getOpenFileName(this,
							tr("Save File"), "", tr("Medaq File (*.medaq)"));
	if( ! openName.isNull())
	{
		dc->clearSampling();
		samplingRateLabel->clear();
		visibleDurationLabel->clear();

		QFile file(openName);
		file.open(QIODevice::ReadOnly);
		QDataStream in(&file);

		quint32 visibleDuration;
		quint32 samplingRate;
		qreal minScale;
		qreal maxScale;

		// Read and check the header
		quint32 magic;
		in >> magic;
		if (magic != 0x11111111){
			loggerEdit->append( tr("The file that you trying to open is not a Medaq file !") );
			return;
		}

		// Read the version
		quint32 version;
		in >> version;
		if (version < 100){
			loggerEdit->append( tr("The file that you trying to open is an old file format !") );
			return;
		}
		if (version > 100){
			loggerEdit->append( tr("The file that you trying to open is a newer file format !") );
			return;
		}

		in >> visibleDuration;
		in >> samplingRate;
		in >> minScale;
		in >> maxScale;

		samplingRateLabel->setText(tr("Sampling Rate : %1 S/s").arg(samplingRate));
		visibleDurationLabel->setText(tr("Visible Duration : %1 s").arg(visibleDuration));
		minScaleSpin->setMinimum(minScale);
		minScaleSpin->setMaximum(maxScale);
		maxScaleSpin->setMinimum(minScale);
		maxScaleSpin->setMaximum(maxScale);

		dc->clearSampling();
		
		unsigned int dataSize =  (     file.size() - (4*sizeof(quint32)) - (2*sizeof(qreal))    )   /    sizeof(double);
		for(int i=0; i<dataSize; ++i)
		{
			double x = 0;
			in >> x;
			plotter->recordData.append(x);
		}
		file.close();

		recordTimeChanged( dataSize / samplingRate );
		plotter->prepareForPlot(visibleDuration, samplingRate);
		plotter->prepareForScroll();
		timeScroll->setMaximum(plotter->getMaxScrollStep());
		dc->stopRecording();	// state = Scrolling
		
	}
}


void MainWindow::showStatusbar(bool value){
	if(value)
	{
		statusBar()->show();
	}
	else
	{
		statusBar()->hide();
	}
}



void MainWindow::toggleFFTFilter()
{
	if(fftCheck->isChecked())
	{
		fftMagnitudePlot = new QwtPlot(tr("FFT Magnitude"), this);
		fftPhasePlot = new QwtPlot(tr("FFT Phase"), this);
		psdPlot = new QwtPlot(tr("PSD"), this);
		fftMagnitudePlot->setCanvasBackground(Qt::white);
		fftPhasePlot->setCanvasBackground(Qt::white);
		psdPlot->setCanvasBackground(Qt::white);
		gridLayout->addWidget(fftMagnitudePlot, 0, 1);
		gridLayout->addWidget(fftPhasePlot, 1, 1);
		gridLayout->addWidget(psdPlot, 1, 0);
		fftMagnitudeCurve = new QwtPlotCurve(tr("FFT Magnitude Curve"));
		fftPhaseCurve = new QwtPlotCurve(tr("FFT Phase Curve"));
		psdCurve = new QwtPlotCurve(tr("PSD Curve"));

		QwtPlotPicker * fftMagnitude_picker = new QwtPlotPicker(QwtPlot::xBottom, QwtPlot::yLeft,
			QwtPicker::PointSelection | QwtPicker::DragSelection, 
			QwtPlotPicker::CrossRubberBand, QwtPicker::AlwaysOn, 
			fftMagnitudePlot->canvas());
		fftMagnitude_picker->setRubberBandPen(QColor(Qt::green));
		fftMagnitude_picker->setRubberBand(QwtPicker::CrossRubberBand);
		fftMagnitude_picker->setTrackerPen(QColor(Qt::blue));

		QwtPlotPicker * fftPhase_picker = new QwtPlotPicker(QwtPlot::xBottom, QwtPlot::yLeft,
			QwtPicker::PointSelection | QwtPicker::DragSelection, 
			QwtPlotPicker::CrossRubberBand, QwtPicker::AlwaysOn, 
			fftPhasePlot->canvas());
		fftPhase_picker->setRubberBandPen(QColor(Qt::green));
		fftPhase_picker->setRubberBand(QwtPicker::CrossRubberBand);
		fftPhase_picker->setTrackerPen(QColor(Qt::blue));

		QwtPlotPicker * psd_picker = new QwtPlotPicker(QwtPlot::xBottom, QwtPlot::yLeft,
			QwtPicker::PointSelection | QwtPicker::DragSelection, 
			QwtPlotPicker::CrossRubberBand, QwtPicker::AlwaysOn, 
			psdPlot->canvas());
		psd_picker->setRubberBandPen(QColor(Qt::green));
		psd_picker->setRubberBand(QwtPicker::CrossRubberBand);
		psd_picker->setTrackerPen(QColor(Qt::blue));

		// call the update function
		updateFFTFilter();

		fftMagnitudeCurve->attach(fftMagnitudePlot);
		fftPhaseCurve->attach(fftPhasePlot);
		psdCurve->attach(psdPlot);

		fftMagnitudePlot->replot();
		fftPhasePlot->replot();
		psdPlot->replot();

		plotter->setTitle(tr("Sampled Signal"));
	}
	else
	{
		if(fftMagnitudePlot)
		{
			delete fftMagnitudeCurve;
			delete fftMagnitudePlot;
			fftMagnitudeCurve = NULL;
			fftMagnitudePlot = NULL;
		}
		if(fftPhasePlot)
		{
			delete fftPhaseCurve;
			delete fftPhasePlot;
			fftPhaseCurve = NULL;
			fftPhasePlot = NULL;
		}
		if(psdPlot)
		{
			delete psdCurve;
			delete psdPlot;
			psdCurve = NULL;
			psdPlot = NULL;
		}

		plotter->setTitle(tr(""));
	}
}


void MainWindow::updateFFTFilter()
{
	if(fftCheck->isChecked())
	{
		// calculate fft
		// get data from plotter record about the duration
		int start	= fftMinSpin->value() * plotter->getSamplingRate();
		int end		= fftMaxSpin->value() * plotter->getSamplingRate();

		if( start >= plotter->recordData.size() )
			return;
		if( end > plotter->recordData.size() )
			return;

		// do fft 

		int size = end - start;

		double *in	= (double*) fftw_malloc( sizeof(double) * size );
		fftw_complex *out = (fftw_complex*) fftw_malloc( sizeof(fftw_complex) * size );
		fftw_plan p	= fftw_plan_dft_r2c_1d( size, in, out, FFTW_ESTIMATE );

		if(fftWisdom.isEmpty())
		{
			char * s = fftw_export_wisdom_to_string();
			fftWisdom = QString::fromLatin1(s);
		}
		else
		{
			fftw_import_wisdom_from_string(fftWisdom.toLatin1().data());
		}

		if( p!=NULL && in!=NULL && out!=NULL )
		{
			statusBar()->showMessage(tr("Deriving the FFT data ..."));

			memcpy(&(in[0]), &(plotter->recordData.data()[start]), size * sizeof(double));			// take data from plot screen

			fftw_execute(p);

			fftMagnitudeData.fill(0.0, size);
			fftPhaseData.fill(0.0, size);
			psdData.fill(0.0, size);
			fftBottomData.resize(size);

			for(int i=0; i<size; ++i)
			{
				register int xr = out[i][0];
				register int xi = out[i][1];
				fftMagnitudeData[i] = qSqrt( xr*xr + xi*xi );
				fftPhaseData[i] = atan2( (double) xi,(double) xr );
				psdData[i] = xr*xr + xi*xi ;
				fftBottomData[i] = i;
			}

			statusBar()->showMessage(tr(""));

		}
		else
		{
			statusBar()->showMessage(tr("Could not derive fft"));
			qDebug() << "cannot create plan";
		}

		fftw_destroy_plan(p);
		fftw_free(in); fftw_free(out);

		// set datas
		if(fftMagnitudeCurve)
			fftMagnitudeCurve->setRawData( fftBottomData.data(), fftMagnitudeData.data(), size );
		if(fftPhaseCurve)
			fftPhaseCurve->setRawData( fftBottomData.data(), fftPhaseData.data(), size );
		if(psdCurve)
			psdCurve->setRawData( fftBottomData.data(), psdData.data(), size );

		fftMagnitudePlot->replot();
		fftPhasePlot->replot();
		psdPlot->replot();
	}
}


void MainWindow::fftMinSpinChanged(int val)
{
	fftMaxSpin->setMinimum(val+1);
}


void MainWindow::fftMaxSpinChanged(int val)
{
	fftMinSpin->setMaximum(val-1);
}

void MainWindow::recordTimeChanged(int sec)
{
	int m = sec / 60;
	int s = sec % 60;
	QString s_m;
	QString s_s;
	QString z("0");
	
	if(m<10)
		s_m = z + QString::number(m);
	else
		s_m = QString::number(m);

	if(s<10)
		s_s = z + QString::number(s);
	else
		s_s = QString::number(s);
	
	recordTimeLabel->setText(s_m + QString(":") + s_s);
}


void MainWindow::toggleAverageFilter()
{
	if(averageCheck->isChecked())
	{
		averagePlot = new QwtPlot(tr("Average"), this);
		averagePlot->setCanvasBackground(Qt::white);
		gridLayout->addWidget(averagePlot, 2, 0);
		averageCurve = new QwtPlotCurve(tr("Average Curve"));

		QwtPlotPicker * average_picker = new QwtPlotPicker(QwtPlot::xBottom, QwtPlot::yLeft,
			QwtPicker::PointSelection | QwtPicker::DragSelection, 
			QwtPlotPicker::CrossRubberBand, QwtPicker::AlwaysOn, 
			averagePlot->canvas());
		average_picker->setRubberBandPen(QColor(Qt::green));
		average_picker->setRubberBand(QwtPicker::CrossRubberBand);
		average_picker->setTrackerPen(QColor(Qt::blue));

		int size = plotter->getSamplingRate() * plotter->getVisibleDuration();
		averageData.fill(0.0, size);
		averageBottomData.resize(size);
		for( int i = 0 ; i < size ; ++i )
		{
			averageBottomData[i] = i;
		}

		// call the update function
		updateAverageFilter();

		if(averageCurve)
			averageCurve->setRawData( averageBottomData.data(), averageData.data(), averageBottomData.size() );

		averageCurve->attach(averagePlot);

		// time scale
		TimeScaleDraw * tsd = new TimeScaleDraw(QTime(0,0), plotter->getSamplingRate());
		averagePlot->setAxisScaleDraw(QwtPlot::xBottom, tsd );
		averagePlot->setAxisScale(QwtPlot::xBottom, 0, size);
		averagePlot->setAxisLabelRotation(QwtPlot::xBottom, -50.0);
		averagePlot->setAxisLabelAlignment(QwtPlot::xBottom, Qt::AlignLeft | Qt::AlignBottom);
		// To avoid this "jumping canvas" effect, we add a permanent margin.
		QwtScaleWidget *scaleWidget = averagePlot->axisWidget(QwtPlot::xBottom);
		const int fmh = QFontMetrics(scaleWidget->font()).height();
		scaleWidget->setMinBorderDist(0, fmh / 2);

		averagePlot->replot();

		plotter->setTitle(tr("Sampled Signal"));
	}
	else
	{
		if(averagePlot)
		{
			delete averageCurve;
			delete averagePlot;
			averageCurve = NULL;
			averagePlot = NULL;
		}

		plotter->setTitle(tr(""));
	}
}


void MainWindow::updateAverageFilter()
{
	if(averageCheck->isChecked())
	{
		int winSize = averageSpin->value();

		if( winSize < 3 || winSize % 2 == 0 || winSize > plotter->recordData.size() )
			return;

		int recordSize = plotter->recordData.size();
		int half = (winSize - 1) / 2;
		averageRecordData.fill ( 0.0, recordSize );
		double * r = plotter->recordData.data();
		double * a = averageRecordData.data();

		// data without boundary spaces
		for(int i = half; i < recordSize - half; ++i)
		{
			double total = 0;

			for(int j = -half; j <= half; ++j)
			{
				total += r[i+j];
			}

			a[i] = total / winSize;
		}

		scrollAverageFilter(timeScroll->value());

		averagePlot->replot();
	}
}


void MainWindow::scrollAverageFilter(int step)
{
	if( ! averageCheck->isChecked())
		return;
	if ( step > plotter->getMaxScrollStep() )
		return;

	int size = plotter->getSamplingRate() * plotter->getVisibleDuration();
	if( size > plotter->recordData.size())
	{
		// copy recorddata and return
		memcpy(&(averageData.data()[0]), &(averageRecordData.data()[0]), averageRecordData.size() * sizeof(double));
		averagePlot->replot();
		return;
	}

	QSettings settings(QDir::currentPath() + "/medaq.ini", QSettings::IniFormat);
	settings.beginGroup("Settings");
		int plotSplitCount					= settings.value("plotSplitCount", 50).toInt();
	settings.endGroup();


	int sourceIndex = step*(size/plotSplitCount);
	memcpy(&(averageData.data()[0]), &(averageRecordData.data()[sourceIndex]), averageData.size() * sizeof(double));


	unsigned int plotSize = averageBottomData.size();
	double * d = averageBottomData.data();
	int samplingRate = plotter->getSamplingRate();
	QwtValueList vlist_y[3];
	for ( unsigned int i = 0 ; i < plotSize ; ++i )
	{
		register int x = sourceIndex + i; 
		d[i] = x;
		if( 0 == x % samplingRate )
			vlist_y[0] << d[i];
	}
	averagePlot->setAxisScale(QwtPlot::xBottom, averageBottomData[0], averageBottomData[plotSize - 1]);
	QwtScaleDiv scdiv_y(averageBottomData.at(0), averageBottomData.at(averageBottomData.size()-1), vlist_y);
	scdiv_y.setTicks(QwtScaleDiv::MajorTick, vlist_y[0]);
	averagePlot->setAxisScaleDiv(QwtPlot::xBottom, scdiv_y);

	averagePlot->replot();
}
