/*
	Copyright 2008 Huseyin Kozan (posta@huseyinkozan.com.tr)

	This file is part of Medaq.

	Medaq is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Medaq is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with Medaq.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ui_MainWindow.h"

class DeviceController;
class QwtPlotCurve;
class QwtPlot;

QT_BEGIN_NAMESPACE
class QAction;
class SettingsDialog;
class QLabel;
QT_END_NAMESPACE

class MainWindow : public QMainWindow, private Ui::MainWindow
{
    Q_OBJECT

public:
    MainWindow();
    
protected:
    void closeEvent(QCloseEvent *event);
    
private slots:

    void settingsDialog();
    void infoDialog();
    void aboutDialog();
    void helpDialog();
	void showStatusbar(bool);

	void handleStateChanges(int state);
	void handleLogMessages(QString messsage);
	void toggleManualScale();

	// out
	void toggleAnalogOutCheck();
	void toggleDigitalOutCheck();

	// filter
	void toggleFFTFilter();
	void updateFFTFilter();
	
	void toggleAverageFilter();
	void updateAverageFilter();
	void scrollAverageFilter(int step);

	void newSamplingDialog();
	void saveRecord();
	void openRecord();

	void fftMinSpinChanged(int);
	void fftMaxSpinChanged(int);

	void recordTimeChanged(int);
    
private:
    void connections();
    void readSettings();
    void writeSettings();

private:
    QAction * dockToggleViewAction;
	DeviceController * dc;
	QLabel * samplingRateLabel;
	QLabel * visibleDurationLabel;

	// plot
	QwtPlot * fftMagnitudePlot;
	QwtPlot * fftPhasePlot;
	QwtPlot * psdPlot;
	QwtPlot * averagePlot;
	QwtPlotCurve * fftMagnitudeCurve;
	QwtPlotCurve * fftPhaseCurve;
	QwtPlotCurve * psdCurve;
	QwtPlotCurve * averageCurve;

	// filter
	QString				fftWisdom;
	QVector<double>		fftMagnitudeData;
	QVector<double>		fftPhaseData;
	QVector<double>		psdData;
	QVector<double>		fftBottomData;
	QVector<double>		averageData;
	QVector<double>		averageRecordData;
	QVector<double>		averageBottomData;

};

#endif

