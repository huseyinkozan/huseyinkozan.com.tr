// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once
#include<windows.h>        // Windows header file.


#include "targetver.h"
#include "matrixes.h"
#include "tetris_functions.h"

#include <stdio.h>
#include <tchar.h>



// TODO: reference additional headers your program requires here
