// #pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" ) 

//#pragma comment (linker, "/SUBSYSTEM:WINDOWS")
//#pragma comment (linker, "/ENTRY:WinMainCRTStartup")

#pragma comment (linker, "/SUBSYSTEM:CONSOLE")
#pragma comment (linker, "/ENTRY:mainCRTStartup")

#include <GL/glut.h>
#include <time.h>
#include <stdlib.h>
#include "tetris_functions.h"
#include "matrixes.h"
#include "BMPLoader.h"

#ifdef BMPLOADER_ENABLE
	CBMPLoader * texture = new CBMPLoader();
#endif

GLuint window;
int color;
void timerFuction(int);

void keyboardFunction(unsigned char key, int x, int y)
{
	switch(key)
	{
	case 27:
		exit(0);
		break;
	case 32:
			if(game_paused)
			{
				game_paused = false;
				glutSetWindow(window);
				glutPostRedisplay();
			}
			else
			{
				game_paused = true;
				glutSetWindow(window);
				glutPostRedisplay();
			}
			break;
	}
}

void keyboardSpacialFuntion(int key, int x, int y)
{
	if ( ! game_ended() )
	{
		switch(key)
		{
		case GLUT_KEY_LEFT:
			if( ! game_paused )
			{
				moveMatrixLeft(movingMatrix);
				glutSetWindow(window);
				glutPostRedisplay();
			}
			break;
		case GLUT_KEY_RIGHT:
			if( ! game_paused )
			{
				moveMatrixRight(movingMatrix);
				glutSetWindow(window);
				glutPostRedisplay();
			}
			break;
		case GLUT_KEY_DOWN:
			if( ! game_paused )
			{
				moveMatrixDown(movingMatrix);
				glutSetWindow(window);
				glutPostRedisplay();
			}
			break;
		case GLUT_KEY_UP:
			if( ! game_paused )
			{
				rotateMatrixLeft(movingMatrix);
				glutSetWindow(window);
				glutPostRedisplay();
			}
			break;
		}
	}

}

void myDisplay()
{
	//glEnable(GL_TEXTURE_2D);
	//glBindTexture(GL_TEXTURE_2D, texture->ID);
	//glBegin(GL_QUADS);
	////glNormal3f( 0.0f, 0.0f, 1.0f);					// Normal Pointing Towards Viewer
	// glTexCoord2f(0.0f, 0.0f); glVertex3f( 0.0f, 0.0f,  0.0f);	// Point 1 (Front)
	// glTexCoord2f(1.0f, 0.0f); glVertex3f( (GLfloat) glutGet(GLUT_WINDOW_X), 0.0f,  0.0f);	// Point 2 (Front)
	// glTexCoord2f(1.0f, 1.0f); glVertex3f( (GLfloat) glutGet(GLUT_WINDOW_X),  (GLfloat) glutGet(GLUT_WINDOW_Y),  0.0f);	// Point 3 (Front)
	// glTexCoord2f(0.0f, 1.0f); glVertex3f( 0.0f,  (GLfloat) glutGet(GLUT_WINDOW_Y),  0.0f);	// Point 4 (Front)
	//glEnd();
	//glDisable(GL_TEXTURE_2D);

	glClearColor(0.7,0.7,0.7,0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glColor3f (0,0,0);
	glRectd( 0.0, 0.0, 1.0, -1.8 );
	glRectd( ((0+1)*0.1-0.09)+1.0, -(0+1)*0.1+0.09, ((3+1)*0.1-0.01)+1.0, -(2+1)*0.1+0.01 );

	char levelString[] = "Level :", levelCount[255] = "1", score[] = "Score :",
		scoreCount[255] = "0",gameOver[] = "Game Over",gamePaused[] = "Game Paused",
		escString[] = "ESC2Exit",spaceString[] = "Space2Pause", *s;
	itoa(eliminated_blocks,scoreCount,10);
	itoa(level+1,levelCount,10);
	glRasterPos2f(1.01, -0.5);
	for (s = levelString; *s; s++)
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *s);
	glRasterPos2f(1.26, -0.5);
	for (s = levelCount; *s; s++)
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *s);
	glRasterPos2f(1.01, -0.8);
	for (s = score; *s; s++)
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *s);
	glRasterPos2f(1.26, -0.8);
	for (s = scoreCount; *s; s++)
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *s);
	glRasterPos2f(1.01, -1.3);
	for (s = escString; *s; s++)
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *s);
	glRasterPos2f(1.01, -1.5);
	for (s = spaceString; *s; s++)
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *s);
	// draw nextMatrix and baseMatrix
	for(int i = 0; i <= 17; i++)
	{
		for(int j = 0; j <= 9; j++)
		{
			if( movingMatrix[i][j] != 0 || baseMatrix[i][j] != 0 )
			{
				int color = 1;
				if(movingMatrix[i][j] != 0)
					color = movingMatrix[i][j]>=99?movingMatrix[i][j]-100:movingMatrix[i][j];
				else 
					color = baseMatrix[i][j]>=99?baseMatrix[i][j]-100:baseMatrix[i][j];
				switch(color)
				{
					case 1: glColor3f(1,0,0); break;
					case 2: glColor3f(0,1,0); break;
					case 3: glColor3f(0,0,1); break;
					case 4: glColor3f(1,1,0); break;
					case 5: glColor3f(0,1,1); break;
					case 6: glColor3f(1,0,1); break;
					case 7: glColor3f(1,1,1); break;
				}
				glRectf( (j+1)*0.1-0.09, -(i+1)*0.1+0.09, (j+1)*0.1-0.01, -(i+1)*0.1+0.01 );
			}
		}
	}
	// draw nextMatrix
	for(int i = 0; i <= 2; i++)
	{
		for(int j = 0; j <= 3; j++)
		{
			int color = 0;
			if(nextMatrix[i][j] != 0)
				color = nextMatrix[i][j]>=99?nextMatrix[i][j]-100:nextMatrix[i][j];
			switch(color)
			{
				case 0: glColor3f(0,0,0); break;
				case 1: glColor3f(1,0,0); break;
				case 2: glColor3f(0,1,0); break;
				case 3: glColor3f(0,0,1); break;
				case 4: glColor3f(1,1,0); break;
				case 5: glColor3f(0,1,1); break;
				case 6: glColor3f(1,0,1); break;
				case 7: glColor3f(1,1,1); break;
			}
			glRectf( ((j+1)*0.1-0.09)+1.0, -(i+1)*0.1+0.09, ((j+1)*0.1-0.01)+1.0, -(i+1)*0.1+0.01 );
		}
	}
	if ( game_ended() )
	{
		glColor3f(0.7,0.7,0.7);
		glRectf(0.2,-1.0,0.8,-1.3);
		glColor3f(0,0,0);
		glRectf(0.21,-1.01,0.79,-1.29);
		glColor3f(1,0,0);
		glRasterPos3f(0.3, -1.3,-0.1);
		for (s = gameOver; *s; s++)
			glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *s);
	}
	if ( game_paused )
	{
		glColor3f(0.7,0.7,0.7);
		glRectf(0.2,-1.0,0.8,-1.3);
		glColor3f(0,0,0);
		glRectf(0.21,-1.01,0.79,-1.29);
		glColor3f(1,0,0);
		glRasterPos3f(0.25, -1.3,-0.1);
		for (s = gamePaused; *s; s++)
			glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *s);
	}

	glFlush();
}
void timerFuction(int value)
{
	if ( ! game_ended() )
	{
		if( ! game_paused  )
		{
			moveMatrixDown(movingMatrix);
			glutSetWindow(window);
			glutPostRedisplay();
		}
		glutTimerFunc(1000/(level+1),timerFuction,1);
	}
}
int main(int argc, char ** argv)
{
	srand( (unsigned) time(NULL) );
	currentObject = rand() % 8;
	nextObject = rand() % 8;
	callNewObject(currentObject,nextObject);

	#ifdef BMPLOADER_ENABLE
		texture->LoadBMPFile("image.bmp");
	#endif

	glutInitWindowSize(400,300);
	glutInitWindowPosition(300,0);
	glutInit (&argc,argv);

	window = glutCreateWindow("Tetris");
	glutSpecialFunc(keyboardSpacialFuntion);
	glutKeyboardFunc(keyboardFunction);
	glutDisplayFunc(myDisplay);
	glutTimerFunc(1000/(level+1),timerFuction,1);

	glFrustum( 0.0, 1.0, -1.2, 0.0, 1.0, 3.5 );
	gluLookAt(	0.0, 0.0, 1.5,			// eye
		0.0, 0.0, 0.0,					// center
		0.0, 1.0, 0.0 );				// up

	glutMainLoop();
	return(0);
}