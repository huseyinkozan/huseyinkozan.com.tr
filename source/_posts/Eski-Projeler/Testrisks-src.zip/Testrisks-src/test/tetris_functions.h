
#ifndef TEST_H
#define TEST_H

extern int eliminated_blocks;
extern int nextObject;
extern int currentObject;
extern int level;
extern bool game_paused;
bool game_ended(void);
bool isConflictWithBaseMatrix(char [18][10]);
void moveMatrixDown(char [18][10]);
void moveMatrixLeft(char [18][10]);
void moveMatrixRight(char [18][10]);
void assignToMovingMatrix(char [18][10]);
void assignToNextMatrix(char [3][4]);
void assignToBaseMatrix(char [18][10]);
void zeroMovingmatrix(char [18][10]);
bool isObjectOnLeftSide(char [18][10]);
bool isObjectOnRightSide(char [18][10]);
void rotateMatrixLeft(char [18][10]);
bool isObjectOnDown(char [18][10]);
void callNewObject(int,int);

#endif /* TEST_H */