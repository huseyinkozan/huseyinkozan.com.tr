#ifdef BMPLOADER_ENABLE
#ifndef BMPLOADER_H
#define BMPLOADER_H

#include <windows.h>

#define BITMAP_ID 0x4D42	// The universal bitmap ID


class CBMPLoader
{
   public:
      CBMPLoader();   // Constructor.
      ~CBMPLoader();  // Destructor.

      bool LoadBMPFile(char *filename);   // Load a .bmp image file.
      void FreeImage();                   // Delete a image.

      unsigned int ID;                    // ID used for generating the textures in OpenGl.
      int imageWidth;                     // Width of a texture.
      int imageHeight;                    // Height of a texture.

   protected:
      void GenerateTexture();             // Generate a texture in OpenGL.
      unsigned char* LoadBitmap(char *file,
                                BITMAPINFOHEADER *bitmapInfoHeader);// Load a bitmap image.

      unsigned char *image;               // Texture image.
      bool textureExist;                  // This will be used if the image was loaded.
      int type;                           // Image format.
};

#endif
#endif /*BMPLOADER_ENABLE*/