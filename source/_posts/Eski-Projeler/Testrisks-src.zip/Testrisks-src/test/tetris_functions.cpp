#include <GL/glut.h>
#include <time.h>
#include <stdlib.h>
#include "tetris_functions.h"
#include "matrixes.h"

bool game_paused = false;
bool game_ended_bool = false;
int eliminated_blocks = 0;
int level = 0;
int nextObject = 0;
int currentObject = 0;

bool game_ended()
{
	return game_ended_bool;
}

bool isConflictWithBaseMatrix(char xMatrix[18][10]) // return false when didnt conflict
{
	for(int i = 0; i <= 17; i++)
	{
		for(int j = 0; j <= 9; j++)
		{
			if( ( xMatrix[i][j] != 0 ) & ( baseMatrix[i][j] != 0 ) )
			{
				return true;
			}
		}
	}
	return false;
}

void moveMatrixDown(char xMatrix[18][10])
{
	char tempMatrix[18][10];			// temp matrix to move
	// copy to temp matrix with moving down
	for(int i = 1; i <= 17; i++)
	{
		for(int j = 0; j <= 9; j++)
		{
			tempMatrix[i][j] = xMatrix[i-1][j];
		}
	}
	// fill top with 0
	for(int j = 0; j <= 9; j++)
		tempMatrix[0][j] = 0;
	// check with base matrix and is it on the bottom
	if( !isConflictWithBaseMatrix(tempMatrix) && !isObjectOnDown(xMatrix) )
	{
		// save matrix
		for(int i = 0; i <= 17; i++)
		{
			for(int j = 0; j <= 9; j++)
			{
				xMatrix[i][j] = tempMatrix[i][j]; // save back
			}
		}
	}
	else
	{
		for(int j = 0; j <= 9; j++)
		{
			if( xMatrix[0][j] != 0 ) game_ended_bool = true;
		}
		if ( ! game_ended_bool )
		{
			assignToBaseMatrix(movingMatrix);
			// check the rows that filled
			char row[18] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
			int count = 0;
			bool row_check = false;
			for(int i = 0; i <= 17; i++)
			{
				row_check = false;
				for(int j = 0; j <= 9; j++)
				{
					if( baseMatrix[i][j] == 0 )
					{
						row_check = false;
						break;
					}
					row_check = true;

				}
				if(row_check)
				{
					row[i] = 1;
					count++;
				}
			}
			// eliminate the filled rows
			for(int x = 0;x < count ; x++ )
			{
				bool copy_upper_rows = false;
				int y = 0;
				for(y = 0; y<=17;y++) if(row[y] == 1)break;
				for(int i = y ; i >= 1; i--)
				{
					if( row[i] == 1 )
					{
						for(int j = 0; j <= 9; j++)
						{
							baseMatrix[i][j] = baseMatrix[i-1][j];
						}
						row[i] = 0;
						copy_upper_rows = true;
					}
					if ( copy_upper_rows )
					{
						for(int j = 0; j <= 9; j++)
						{
							baseMatrix[i][j] = baseMatrix[i-1][j];
						}
					}

				}
				for(int j = 0; j <= 9; j++)
					baseMatrix[0][j] = 0;
			}
			// save score
			eliminated_blocks += count*count*1;
			level = eliminated_blocks / 100;
			currentObject = nextObject;
			srand( (unsigned) time(NULL) );
			nextObject = rand() % 8;
			callNewObject(currentObject,nextObject);
		}
	}
}

void moveMatrixLeft(char xMatrix[18][10])
{
	// if matrix is not on left side
	if( !isObjectOnLeftSide(xMatrix) )
	{
		char tempMatrix[18][10];
		// store data in temp matrix and move left
		for(int i = 0; i <= 17; i++)
		{
			for(int j = 1; j <= 9; j++)
			{
				tempMatrix[i][j-1] = xMatrix[i][j];
			}
		}
		// fill right side with 0
		for(int i = 0; i <= 17; i++)
			tempMatrix[i][9] = 0;
		// check with base matrix
		if( !isConflictWithBaseMatrix(tempMatrix) )
		{
			for(int i = 0; i <= 17; i++)
			{
				for(int j = 0; j <= 9; j++)
				{
					// assign to movingMatrix
					xMatrix[i][j] = tempMatrix[i][j];
				}
			}
		}
	}
}
void moveMatrixRight(char xMatrix[18][10])
{
	// if matrix is not on rigth side
	if( !isObjectOnRightSide(xMatrix) )
	{
		char tempMatrix[18][10];
		// store data in temp matrix and move right
		for(int i = 0; i <= 17; i++)
		{
			for(int j = 1; j <= 9; j++)
			{
				tempMatrix[i][j] = xMatrix[i][j-1];
			}
		}
		// fill left side with 0
		for(int i = 0; i <= 17; i++)
			tempMatrix[i][0] = 0;
		// check with base matrix
		if( !isConflictWithBaseMatrix(tempMatrix) )
		{
			for(int i = 0; i <= 17; i++)
			{
				for(int j = 0; j <= 9; j++)
				{
					// assign to movingMatrix
					xMatrix[i][j] = tempMatrix[i][j];
				}
			}
		}
	}
}
void assignToMovingMatrix(char xMatrix[18][10])
{
	for(int i = 0; i <= 17; i++)
	{
		for(int j = 0; j <= 9; j++)
		{
			movingMatrix[i][j] = xMatrix[i][j];
		}
	}
}
void assignToNextMatrix(char xMatrix[3][4])
{
	for(int i = 0; i <= 2; i++)
	{
		for(int j = 0; j <= 3; j++)
		{
			nextMatrix[i][j] = xMatrix[i][j];
		}
	}
}
void assignToBaseMatrix(char xMatrix[18][10])
{
	for(int i = 0; i <= 17; i++)
	{
		for(int j = 0; j <= 9; j++)
		{
			if( xMatrix[i][j] != 0 )
				baseMatrix[i][j] = xMatrix[i][j];
		}
	}
}

void rotateMatrixLeft(char xMatrix[18][10])
{
	char x = 255;	// rotation point x
	char y = 255;	// rotation point y
	char v = 255;	// rotation point value
	// find rotation point
	for(int i = 0; i <= 17; i++)
	{
		for(int j = 0; j <= 9; j++)
		{
			if( xMatrix[i][j] >= 100 )
			{
				x = j;
				y = i;
				v = xMatrix[i][j];
				break;
				break;
			}
		}
	}
	// if finded rotation point
	if(x != 255)
	{
		// if rotation object is stick
		if( v == 101 )
		{
			char tempMatrix[18][10];
			// return if rotation point on left side
			if( x == 0 ) return;
			// return if rotation point on top
			if( y == 0 ) return;
			// return if rotation point on near right side 
			if( x >= 8 )
			{
				if( xMatrix[y+2][x] != 0 )
					return;
			}
			// return if rotation point on near bottom
			if( y > 15 ) return;
			// store data in temp matrix
			for(int i = 0; i <= 17; i++)
			{
				for(int j = 0; j <= 9; j++)
				{
					tempMatrix[i][j] = xMatrix[i][j];
				}
			}
			// rotate matrix
			char t;
			t = tempMatrix[y-1][x];
			tempMatrix[y-1][x] = tempMatrix[y][x-1];
			tempMatrix[y][x-1] = t;
			t = tempMatrix[y+1][x];
			tempMatrix[y+1][x] = tempMatrix[y][x+1];
			tempMatrix[y][x+1] = t;
			t = tempMatrix[y+2][x];
			tempMatrix[y+2][x] = tempMatrix[y][x+2];
			tempMatrix[y][x+2] = t;
			// check with base matrix
			if( !isConflictWithBaseMatrix(tempMatrix) )
			{
				for(int i = 0; i <= 17; i++)
				{
					for(int j = 0; j <= 9; j++)
					{
						xMatrix[i][j] = tempMatrix[i][j];
					}
				}
			}
		}
		// if rotation object is left foot nad right foot
		if( v == 103 || v == 104 || v == 105 || v == 106 || v == 107 )
		{
			char tempMatrix[18][10] = {0};
			// return if rotation point on left side
			if( x == 0 ) return;
			// return if rotation point on top
			if( y == 0 ) return;
			// return if rotation point on right side
			if( x == 9 ) return;
			// return if rotation point on bottom
			if( y == 17 ) return;
			// store data in temp matrix
			for(int i = 0; i <= 17; i++)
			{
				for(int j = 0; j <= 9; j++)
				{
					tempMatrix[i][j] = xMatrix[i][j];
				}
			}
			// rotate matrix
			char t;
			t = tempMatrix[y][x-1];
			tempMatrix[y][x-1] = tempMatrix[y-1][x];
			tempMatrix[y-1][x] = tempMatrix[y][x+1];
			tempMatrix[y][x+1] = tempMatrix[y+1][x];
			tempMatrix[y+1][x] = t;

			if( tempMatrix[y+1][x+1] != 0 )
			{
				tempMatrix[y-1][x+1] = tempMatrix[y+1][x+1];
				tempMatrix[y+1][x+1] = 0;
			}
			else if( tempMatrix[y-1][x+1] != 0 )
			{
				tempMatrix[y-1][x-1] = tempMatrix[y-1][x+1];
				tempMatrix[y-1][x+1] = 0;
			}
			else if( tempMatrix[y-1][x-1] != 0 )
			{
				tempMatrix[y+1][x-1] = tempMatrix[y-1][x-1];
				tempMatrix[y-1][x-1] = 0;
			}
			else if( tempMatrix[y+1][x-1] != 0 )
			{
				tempMatrix[y+1][x+1] = tempMatrix[y+1][x-1];
				tempMatrix[y+1][x-1] = 0;
			}
			// check with base matrix
			if( !isConflictWithBaseMatrix(tempMatrix) )
			{
				for(int i = 0; i <= 17; i++)
				{
					for(int j = 0; j <= 9; j++)
					{
						xMatrix[i][j] = tempMatrix[i][j];
					}
				}
			}
		}
	}
}


bool isObjectOnDown(char xMatrix[18][10])
{
	for(int j = 0; j <= 9; j++)
	{
		if ( xMatrix[17][j] != 0 )
		{
			return true;
		}
	}
	return false;
}

bool isObjectOnLeftSide (char xMatrix[18][10]) // return true if it is on the side
{
	for( int i = 0; i <= 17; i++ )
	{
		if( xMatrix[i][0] != 0 )
			return true;
	}
	return false;
}
bool isObjectOnRightSide (char xMatrix[18][10]) // return true if it is on the side
{
	for( int i = 0; i <= 17; i++ )
	{
		if( xMatrix[i][9] != 0 )
			return true;
	}
	return false;
}

void callNewObject(int current,int next)
{
	switch(current)
	{
	case 0:
		assignToMovingMatrix(stickMatrix);
		break;
	case 1:
		assignToMovingMatrix(boxMatrix);
		break;
	case 2:
		assignToMovingMatrix(rightFootMatrix);
		break;
	case 3:
		assignToMovingMatrix(leftZMatrix);
		break;
	case 4:
		assignToMovingMatrix(rightZMatrix);
		break;
	case 5:
		assignToMovingMatrix(rightFootMatrix);
		break;
	case 6:
		assignToMovingMatrix(tMatrix);
		break;
	case 7:
		assignToMovingMatrix(leftFootMatrix);
		break;
	}
	switch(next)
	{
	case 0:
		assignToNextMatrix(nextStickMatrix);
		break;
	case 1:
		assignToNextMatrix(nextBoxMatrix);
		break;
	case 2:
		assignToNextMatrix(nextRightFootMatrix);
		break;
	case 3:
		assignToNextMatrix(nextLeftZMatrix);
		break;
	case 4:
		assignToNextMatrix(nextRightZMatrix);
		break;
	case 5:
		assignToNextMatrix(nextRightFootMatrix);
		break;
	case 6:
		assignToNextMatrix(nextTMatrix);
		break;
	case 7:
		assignToNextMatrix(nextLeftFootMatrix);
		break;
	}
}
