#ifndef MATRIXES_H
#define MATRIXES_H

extern char nextMatrix[3][4];
extern char nextStickMatrix[3][4];
extern char nextBoxMatrix[3][4];
extern char nextLeftFootMatrix[3][4];
extern char nextRightFootMatrix[3][4];
extern char nextLeftZMatrix[3][4];
extern char nextRightZMatrix[3][4];
extern char nextTMatrix[3][4];

extern char baseMatrix[18][10];
extern char movingMatrix[18][10];
extern char stickMatrix[18][10];
extern char boxMatrix[18][10];
extern char leftFootMatrix[18][10];
extern char rightFootMatrix[18][10];
extern char leftZMatrix[18][10];
extern char rightZMatrix[18][10];
extern char tMatrix[18][10];


#endif /* MATRIXES_H */