function [ output_args ] = ANNProject( input_args )
%   
%   Huseyin Kozan
%   1306040082
%   
%   ANN Project
%   http://www.huseyinkozan.com.tr/files/sine_recognition.zip

% functions
%------------------------------------------------------
% sgn() : bipolar sigmoid function
sgn = @ (x) ( 2 ./ (1+exp(-x)) ) - 1;
% dsgn() : derivate of bipolar sigmoid function
dsgn = @ (x) ( .5 .* (1 - power(sgn(x),2)) );
% usgn() : unipolar sigmoid function
usgn = @ (x) ( 1 ./ (1+exp(-x)) );
% dusgn() : derivative of unipolar sigmoid function
dusgn = @ (x) ( usgn(x) .* (1-usgn(x)) );

% variables
%------------------------------------------------------
% J : first layer neuron number
J = 4;
% K : second layer neuron number
K = 5;
% N : sine wave sample's number
N = 40;
% t : learning steps
t = 1;
% z : input samples
z = sin (0 : (2*pi)/(N-1): 2*pi);
% d : supervisers desired response
d = z;
% W : weight of second layer
W = ones(K,J) * 0.001;
% v : weight of first layer
v = ones(J,1) * 0.001;

% learning process
%------------------------------------------------------
% loop for learning iteration
done = false;
while ~done
    
    t = t + 1;
    % loop for sine wave samples
    for n = 1:N 
        
        u = sgn(v*z(n));
        du = dsgn(v*z(n));
        g = W * u;
        % loop for last neuron
        for k = 1:K
            total_g = g(k);
        end
        o(n) = sgn(total_g);
        
        % loop for second layer delta
        for k = 1:K
            delta_g(k) = 0.5 * (d(n) - sgn(g(k))) * dsgn(g(k));
        end
        
        % loop for first layer delta
        for j = 1:J
            delta_u(j) = ( W(:,j)' * delta_g'  ) * du(j);
        end
        
        % update weights
        v = v + ( 0.1 * delta_u' * z(n) );
        W = W + ( 0.1 * delta_g' * u' );
        
    end % end sample's loop
    
    % save the values for visualization
    G(:,t) = o';
    V(:,t) = v';
    W1(:,t) = W(:,1)';
    
    % learning check
    if ( norm(z-o,inf) < .25 )
        done = true;
    end
    
end % end while

% learning test process
%------------------------------------------------------
f1 = figure(1); set(f1,'Name','Test Process','NumberTitle','off');

% noisy sine
subplot(2,2,1);
h = sin(0:(2*pi)/(N-1):2*pi);
h = h + (randn(1,40));
plot(1:N,h);
title('Noisy Sine'); xlabel('Samples'); ylabel('In Values');
if (norm(h-o,inf) < 1)
    text(N/4,0,'Result: Sine');
else
    text(N/4,0,'Result: NOT Sine');
end

% noisy Sine
subplot(2,2,2);
l = sin(0:(2*pi)/(N-1):2*pi);
l = l + (randn(1,40)*0.1);
plot( 1:N,l );
title('Noisy Sine'); xlabel('Samples'); ylabel('In Values');
if (norm(l-o,inf) < 1)
    text(N/4,0,'Result: Sine');
else
    text(N/4,0,'Result: NOT Sine');
end

% sine wave
subplot(2,2,3);
s = sin(0:(2*pi)/(N-1):2*pi);
s = s .* 0.1;
plot( 1:N,s );
title('Sine'); xlabel('Samples'); ylabel('In Values');
if (norm(s-o,inf)<1) 
    text(N/4,0,'Result: Sine');
else
    text(N/4,0,'Result: NOT Sine');
end

% cosine wave
subplot(2,2,4);
c = cos(0:(2*pi)/(N-1):2*pi);
plot( 1:N,c );
title('Cosine'); xlabel('Samples'); ylabel('In Values');
if (norm(c-o,inf)<1) 
    text(N/4,0,'Result: Sine');
else
    text(N/4,0,'Result: NOT Sine');
end

% visualization process
%------------------------------------------------------
f2 = figure(2); set(f2,'Name','Visualization Process','NumberTitle','off');

% input
subplot(2,2,1);
plot(1:N,z);
title('Input'); xlabel('Samples'); ylabel('In Values');

% output
subplot(2,2,2);
mesh(1:t,1:N,G);
title('Output'); 
xlabel('Iteration'); ylabel('Samples'); zlabel('Out Values');

% first layer weights
subplot(2,2,3);
mesh(1:t,1:J,V);
title('First Layer Weights');
xlabel('Iteration'); ylabel('Neurons'); zlabel('Weights');

% second layer weights
subplot(2,2,4);
mesh(1:t,1:K,W1);
title('Second Layer, Firts Input Weights');
xlabel('Iteration'); ylabel('Neurons'); zlabel('Wights');

