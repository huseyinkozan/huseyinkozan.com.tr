% hh model, by mustafa dagtekin
clear;
vna =   50;
vk  =   -77;
vl  =   -54.4;

gna =   120;
gk  =   36;
gl  =   0.3;

m   =   0.053;
h   =   0.6;
n   =   0.32;

c   =   1;
i   =   0;
v   =   -55.1;

delta_t =   0.001;

varray(1)   =   v;

for t   =   2:5000,
    am  =   (0.1)*(v+40)/(1-exp(-(v+40)/10));
    bm  =   4*exp(-(v+65)/18);
    ah  =   (0.07)*exp(-(v+65)/20);
    bh  =   1/(1+exp(-(v+35)/10));
    an  =   (0.01)*(v+55)/(1-exp(-(v+55)/10));
    bn  =   (0.125)*exp(-(v+65)/80);
    
    m   =   m + (am*(1-m)-bm*m)*delta_t;
    h   =   h + (ah*(1-h)-bh*h)*delta_t;
    n   =   n + (an*(1-n)-bn*n)*delta_t;
    
    v   =   varray(t-1) + ((i-gna*h*(v-vna)*m^3-gk*(v-vk)*n^4-gl*(v-vl))/c)*delta_t;
    varray(t)   =   v;
end

plot(1:t:5000*t,varray);