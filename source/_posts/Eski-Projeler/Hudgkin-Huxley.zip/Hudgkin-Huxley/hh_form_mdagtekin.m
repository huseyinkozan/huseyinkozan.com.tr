function varargout = hh_form_mdagtekin(varargin)
% HH_FORM_MDAGTEKIN M-file for hh_form_mdagtekin.fig
%      HH_FORM_MDAGTEKIN, by itself, creates a new HH_FORM_MDAGTEKIN or raises the existing
%      singleton*.
%
%      H = HH_FORM_MDAGTEKIN returns the handle to a new HH_FORM_MDAGTEKIN or the handle to
%      the existing singleton*.
%
%      HH_FORM_MDAGTEKIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HH_FORM_MDAGTEKIN.M with the given input arguments.
%
%      HH_FORM_MDAGTEKIN('Property','Value',...) creates a new HH_FORM_MDAGTEKIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before hh_form_mdagtekin_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to hh_form_mdagtekin_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help hh_form_mdagtekin

% Last Modified by GUIDE v2.5 29-Jul-2008 21:28:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @hh_form_mdagtekin_OpeningFcn, ...
                   'gui_OutputFcn',  @hh_form_mdagtekin_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before hh_form_mdagtekin is made visible.
function hh_form_mdagtekin_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to hh_form_mdagtekin (see VARARGIN)
file = 'hh_form_mdagtekin_settings.mat';
if exist(file) == 2
    s = load(file);
    handles.s = s;
    guidata(hObject,handles);
else
     errordlg('Not a valid settings file, should be : hh_form_mdagtekin_settings.mat','File Load Error');
     close(hh_figure);
end
% set components values from file 
% -------------------------------
set( handles.vt_axes_max_y_edit, 'String', num2str(s.vt_axes_max_y));
set( handles.vt_axes_min_y_edit, 'String', num2str(s.vt_axes_min_y));
set( handles.vt_axes_max_x_edit, 'String', num2str(s.vt_axes_max_x));

set( handles.vna_min_edit, 'String', num2str(s.vna_min_edit));
set( handles.vna_max_edit, 'String', num2str(s.vna_max_edit));
set( handles.vna_value_edit, 'String', num2str(s.vna_value));

set( handles.vk_min_edit, 'String', num2str(s.vk_min_edit));
set( handles.vk_max_edit, 'String', num2str(s.vk_max_edit));
set( handles.vk_value_edit, 'String', num2str(s.vk_value));

set( handles.vl_min_edit, 'String', num2str(s.vl_min_edit));
set( handles.vl_max_edit, 'String', num2str(s.vl_max_edit));
set( handles.vl_value_edit, 'String', num2str(s.vl_value));

set( handles.v_min_edit, 'String', num2str(s.v_min_edit));
set( handles.v_max_edit, 'String', num2str(s.v_max_edit));
set( handles.v_value_edit, 'String', num2str(s.v_value));

set( handles.c_min_edit, 'String', num2str(s.c_min_edit));
set( handles.c_max_edit, 'String', num2str(s.c_max_edit));
set( handles.c_value_edit, 'String', num2str(s.c_value));

set( handles.i_min_edit, 'String', num2str(s.i_min_edit));
set( handles.i_max_edit, 'String', num2str(s.i_max_edit));
set( handles.i_value_edit, 'String', num2str(s.i_value));

set( handles.gna_min_edit, 'String', num2str(s.gna_min_edit));
set( handles.gna_max_edit, 'String', num2str(s.gna_max_edit));
set( handles.gna_value_edit, 'String', num2str(s.gna_value));

set( handles.gk_min_edit, 'String', num2str(s.gk_min_edit));
set( handles.gk_max_edit, 'String', num2str(s.gk_max_edit));
set( handles.gk_value_edit, 'String', num2str(s.gk_value));

set( handles.gl_min_edit, 'String', num2str(s.gl_min_edit));
set( handles.gl_max_edit, 'String', num2str(s.gl_max_edit));
set( handles.gl_value_edit, 'String', num2str(s.gl_value));

set( handles.m_min_edit, 'String', num2str(s.m_min_edit));
set( handles.m_max_edit, 'String', num2str(s.m_max_edit));
set( handles.m_value_edit, 'String', num2str(s.m_value));

set( handles.h_min_edit, 'String', num2str(s.h_min_edit));
set( handles.h_max_edit, 'String', num2str(s.h_max_edit));
set( handles.h_value_edit, 'String', num2str(s.h_value));

set( handles.n_min_edit, 'String', num2str(s.n_min_edit));
set( handles.n_max_edit, 'String', num2str(s.n_max_edit));
set( handles.n_value_edit, 'String', num2str(s.n_value));

set( handles.delta_min_edit, 'String', num2str(s.delta_min_edit));
set( handles.delta_max_edit, 'String', num2str(s.delta_max_edit));
set( handles.delta_value_edit, 'String', num2str(s.delta_value));

set( handles.vna_slider, 'Min', s.vna_slider_min);
set( handles.vna_slider, 'Max', s.vna_slider_max);
set( handles.vna_slider, 'Value', s.vna_slider);

set( handles.vk_slider, 'Min', s.vk_slider_min);
set( handles.vk_slider, 'Max', s.vk_slider_max);
set( handles.vk_slider, 'Value', s.vk_slider);

set( handles.vl_slider, 'Min', s.vl_slider_min);
set( handles.vl_slider, 'Max', s.vl_slider_max);
set( handles.vl_slider, 'Value', s.vl_slider);

set( handles.v_slider, 'Min', s.v_slider_min);
set( handles.v_slider, 'Max', s.v_slider_max);
set( handles.v_slider, 'Value', s.v_slider);

set( handles.c_slider, 'Min', s.c_slider_min);
set( handles.c_slider, 'Max', s.c_slider_max);
set( handles.c_slider, 'Value', s.c_slider);

set( handles.i_slider, 'Min', s.i_slider_min);
set( handles.i_slider, 'Max', s.i_slider_max);
set( handles.i_slider, 'Value', s.i_slider);

set( handles.gna_slider, 'Min', s.gna_slider_min);
set( handles.gna_slider, 'Max', s.gna_slider_max);
set( handles.gna_slider, 'Value', s.gna_slider);

set( handles.gk_slider, 'Min', s.gk_slider_min);
set( handles.gk_slider, 'Max', s.gk_slider_max);
set( handles.gk_slider, 'Value', s.gk_slider);

set( handles.gl_slider, 'Min', s.gl_slider_min);
set( handles.gl_slider, 'Max', s.gl_slider_max);
set( handles.gl_slider, 'Value', s.gl_slider);

set( handles.m_slider, 'Min', s.m_slider_min);
set( handles.m_slider, 'Max', s.m_slider_max);
set( handles.m_slider, 'Value', s.m_slider);

set( handles.h_slider, 'Min', s.h_slider_min);
set( handles.h_slider, 'Max', s.h_slider_max);
set( handles.h_slider, 'Value', s.h_slider);

set( handles.n_slider, 'Min', s.n_slider_min);
set( handles.n_slider, 'Max', s.n_slider_max);
set( handles.n_slider, 'Value', s.n_slider);

set( handles.delta_slider, 'Min', s.delta_slider_min);
set( handles.delta_slider, 'Max', s.delta_slider_max);
set( handles.delta_slider, 'Value', s.delta_slider);

set( handles.grid_togglebutton, 'Value', s.grid_togglebutton);
set( handles.datacursor_togglebutton, 'Value', s.datacursor_togglebutton);
set( handles.progressbar_checkbox, 'Value', s.progressbar_checkbox);

set( handles.i_na_checkbox, 'Value', s.i_na_checkbox);
set( handles.i_k_checkbox, 'Value', s.i_k_checkbox);
set( handles.i_l_checkbox, 'Value', s.i_l_checkbox);

set( handles.g_na_checkbox, 'Value', s.g_na_checkbox);
set( handles.g_k_checkbox, 'Value', s.g_k_checkbox);
set( handles.g_l_checkbox, 'Value', s.g_l_checkbox);

set( handles.v_checkbox, 'Value', s.v_checkbox);
set( handles.plot_after_change_checkbox, 'Value', s.plot_after_change_checkbox);

% Choose default command line output for hh_form_mdagtekin
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes hh_form_mdagtekin wait for user response (see UIRESUME)
% uiwait(handles.hh_figure);


% --- Outputs from this function are returned to the command line.
function varargout = hh_form_mdagtekin_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function hh_figure_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hh_figure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function vt_axes_max_y_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vt_axes_max_y_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes during object creation, after setting all properties.
function vt_axes_min_y_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vt_axes_min_y_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function vt_axes_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vt_axes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate vt_axes


% --- Executes during object creation, after setting all properties.
function vt_axes_max_x_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vt_axes_max_x_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function values_CreateFcn(hObject, eventdata, handles)
% hObject    handle to values (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function delta_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delta_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



% --- Executes during object creation, after setting all properties.
function delta_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delta_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function delta_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delta_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function delta_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delta_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function delta_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delta_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function grid_togglebutton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to grid_togglebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function plot_pushbutton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plot_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function close_pushbutton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to close_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function potentials_CreateFcn(hObject, eventdata, handles)
% hObject    handle to potentials (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function conductivities_CreateFcn(hObject, eventdata, handles)
% hObject    handle to conductivities (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function membrane_CreateFcn(hObject, eventdata, handles)
% hObject    handle to membrane (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function probabilities_CreateFcn(hObject, eventdata, handles)
% hObject    handle to probabilities (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function vna_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vna_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function vna_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vna_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function vna_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vna_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function vna_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vna_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function vna_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vna_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function vk_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vk_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function vk_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vk_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function vk_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vk_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function vk_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vk_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function vk_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vk_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function vl_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vl_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function vl_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vl_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function vl_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vl_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function vl_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vl_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function vl_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vl_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function gna_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gna_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function gna_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gna_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function gna_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gna_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function gna_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gna_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function gna_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gna_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function gk_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gk_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function gk_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gk_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function gk_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gk_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function gk_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gk_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function gk_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gk_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function gl_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gl_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function gl_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gl_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function gl_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gl_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function gl_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gl_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function gl_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gl_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function v_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to v_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function v_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to v_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function v_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to v_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function v_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to v_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function v_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to v_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function c_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to c_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function c_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to c_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function c_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to c_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function c_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to c_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function c_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to c_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function i_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to i_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function i_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to i_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function i_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to i_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function i_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to i_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function i_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to i_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function m_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to m_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function m_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to m_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function m_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to m_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function m_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to m_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function m_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to m_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function h_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function h_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function h_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function h_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function h_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function n_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function n_min_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function n_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function n_max_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function n_value_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in close_pushbutton.
function close_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to close_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

close();


% --- Executes on button press in grid_togglebutton.
function grid_togglebutton_Callback(hObject, eventdata, handles)
% hObject    handle to grid_togglebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of grid_togglebutton

button_state = get(hObject,'Value');
if button_state == get(hObject,'Max')
    % toggle button is pressed
    grid on;
    set(handles.vt_axes,'XGrid','on');
    set(handles.vt_axes,'YGrid','on');
    set(handles.vt_axes,'XMinorGrid','on');
    set(handles.vt_axes,'YMinorGrid','on');
elseif button_state == get(hObject,'Min')
    % toggle button is not pressed
    grid off;
end



function vt_axes_max_y_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vt_axes_max_y_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vt_axes_max_y_edit as text
%        str2double(get(hObject,'String')) returns contents of vt_axes_max_y_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    min_val = str2double(get(handles.vt_axes_min_y_edit,'String'));
    set(handles.vt_axes,'YLim',[min_val val]);
end


function vt_axes_min_y_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vt_axes_min_y_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vt_axes_min_y_edit as text
%        str2double(get(hObject,'String')) returns contents of vt_axes_min_y_edit as a double

val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    max_val = str2double(get(handles.vt_axes_max_y_edit,'String'));
    set(handles.vt_axes,'YLim',[val max_val]);
end


function vt_axes_max_x_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vt_axes_max_x_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vt_axes_max_x_edit as text
%        str2double(get(hObject,'String')) returns contents of vt_axes_max_x_edit as a double

val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.vt_axes,'XLim',[0 val]);
end


function vna_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vna_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vna_min_edit as text
%        str2double(get(hObject,'String')) returns contents of vna_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.vna_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.vna_slider,'Min')));
end


% --- Executes on slider movement.
function vna_slider_Callback(hObject, eventdata, handles)
% hObject    handle to vna_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.vna_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))
    plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles);
end

% --- Executes on button press in plot_pushbutton.
function plot_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to plot_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vna =   str2double(get(handles.vna_value_edit,'String'));% * 1e-3;
vk  =   str2double(get(handles.vk_value_edit,'String'));% * 1e-3;
vl  =   str2double(get(handles.vl_value_edit,'String'));% * 1e-3;
gna =   str2double(get(handles.gna_value_edit,'String'));
gk  =   str2double(get(handles.gk_value_edit,'String'));
gl  =   str2double(get(handles.gl_value_edit,'String'));
m   =   str2double(get(handles.m_value_edit,'String'));
h   =   str2double(get(handles.h_value_edit,'String'));
n   =   str2double(get(handles.n_value_edit,'String'));
c   =   str2double(get(handles.c_value_edit,'String'));% * 1e-2;
i   =   str2double(get(handles.i_value_edit,'String'));% * 1e-2;
v   =   str2double(get(handles.v_value_edit,'String'));% * 1e-3;
delta_t =   str2double(get(handles.delta_value_edit,'String'));
varray(1)   =   v;
ina_array(1)=   0.001;
ik_array(1) =   0.001;
il_array(1) =   0.001;

gna_array(1)=   0.001;
gk_array(1) =   0.001;
gl_array(1) =   0.001;
max_x_val = str2double(get(handles.vt_axes_max_x_edit,'String'));

for t   =   2:max_x_val,
    am  =   (0.1)*(v+40)/(1-exp(-(v+40)/10));
    bm  =   0.108*exp(-v/18);
    ah  =   0.0027*exp(-v/20);
    bh  =   1/(1+exp(-(v+35)/10));
    an  =   (0.01)*(v+55)/(1-exp(-(v+55)/10)+eps); % divide by zero
    bn  =   0.0555*exp(-v/80);
    
    m   =   m + (am*(1-m)-bm*m)*delta_t;
    h   =   h + (ah*(1-h)-bh*h)*delta_t;
    n   =   n + (an*(1-n)-bn*n)*delta_t;
    
    gna_array(t-1) =   (gna*(m^3)*h);
    gk_array(t-1) =   (gk*(n^4));
    gl_array(t-1) =   gl;
    
    ina_array(t-1)  =   gna_array(t-1) * (v-vna); 
    ik_array(t-1)   =   gk_array(t-1) * (v-vk);
    il_array(t-1)   =   gl_array(t-1) * (v-vl);
    v   =   varray(t-1) + (( i -  ina_array(t-1) - ik_array(t-1) - il_array(t-1) )/(c+eps))*delta_t;
    varray(t)   =   v;
    if get(handles.progressbar_checkbox,'Value') == ...
            get(handles.progressbar_checkbox,'Max')
                stopBar = progressbar(t/max_x_val,0); 
                if (stopBar) break; end 
    end
end
cla
hold on
if (get(handles.v_checkbox,'Value') == get(handles.v_checkbox,'Max'))
    plot(1:max_x_val,varray-1,'k');
end
if (get(handles.i_na_checkbox,'Value') == get(handles.i_na_checkbox,'Max'))
    plot(1:max_x_val-1,ina_array,'r');
end
if (get(handles.i_k_checkbox,'Value') == get(handles.i_k_checkbox,'Max'))
    plot(1:max_x_val-1,ik_array,'g');
end
if (get(handles.i_l_checkbox,'Value') == get(handles.i_l_checkbox,'Max'))
    plot(1:max_x_val-1,il_array,'b');
end
if (get(handles.g_na_checkbox,'Value') == get(handles.g_na_checkbox,'Max'))
    plot(1:max_x_val-1, gna_array, 'r:');
end
if (get(handles.g_k_checkbox,'Value') == get(handles.g_k_checkbox,'Max'))
    plot(1:max_x_val-1,gk_array,'g:');
end
if (get(handles.g_l_checkbox,'Value') == get(handles.g_l_checkbox,'Max'))
    plot(1:max_x_val-1,gl_array,'b:');
end



max_val = str2double(get(handles.vt_axes_max_y_edit,'String'));
min_val = str2double(get(handles.vt_axes_min_y_edit,'String'));
set(handles.vt_axes,'YLim',[min_val max_val]);
set(handles.vt_axes,'XLim',[0 max_x_val]);

if get(handles.grid_togglebutton,'Value') == ...
        get(handles.grid_togglebutton,'Max')
    grid on
    set(handles.vt_axes,'XGrid','on');
    set(handles.vt_axes,'YGrid','on');
    set(handles.vt_axes,'XMinorGrid','on');
    set(handles.vt_axes,'YMinorGrid','on');
elseif get(handles.grid_togglebutton,'Value') == ...
        get(handles.grid_togglebutton,'Min')
    grid off
end
if get(handles.datacursor_togglebutton,'Value') == ...
        get(handles.datacursor_togglebutton,'Max')
    datacursormode on
elseif get(handles.datacursor_togglebutton,'Value') == ...
        get(handles.datacursor_togglebutton,'Min')
    datacursormode off
end


% --- Executes on button press in datacursor_togglebutton.
function datacursor_togglebutton_Callback(hObject, eventdata, handles)
% hObject    handle to datacursor_togglebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of datacursor_togglebutton
button_state = get(hObject,'Value');
if button_state == get(hObject,'Max')
    % toggle button is pressed
    datacursormode on;
elseif button_state == get(hObject,'Min')
    % toggle button is not pressed
    datacursormode off;
end


% --- Executes when user attempts to close hh_figure.
function hh_figure_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to hh_figure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% save value to struct
% --------------------
s = handles.s;

s.vt_axes_max_y = str2double(get(handles.vt_axes_max_y_edit ,'String'));
s.vt_axes_min_y = str2double(get(handles.vt_axes_min_y_edit ,'String'));
s.vt_axes_max_x = str2double(get(handles.vt_axes_max_x_edit ,'String'));

s.vna_min_edit = str2double(get(handles.vna_min_edit ,'String'));
s.vna_max_edit = str2double(get(handles.vna_max_edit ,'String'));
s.vna_value = str2double(get(handles.vna_value_edit ,'String'));

s.vk_min_edit = str2double(get(handles.vk_min_edit ,'String'));
s.vk_max_edit = str2double(get(handles.vk_max_edit ,'String'));
s.vk_value = str2double(get(handles.vk_value_edit ,'String'));

s.vl_min_edit = str2double(get(handles.vl_min_edit ,'String'));
s.vl_max_edit = str2double(get(handles.vl_max_edit ,'String'));
s.vl_value = str2double(get(handles.vl_value_edit ,'String'));

s.v_min_edit = str2double(get(handles.v_min_edit ,'String'));
s.v_max_edit = str2double(get(handles.v_max_edit ,'String'));
s.v_value = str2double(get(handles.v_value_edit ,'String'));

s.c_min_edit = str2double(get(handles.c_min_edit ,'String'));
s.c_max_edit = str2double(get(handles.c_max_edit ,'String'));
s.c_value = str2double(get(handles.c_value_edit ,'String'));

s.i_min_edit = str2double(get(handles.i_min_edit ,'String'));
s.i_max_edit = str2double(get(handles.i_max_edit ,'String'));
s.i_value = str2double(get(handles.i_value_edit ,'String'));

s.gna_min_edit = str2double(get(handles.gna_min_edit ,'String'));
s.gna_max_edit = str2double(get(handles.gna_max_edit ,'String'));
s.gna_value = str2double(get(handles.gna_value_edit ,'String'));

s.gk_min_edit = str2double(get(handles.gk_min_edit ,'String'));
s.gk_max_edit = str2double(get(handles.gk_max_edit ,'String'));
s.gk_value = str2double(get(handles.gk_value_edit ,'String'));

s.gl_min_edit = str2double(get(handles.gl_min_edit ,'String'));
s.gl_max_edit = str2double(get(handles.gl_max_edit ,'String'));
s.gl_value = str2double(get(handles.gl_value_edit ,'String'));

s.m_min_edit = str2double(get(handles.m_min_edit ,'String'));
s.m_max_edit = str2double(get(handles.m_max_edit ,'String'));
s.m_value = str2double(get(handles.m_value_edit ,'String'));

s.h_min_edit = str2double(get(handles.h_min_edit ,'String'));
s.h_max_edit = str2double(get(handles.h_max_edit ,'String'));
s.h_value = str2double(get(handles.h_value_edit ,'String'));

s.n_min_edit = str2double(get(handles.n_min_edit ,'String'));
s.n_max_edit = str2double(get(handles.n_max_edit ,'String'));
s.n_value = str2double(get(handles.n_value_edit ,'String'));

s.delta_min_edit = str2double(get(handles.delta_min_edit ,'String'));
s.delta_max_edit = str2double(get(handles.delta_max_edit ,'String'));
s.delta_value = str2double(get(handles.delta_value_edit ,'String'));

s.vna_slider = get(handles.vna_slider,'Value');
s.vna_slider_min = get(handles.vna_slider,'Min');
s.vna_slider_max = get(handles.vna_slider,'Max');

s.vk_slider = get(handles.vk_slider,'Value');
s.vk_slider_min = get(handles.vk_slider,'Min');
s.vk_slider_max = get(handles.vk_slider,'Max');

s.vl_slider = get(handles.vl_slider,'Value');
s.vl_slider_min = get(handles.vl_slider,'Min');
s.vl_slider_max = get(handles.vl_slider,'Max');

s.v_slider = get(handles.v_slider,'Value');
s.v_slider_min = get(handles.v_slider,'Min');
s.v_slider_max = get(handles.v_slider,'Max');

s.c_slider = get(handles.c_slider,'Value');
s.c_slider_min = get(handles.c_slider,'Min');
s.c_slider_max = get(handles.c_slider,'Max');

s.i_slider = get(handles.i_slider,'Value');
s.i_slider_min = get(handles.i_slider,'Min');
s.i_slider_max = get(handles.i_slider,'Max');

s.gna_slider = get(handles.gna_slider,'Value');
s.gna_slider_min = get(handles.gna_slider,'Min');
s.gna_slider_max = get(handles.gna_slider,'Max');

s.gk_slider = get(handles.gk_slider,'Value');
s.gk_slider_min = get(handles.gk_slider,'Min');
s.gk_slider_max = get(handles.gk_slider,'Max');

s.gl_slider = get(handles.gl_slider,'Value');
s.gl_slider_min = get(handles.gl_slider,'Min');
s.gl_slider_max = get(handles.gl_slider,'Max');

s.m_slider = get(handles.m_slider,'Value');
s.m_slider_min = get(handles.m_slider,'Min');
s.m_slider_max = get(handles.m_slider,'Max');

s.h_slider = get(handles.h_slider,'Value');
s.h_slider_min = get(handles.h_slider,'Min');
s.h_slider_max = get(handles.h_slider,'Max');

s.n_slider = get(handles.n_slider,'Value');
s.n_slider_min = get(handles.n_slider,'Min');
s.n_slider_max = get(handles.n_slider,'Max');

s.delta_slider = get(handles.delta_slider,'Value');
s.delta_slider_min = get(handles.delta_slider,'Min');
s.delta_slider_max = get(handles.delta_slider,'Max');

s.grid_togglebutton = get(handles.grid_togglebutton,'Value');
s.datacursor_togglebutton = get(handles.datacursor_togglebutton,'Value');
s.progressbar_checkbox = get(handles.progressbar_checkbox,'Value');

s.i_na_checkbox = get(handles.i_na_checkbox,'Value');
s.i_k_checkbox = get(handles.i_k_checkbox,'Value');
s.i_l_checkbox = get(handles.i_l_checkbox,'Value');

s.g_na_checkbox = get(handles.g_na_checkbox,'Value');
s.g_k_checkbox = get(handles.g_k_checkbox,'Value');
s.g_l_checkbox = get(handles.g_l_checkbox,'Value');

s.v_checkbox = get(handles.v_checkbox,'Value');
s.plot_after_change_checkbox = get(handles.plot_after_change_checkbox,'Value');



handles.s = s;
guidata(hObject,handles);

s = handles.s;
save hh_form_mdagtekin_settings -struct s;
guidata(hObject,handles);

% Hint: delete(hObject) closes the figure
delete(hObject);



function vna_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vna_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vna_value_edit as text
%        str2double(get(hObject,'String')) returns contents of vna_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.vna_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.vna_slider,'Value')));
end
plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles);


function vk_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vk_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vk_value_edit as text
%        str2double(get(hObject,'String')) returns contents of vk_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.vk_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.vk_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end

function v_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to v_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of v_value_edit as text
%        str2double(get(hObject,'String')) returns contents of v_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.v_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.v_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


function c_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to c_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of c_value_edit as text
%        str2double(get(hObject,'String')) returns contents of c_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.c_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.c_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


function i_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to i_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of i_value_edit as text
%        str2double(get(hObject,'String')) returns contents of i_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.i_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.i_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


function delta_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to delta_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of delta_value_edit as text
%        str2double(get(hObject,'String')) returns contents of delta_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.delta_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.delta_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


function gna_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to gna_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gna_value_edit as text
%        str2double(get(hObject,'String')) returns contents of gna_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.gna_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.gna_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


function gk_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to gk_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gk_value_edit as text
%        str2double(get(hObject,'String')) returns contents of gk_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.gk_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.gk_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


function gl_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to gl_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gl_value_edit as text
%        str2double(get(hObject,'String')) returns contents of gl_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.gl_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.gl_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


function m_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to m_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of m_value_edit as text
%        str2double(get(hObject,'String')) returns contents of m_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.m_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.m_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


function n_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to n_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of n_value_edit as text
%        str2double(get(hObject,'String')) returns contents of n_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.n_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.n_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end



function vl_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vl_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vl_value_edit as text
%        str2double(get(hObject,'String')) returns contents of vl_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.vl_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.vl_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


function vk_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vk_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vk_min_edit as text
%        str2double(get(hObject,'String')) returns contents of vk_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.vk_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.vk_slider,'Min')));
end



function vl_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vl_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vl_min_edit as text
%        str2double(get(hObject,'String')) returns contents of vl_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.vl_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.vl_slider,'Min')));
end



function v_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to v_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of v_min_edit as text
%        str2double(get(hObject,'String')) returns contents of v_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.v_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.v_slider,'Min')));
end



function c_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to c_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of c_min_edit as text
%        str2double(get(hObject,'String')) returns contents of c_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.c_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.c_slider,'Min')));
end



function i_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to i_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of i_min_edit as text
%        str2double(get(hObject,'String')) returns contents of i_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.i_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.i_slider,'Min')));
end



function gna_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to gna_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gna_min_edit as text
%        str2double(get(hObject,'String')) returns contents of gna_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.gna_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.gna_slider,'Min')));
end



function gk_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to gk_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gk_min_edit as text
%        str2double(get(hObject,'String')) returns contents of gk_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.gk_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.gk_slider,'Min')));
end



function gl_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to gl_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gl_min_edit as text
%        str2double(get(hObject,'String')) returns contents of gl_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.gl_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.gl_slider,'Min')));
end



function m_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to m_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of m_min_edit as text
%        str2double(get(hObject,'String')) returns contents of m_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.m_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.m_slider,'Min')));
end



function h_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to h_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_min_edit as text
%        str2double(get(hObject,'String')) returns contents of h_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.h_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.h_slider,'Min')));
end



function n_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to n_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of n_min_edit as text
%        str2double(get(hObject,'String')) returns contents of n_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.n_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.n_slider,'Min')));
end



function delta_min_edit_Callback(hObject, eventdata, handles)
% hObject    handle to delta_min_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of delta_min_edit as text
%        str2double(get(hObject,'String')) returns contents of delta_min_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.delta_slider,'Min',val);
else
    set(hObject,'String',num2str(get(handles.delta_slider,'Min')));
end


function vna_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vna_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vna_max_edit as text
%        str2double(get(hObject,'String')) returns contents of vna_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.vna_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.vna_slider,'Max')));
end



function vk_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vk_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vk_max_edit as text
%        str2double(get(hObject,'String')) returns contents of vk_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.vk_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.vk_slider,'Max')));
end



function vl_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vl_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vl_max_edit as text
%        str2double(get(hObject,'String')) returns contents of vl_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.vl_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.vl_slider,'Max')));
end



function v_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to v_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of v_max_edit as text
%        str2double(get(hObject,'String')) returns contents of v_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.v_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.v_slider,'Max')));
end



function c_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to c_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of c_max_edit as text
%        str2double(get(hObject,'String')) returns contents of c_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.c_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.c_slider,'Max')));
end



function i_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to i_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of i_max_edit as text
%        str2double(get(hObject,'String')) returns contents of i_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.i_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.i_slider,'Max')));
end



function gna_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to gna_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gna_max_edit as text
%        str2double(get(hObject,'String')) returns contents of gna_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.gna_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.gna_slider,'Max')));
end



function gk_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to gk_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gk_max_edit as text
%        str2double(get(hObject,'String')) returns contents of gk_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.gk_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.gk_slider,'Max')));
end



function gl_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to gl_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gl_max_edit as text
%        str2double(get(hObject,'String')) returns contents of gl_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.gl_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.gl_slider,'Max')));
end



function m_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to m_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of m_max_edit as text
%        str2double(get(hObject,'String')) returns contents of m_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.m_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.m_slider,'Max')));
end



function h_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to h_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_max_edit as text
%        str2double(get(hObject,'String')) returns contents of h_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.h_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.h_slider,'Max')));
end



function n_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to n_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of n_max_edit as text
%        str2double(get(hObject,'String')) returns contents of n_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.n_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.n_slider,'Max')));
end



function delta_max_edit_Callback(hObject, eventdata, handles)
% hObject    handle to delta_max_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of delta_max_edit as text
%        str2double(get(hObject,'String')) returns contents of delta_max_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.delta_slider,'Max',val);
else
    set(hObject,'String',num2str(get(handles.delta_slider,'Max')));
end



function h_value_edit_Callback(hObject, eventdata, handles)
% hObject    handle to h_value_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_value_edit as text
%        str2double(get(hObject,'String')) returns contents of h_value_edit as a double
val = str2double(get(hObject,'String'));
if isnumeric(val) & length(val) == 1
    set(handles.h_slider,'Value',val);
else
    set(hObject,'String',num2str(get(handles.h_slider,'Value')));
end
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function vk_slider_Callback(hObject, eventdata, handles)
% hObject    handle to vk_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.vk_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function vl_slider_Callback(hObject, eventdata, handles)
% hObject    handle to vl_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.vl_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function v_slider_Callback(hObject, eventdata, handles)
% hObject    handle to v_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.v_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function c_slider_Callback(hObject, eventdata, handles)
% hObject    handle to c_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.c_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function i_slider_Callback(hObject, eventdata, handles)
% hObject    handle to i_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.i_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function delta_slider_Callback(hObject, eventdata, handles)
% hObject    handle to delta_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.delta_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function gna_slider_Callback(hObject, eventdata, handles)
% hObject    handle to gna_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.gna_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function gk_slider_Callback(hObject, eventdata, handles)
% hObject    handle to gk_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.gk_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function gl_slider_Callback(hObject, eventdata, handles)
% hObject    handle to gl_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.gl_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function m_slider_Callback(hObject, eventdata, handles)
% hObject    handle to m_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.m_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function h_slider_Callback(hObject, eventdata, handles)
% hObject    handle to h_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.h_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on slider movement.
function n_slider_Callback(hObject, eventdata, handles)
% hObject    handle to n_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
set(handles.n_value_edit,'String',num2str(get(hObject,'Value')));
if (get(handles.plot_after_change_checkbox,'Value') == get(handles.plot_after_change_checkbox,'Max'))     plot_pushbutton_Callback(handles.plot_pushbutton, eventdata, handles); end


% --- Executes on button press in progressbar_checkbox.
function progressbar_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to progressbar_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of progressbar_checkbox
button_state = get(hObject,'Value');
if button_state == get(hObject,'Max')
    % toggle button is pressed
    handles.progressbar = 1;
elseif button_state == get(hObject,'Min')
    % toggle button is not pressed
    handles.progressbar = 0;
end
guidata(hObject,handles);



function graph_resolution_edit_Callback(hObject, eventdata, handles)
% hObject    handle to graph_resolution_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of graph_resolution_edit as text
%        str2double(get(hObject,'String')) returns contents of graph_resolution_edit as a double


% --- Executes during object creation, after setting all properties.
function graph_resolution_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to graph_resolution_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in i_na_checkbox.
function i_na_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to i_na_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of i_na_checkbox


% --- Executes on button press in i_k_checkbox.
function i_k_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to i_k_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of i_k_checkbox


% --- Executes on button press in i_l_checkbox.
function i_l_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to i_l_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of i_l_checkbox


% --- Executes on button press in plot_after_change_checkbox.
function plot_after_change_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to plot_after_change_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of plot_after_change_checkbox


% --- Executes on button press in v_checkbox.
function v_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to v_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of v_checkbox


% --- Executes on button press in g_na_checkbox.
function g_na_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to g_na_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of g_na_checkbox


% --- Executes on button press in g_k_checkbox.
function g_k_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to g_k_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of g_k_checkbox


% --- Executes on button press in g_l_checkbox.
function g_l_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to g_l_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of g_l_checkbox




