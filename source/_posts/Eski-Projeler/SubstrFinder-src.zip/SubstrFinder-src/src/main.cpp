/*!
    \file main.cpp
    \brief main function call
*/
#include <QApplication>
#include "mainwindow.h"

/*!
    \fn int main(int argc, char *argv[])
    \brief main function call
    \param argc Argument count
    \param argv Argument vector
    \return Error code
*/
int main(int argc, char *argv[])
{
   QApplication app(argc, argv); /*!< Create an Qt application object  */
   MainWindow mainWin; /*!< Create a MainWindow class instance */
   mainWin.show(); /*! Show the gui */
   return app.exec(); /*! call applications event loop */
}
