/*!
    \file mainwindow.cpp
    \brief Class declaration of MainGui window
*/
#include <QtGui>
#include <ctime>
#include <QThread>
#include "mainwindow.h"

/*!
    \fn MainWindow
    Default Constructor
*/
MainWindow::MainWindow()
{
    setupUi(this); /*!<Run the moc for setting up the gui elements */
    
    textEdit->setWordWrapMode(QTextOption::NoWrap); /*! Set wrap option to disable in textEdit */
    
    connect(browse,SIGNAL(clicked()),this,SLOT(openFile())); /*! Connect browse pushButton clicked
                                                                                                            signal to the openFile function */
}

/*!
    \fn openFile
    Shows the file dialog for getting the file information
*/
void MainWindow::openFile()
{
    QString fileName = QFileDialog::getOpenFileName(this); /*!< Get file name which will process */
    QFile file(fileName); /*!< File descriptor */
    
    /*! Test for the opening the file for text mode and read only manner */
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        /*! Give an error message and return without continue */
        QMessageBox::warning(this, tr("Substring Finder"),
                             tr("Cannot read file %1:\n%2.")
                             .arg(fileName)
                             .arg(file.errorString()));
         return;
    }
    QTextStream in(&file); /*!< Text stream for reading the text */
    
    numberOfLines = in.readLine().toInt(); /*! Read the first line and assign the int value to numberOfLines */
    strlist.clear(); /*! Reset the string list for reopining new files*/
    while( ! in.atEnd() )
        strlist << in.readLine(); /*! Read line by line until the file ends*/
        
    textEdit->setText(QString::number(numberOfLines)); /*! Append the numberOfLines to the first line of textEdit */
    textEdit->append(strlist.join("\n")); /*! Append the string list to the textEdit which read before from the file */
    textEdit->append(tr("<hr />")); /*! Append a horizontal line for isolate the output */
    
    runFunctions(); /*! run functions*/
}

/*!
    \fn runFunctions
    Reads the file and runs the sub functions properly
*/
void MainWindow::runFunctions()
{
    QStringList wordlist; /*!< Word list of each line */
    QString strsubstr1; /*!< Returned string of substr1 function */
    QString strsubstr2; /*!< Returned string of substr2 function */
    int i = 1; /*!< Count for the line numbers which processed */
    
    /*! For each string in the string list; */
    foreach(QString str, strlist)
    {
        wordlist = str.split(" "); /*! get word list of current line */
        if(wordlist.count() == 2) /*! if line has two words */
        {
            clock_t t1, t2; /*!< variables for measure the elapsed time */
            unsigned long long int c1,c2; /*!< variables for measure the clock cycles */
            
            t1 = clock(); /*! get start time of substr1 */
            c1 = rdtsc(); /*! get start cycle count of substr1 */
                strsubstr1 = substr1(wordlist[0],wordlist[1]); /*! call the substr1 and store the result */
            c2 = rdtsc(); /*! get end cycle count of substr1 */
            t2 = clock(); /*! get end time of substr1 */
            float diff1 = (((float)t2 - (float)t1) / 1000000.0F ) ; /*!< store difference of measured times */
            float c_diff1 = c2 - c1; /*!< store difference of measured cycles */
            
            t1 = clock(); /*! get start time of substr2 */
            c1 = rdtsc(); /*! get start cycle count of substr2 */
                strsubstr2 = substr2(wordlist[0],wordlist[1]); /*! call the substr2 and store the result */
            c2 = rdtsc(); /*! get end cycle count of substr2 */
            t2 = clock(); /*! get end time of substr2 */
            float diff2 = (((float)t2 - (float)t1) / 1000000.0F ) ; /*!< store difference of measured times */
            float c_diff2 = c2 - c1; /*!< store difference of measured cycles */
            
            /*! Append the essencial strings and results of functions and measured values */
            textEdit->append(QString(tr("For line #%1\n")).arg(i++));
            textEdit->append( QString(tr("substr1 takes: %1 seconds (%2 cycle) to produce \"")).arg(diff1).arg(c_diff1) + 
                strsubstr1 + QString(tr("\" with length %1\n")).arg(strsubstr1.length()));
            textEdit->append( QString(tr("substr2 takes: %1 seconds (%2 cycle) to produce \"")).arg(diff2).arg(c_diff2) + 
                strsubstr2 + QString(tr("\" with length %1\n")).arg(strsubstr2.length()));
        }
        else /*! if line has not two words */
        {
            /*! Append a line to inform to the user about the usage of functions */
            textEdit->append(QString(tr("Line #%1 is not in true form (must be 2 words per line).\n")).arg(i++));
        }
    }
}

/*!
    \fn QString substr1(QString first, QString second)
    \brief Brute-Force method function for the longest common substring problem
    \param first First string
    \param second Second string
    \return The longest common substring
    The functions algorith is like below;
        - Find the long and shor string
        - Define max and commonStrStart variable to store the longest common substring and location
        - Build a loop through the shorter string 
            - Build a loop through the longer string inside the shorter strings loop
                - Define c variable to store temporary equal characters count
                    - Build a loop through current character location to end of the shorter string until the characters are equal
                        - If temporary equal character count c is greater than longest common substring max
                            - Store c in max and save start of location of longest common substring
        - If there is a longest common substring return the string, else return empty string
    
    This function is in brute-force manner which does the job in straightforwad. Function does not store any
    information common substring informations which found before during the loops.
    
    The complexity of the function at worst case that shorter string is exactly in the longer string is;
        m = shortStr.length() , for outer loop
        n = longStr.length(), for inner loop
        and one m for while loop.
    The complexity is:
        O(n.m.m)
*/
QString MainWindow::substr1(QString first, QString second)
{
    /*!< Find and store shorter and longer strings */
    QString shortStr,longStr; 
    if(first.length()<second.length()){ shortStr = first; longStr = second; }
    else { longStr = first; shortStr = second; }
    
    int max = 0; /*!< Longest common substring count */
    int commonStrStart = 0; /*!< Start location of longest common substring */
    
    for(int i = 0; i < shortStr.length(); i++) /*! loop through shorter string */
    {
        for(int j = 0; j < longStr.length(); j++) /*! loop through longer string */
        {
            int c = 0; /*!< temporary common substring */
            /*! loop through current short and long string character location to end of 
                shorter string until both characters of strings are equal
            */
            while(i+c < shortStr.length() && shortStr[i+c] == longStr[j+c]) { c++; }
            /*! if local max is greater than global max update global max, 
                and save the start position of common substring
            */
            if(c >= max) { max = c; commonStrStart = i; } 
        }
    }
    
    if(max>0) /*! if there is common substring return it */
        return shortStr.mid(commonStrStart,max);
    else /*! else return empty string */
        return tr("");
}

/*!
    \fn QString substr2(QString first, QString second)
    \brief Dynamic Programming method function for the longest common substring problem
    \param first First string
    \param second Second string
    \return The longest common substring
    The functions algorith is like below;
        - Define max and commonStrEnd variable to store the longest common substring and location
        - Define a matrix in rows first string and in colomns second strings lengths to store common substring information
        - Build a loop through the first string 
            - Fill the first row of matrix with zeros
        - Build a loop through the second string 
            - Fill the first colomn of matrix with zeros
        - Build a loop through the first string
            - Build a loop through the first string inside the second strings loop
                - If first and second strings character at current location is equal
                    - Add 1 to top left neigbour of current matrix location and store it in current location
                    - If current common substring length is greater than global one 
                        - Store it in global max value and store end location in commonStrEnd
                - Else assign zero to the current matrix location
        - If there is a longest common substring return the string, else return empty string
    
    This function is in Dynamic-Programming manner which stores previously founded common substrings
    in a matrix that allows find connection between next found substrings in a diagonal way.
    
    The complexity of the function at worst case is;
        m = first.length() , for outer loop
        n = second.length(), for inner loop
    The complexity of two for loops to fill starting row and colomn:
        O(n) + o(m)
    The complexity is:
        O(n.m) + O(n) + O(m)
    Which O(n) is in set of O(n.m) and O(m) is in set of O(n.m) therefore the result is; 
        O(n.m)
*/
QString MainWindow::substr2(QString first, QString second)
{
    int max = 0; /*!< Longest common substring count */
    int commonStrEnd = 0; /*!< End location of longest common substring */
    int m[(first.length()+1)][(second.length()+1)]; /*!< Matrix for substring relatioship */
    
    for(int i = 0; i < first.length()+1; i++) /*! Fill first row of matrix */
        m[i][0] = 0;
    for(int j = 0; j < second.length()+1; j++) /*! Fill first colomn of matrix */
        m[0][j] = 0;
    
    for(int i = 1; i < first.length()+1; i++) /*! loop through rows */
    {
        for(int j = 1; j < second.length()+1; j++) /*! loop through colomns */
        {
            if(first[i-1]==second[j-1]) /*! if current characters are equal */
            {
                m[i][j] = m[i-1][j-1] + 1; /*! sum top-left neigbour and 1 to the current cell */
                if(m[i][j] >= max) /*! if current longest common substring count is greater than global */
                    { max = m[i][j]; commonStrEnd = i; } /*! store it and save end position of substring */
            }
            else /*! else store zore to the current matrix location */
            {
                m[i][j] = 0;
            }
        }
    }
    
    if(max>0) /*! if there is common substring return it */
        return first.mid((commonStrEnd-max),max);
    else /*! else return empty string */
        return tr("");
}

/*!
    \fn unsigned long long int rdtsc(void)
    \brief Reads Time Stamp Counter. It counts the number of ticks since reset.
    \return TSC count
    For small words we cannot see any time measurements because of the todays fast CPU s.
    This function is helpful to measure the tick differences of CPU.
    This function is taken from http://www.mcs.anl.gov/~kazutomo/rdtsc.html
*/
#if defined(__i386__)
unsigned long long MainWindow::rdtsc(void)
{
  unsigned long long int x;/*!< return variables for the assembler instruciton */
     __asm__ volatile (".byte 0x0f, 0x31" : "=A" (x));  /*! the assembler instruciton call */
     return x;/*! Return 64 bit value of tick count since reset */
}
#elif defined(__x86_64__)
typedef unsigned long long int unsigned long long; /*! typedef for return type */
unsigned long long int MainWindow::rdtsc(void)
{
   unsigned a, d;  /*!< return variables for the assembler instruciton in to EAX and EDX */

   __asm__ volatile("rdtsc" : "=a" (a), "=d" (d));  /*! the assembler instruciton call */

    /*! Return 64 bit value of tick count since reset */
   return ((unsigned long long)a) | (((unsigned long long)d) << 32);;
}
#endif


