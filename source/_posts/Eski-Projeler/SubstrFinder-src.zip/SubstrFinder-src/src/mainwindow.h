/*!
    \file mainwindow.h
    \brief Class definition of MainGui window
*/
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ui_main.h"

/*!
    \class MainWindow mainwindow.h "src/mainwindow.h"
    \extends QMainWindow MainGui
    \brief Main window gui class
*/

class MainWindow : public QMainWindow, private Ui::MainGui
{
    Q_OBJECT /*!< Qt object model macro which initializes the QObject s */

public:
    MainWindow(); /*!< Default Constructor */

private slots:
    void openFile(); /*!< Shows the file dialog for getting the file information */
    void runFunctions(); /*!< Reads the file and runs the sub functions properly */
    
private:
    QStringList strlist; /*!< Stores the lines of file which opened before */
    int numberOfLines; /*!< Stores the first line of file as integer */
    
    /*!
        \fn QString substr1(QString first, QString second)
        \brief Brute-Force method function for the longest common substring problem
        \param first First string
        \param second Second string
        \return The longest common substring
    */
    QString substr1(QString first, QString second);
    
    /*!
        \fn QString substr2(QString first, QString second)
        \brief Dynamic Programming method function for the longest common substring problem
        \param first First string
        \param second Second string
        \return The longest common substring
    */
    QString substr2(QString first, QString second);
    
    /*!
        \fn unsigned long long int rdtsc(void)
        \brief Reads Time Stamp Counter. It counts the number of ticks since reset.
        \return TSC count
    */
    unsigned long long int rdtsc(void);
    
};

#endif
