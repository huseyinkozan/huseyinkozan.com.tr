/*			Modify			*/
#include "main.h"

enum modMenu {ADD_PASS,DELETE_PASS,DISPLAY_PASS,LIST_PASS,FLIGHT_ASS,BACK_TO_MENU} statModMenu;

char arrayModMenu[6][25] = {	"Add Passenger",
								"Delete Passenger",
								"Display Passenger Info",
								"List Passengers",
								"Flight Assign",
								"Back to Menu"};

void modifyMenuSelection(){
	int i;
	for(i=0;i<6;i++){
		gotoxy(30,i+8);
		if(i==statModMenu){
			color(FG_WHITE|FG_LIGHT|BG_BLUE);
			printf("%s\n",arrayModMenu[i]);
		}
		else{
			color(FG_WHITE|FG_LIGHT);
			printf("%s\n",arrayModMenu[i]);
		}
	}
}



void modify(){
	char c;
	statModMenu = ADD_PASS;
	clearScreen();
	do{
		color(FG_YELLOW|FG_LIGHT);
		box(25,6,28,9);
		color(FG_WHITE|FG_LIGHT);
		modifyMenuSelection();
		c=getch();
		if(c==27){
			color(FG_WHITE|FG_LIGHT);
			return;
		}
		if(c==72){
			statModMenu--;
			if(statModMenu<0)statModMenu=5;
		}
		if(c==80){
			statModMenu++;
			if(statModMenu>5)statModMenu=0;
		}
		if(c==13){
			switch(statModMenu){
			case ADD_PASS:
				addPassenger();
				clearScreen();
				break;
			case DELETE_PASS:
				delPassenger();
				clearScreen();
				break;
			case DISPLAY_PASS:
				displayPassenger();
				clearScreen();
				break;
			case LIST_PASS:
				listPassenger();
				clearScreen();
				break;
			case FLIGHT_ASS:
				flightAssign();
				clearScreen();
				break;
			case BACK_TO_MENU:
				color(FG_WHITE|FG_LIGHT);
				clearScreen();
				return;
			}
		}
	}while(1);
}