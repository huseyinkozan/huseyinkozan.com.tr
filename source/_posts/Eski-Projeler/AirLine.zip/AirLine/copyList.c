/*			CopyList			*/
#include "main.h"
#include "structs.h"

void copyList(){
	char buff[256] = "output.txt";
	int j=0;
	struct struct_passenger passenger = {"","","","","","","",0};

	FILE *fp;
	FILE *fp2;
	if((fp=fopen("passeng.txt","a+"))==NULL){
		gotoxy(1,23);
		printf("File  could not be opened.\n");
		system("pause");
		clearScreen();
	}
	else{
		clearScreen();
		if((fp2=fopen(buff,"w"))==NULL){
			gotoxy(1,23);
			printf("File  could not be opened.\n");
			system("pause");
			clearScreen();
		}
		else{
			clearScreen();
			while( fread(&passenger,sizeof(passenger),1,fp)!=0 ){
				fprintf(fp2,"%s,\t%s,\t%s,\t%s\n",passenger.lastName,passenger.firstName,passenger.passAge,
														passenger.passSex);
			}
			gotoxy(1,24);
			printf("All data succesfully copied.");
		}
	fclose(fp);
	fclose(fp2);
	}
	getchar();
}


