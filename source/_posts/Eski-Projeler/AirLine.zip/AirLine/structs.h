
struct struct_flight {
	char flightDepLoc[40];			/*Flight Departure Location*/
	char flightArrLoc[40];			/*Flight Arrival Location*/
	char flightDepDate[15];			/*Flight Departure Date*/
	char flightArrDate[15];			/*Flight Arrival Date*/
	char flightDepTime[10];			/*Flight Departure Time*/
	char flightArrTime[10];			/*Flight Arrival Time*/
	char flightCode[20];			/*Flight Code (or Plane Code)*/
	int flightCap;					/*Flight Capacity*/
	int passCount;					/*Passenger IDs*/
};

struct struct_passenger {
	char lastName[40];	
	char firstName[40];	
	char passAge[10];
	char passSex[10];
	char passClass[10];	
	char passSeat[10];	
	char flightCode[20];
	int passID;			
};
