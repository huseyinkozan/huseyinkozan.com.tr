/*			AirlineInfo			*/
#include "main.h"
#include "structs.h"

#define LEN_FL 8

char arrLabelFlight[LEN_FL][25] = { "Departure Location","Arrival Location","Departure Date",
									"Arrival Date","Departure Time","Arrival Time","Flight Code","Flight Capacity" };

void airlineInfo(){
	int i;
	struct struct_flight flight = {"","","","","","","",0,0};
	char buff[80];
	char c;
	FILE *fp;
	if((fp=fopen("flight.txt","a+"))==NULL){
		gotoxy(1,23);
		printf("File  could not be opened.\n");
		system("pause");
		clearScreen();
	}
	else{
		do{
			clearScreen();
			for(i=0;i<LEN_FL;i++){
				gotoxy(1,2+i);
				printf("%s",arrLabelFlight[i]);
			}
			gotoxy(30,2);
			getWord(buff,39);
			strcpy(flight.flightDepLoc,buff);
			gotoxy(30,3);
			getWord(buff,39);
			strcpy(flight.flightArrLoc,buff);
			gotoxy(30,4);
			getWord(buff,14);
			strcpy(flight.flightDepDate,buff);
			gotoxy(30,5);
			getWord(buff,14);
			strcpy(flight.flightArrDate,buff);
			gotoxy(30,6);
			getWord(buff,9);
			strcpy(flight.flightDepTime,buff);
			gotoxy(30,7);
			getWord(buff,9);
			strcpy(flight.flightArrTime,buff);
			gotoxy(30,8);
			getWord(buff,19);
			strcpy(flight.flightCode,buff);
			gotoxy(30,9);
			getWord(buff,9);
			flight.flightCap = atoi(buff);

			if(flight.flightDepLoc[0] != '\0')
				fwrite(&flight,sizeof(flight),1,fp);

			gotoxy(1,23);
			printf("Do you want to continue ? (Y/N) :");
			gotoxy(35,23); c = getche();
		}while(c=='Y'||c=='y');
		fclose(fp);
	}

	getchar();
}