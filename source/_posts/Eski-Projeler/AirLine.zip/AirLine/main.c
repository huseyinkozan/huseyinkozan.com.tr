/*			Main			*/
#include "main.h"

char arrayMenu[6][25] = {"Create List",
					"Airline Info",
					"Print Menu",
					"Modify",
					"Copy List",
					"Exit"};

enum enumStatusMenu {CREATE,INFO,PRINT,MODIFY,COPY,EXIT} statusMenu;

void menuSelection(){
	int i;
	for(i=0;i<6;i++){
		gotoxy(30,i+8);
		if(i==statusMenu){
			color(FG_WHITE|FG_LIGHT|BG_BLUE);
			printf("%s\n",arrayMenu[i]);
		}
		else{
			color(FG_WHITE|FG_LIGHT);
			printf("%s\n",arrayMenu[i]);
		}
	}
}

int getWord(char *p_char,int n){
	char *p;
	if((fgets(p_char,n,stdin))==NULL) return 0;
	if((p=strchr(p_char,'\n'))!=NULL) *p='\0';
	return 1;
}

int main(){
	char c;
	statusMenu = CREATE;
	clearScreen();
	do{
		color(FG_YELLOW|FG_LIGHT);
		box(25,6,28,9);
		color(FG_WHITE|FG_LIGHT);
		menuSelection();
		c=getch();
		if(c==27){
			color(FG_WHITE|FG_LIGHT);
			clearScreen();
			return 0;
		}
		if(c==72){
			statusMenu--;
			if(statusMenu<0)statusMenu=5;
		}
		if(c==80){
			statusMenu++;
			if(statusMenu>5)statusMenu=0;
		}
		if(c==13){
			switch(statusMenu){
			case CREATE:
				createList();
				clearScreen();
				break;
			case INFO:
				airlineInfo();
				clearScreen();
				break;
			case PRINT:
				printMenu();
				clearScreen();
				break;
			case MODIFY:
				modify();
				clearScreen();
				break;
			case COPY:
				copyList();
				clearScreen();
				break;
			case EXIT:
				color(FG_WHITE|FG_LIGHT);
				clearScreen();
				return 0;
			}
		}
	}while(1);
}