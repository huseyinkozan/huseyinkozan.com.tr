/*			PrintMenu			*/
#include "main.h"
#include "structs.h"

int flightSearch(char *flightCode,char *departureLoc,char *arrivalLoc,char *departureDate,char *arrivalDate,int *capacity){
	struct struct_flight flight = {"","","","","","","",0,0};
	FILE *fp_flight;
	if((fp_flight=fopen("flight.txt","a+"))==NULL){
		gotoxy(1,23);
		printf("File  could not be opened.\n");
		system("pause");
		clearScreen();
	}
	else{
		while( fread(&flight,sizeof(flight),1,fp_flight)!=0 ){
			if(strcmp(flight.flightCode,flightCode)==0){
				strcpy(departureLoc,flight.flightDepLoc);
				strcpy(arrivalLoc,flight.flightArrLoc);
				strcpy(departureDate,flight.flightDepDate);
				strcpy(arrivalDate,flight.flightArrDate);
				*capacity=flight.flightCap;
				
				fclose(fp_flight);
				return 0;
			}
		}
		fclose(fp_flight);
		return 1;

	}
	return 1;
}

void printMenu(){
	char buff[256] = "";
	int j=0;
	struct struct_flight flight = {"","","","","","","",0,0};
	struct struct_passenger passenger = {"","","","","","","",0};
	int pageCounter=0;

	FILE *fp;
	if((fp=fopen("passeng.txt","a+"))==NULL){
		gotoxy(1,23);
		printf("File  could not be opened.\n");
		system("pause");
		clearScreen();
	}
	else{
			clearScreen();
			gotoxy(0,1);
			printf("LastName FirstName FlightCode DepartureLoc ArrivalLoc DepartureDate ArrivalDate");
			while( fread(&passenger,sizeof(passenger),1,fp)!=0 ){
				flightSearch(passenger.flightCode,flight.flightDepLoc,flight.flightArrLoc,flight.flightDepDate,
								flight.flightArrDate,&flight.flightCap);
				printf("\n%s  %s  %s  %s  %s",passenger.lastName,passenger.firstName,passenger.flightCode,
													flight.flightDepLoc,flight.flightArrLoc,flight.flightDepDate,
													flight.flightArrDate);
				flight.flightDepLoc[0] = '\0';
				flight.flightArrLoc[0] = '\0';
				flight.flightDepDate[0] = '\0';
				flight.flightArrDate[0] = '\0';
				flight.flightCap = 0;
				pageCounter++;
				if(pageCounter>20){
					printf("\n");
					system("pause");
					pageCounter=0;
				}

			}
	}
	fclose(fp);
	getchar();
}


