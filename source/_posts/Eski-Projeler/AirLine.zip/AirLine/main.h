#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#define FG_RED FOREGROUND_RED
#define FG_GREEN FOREGROUND_GREEN
#define FG_BLUE FOREGROUND_BLUE
#define FG_LIGHT FOREGROUND_INTENSITY

#define FG_YELLOW (WORD) 0x0006
#define FG_CYAN   (WORD) 0x0003
#define FG_WHITE  (WORD) 0x0007

#define BG_RED BACKGROUND_RED
#define BG_GREEN BACKGROUND_GREEN
#define BG_BLUE BACKGROUND_BLUE
#define BG_LIGHT BACKGROUND_INTENSITY

#define BG_WHITE  (WORD) 0x00f0
#define BG_CYAN   (WORD) 0x0030

extern void clearScreen(void);
extern void color( WORD attr );
extern void gotoxy( int x, int y );
extern void hLineSingle(int x, int y, int width);
extern void vLineSingle(int x, int y, int height);
extern void hLineDouble(int x, int y, int width);
extern void vLineDouble(int x, int y, int height);
extern void box(int x, int y, int width,int height);

extern int getWord(char *p_char,int n);

extern void airlineInfo();
extern void createList();
extern void copyList();
extern void modify();
extern void printMenu();

extern void addPassenger();
extern void delPassenger();
extern void displayPassenger();
extern void listPassenger();
extern void flightAssign();
