/*			Graphics			*/
#include "main.h"

HANDLE scr;

void gotoxy( int x, int y ){
  COORD pos = { x, y };
  scr = GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleCursorPosition(scr, pos);
}

void color( WORD attr ){ 
	scr = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(scr, attr); 
}


void hLineSingle(int x, int y, int width){
	int i;
	for( i=x; i<=width+x; i++){	
		gotoxy( i, y );
		printf( "�" );
	}
}

void vLineSingle(int x, int y, int height){
	int i;
	for( i=y; i<=height+y; i++){	
		gotoxy( x, i );
		printf( "�" );
  }
}

void hLineDouble(int x, int y, int width){
	int i;
	for( i=x; i<=width+x; i++){	
		gotoxy( i, y );
		printf( "�" );
	}
}

void vLineDouble(int x, int y, int height){
	int i;
	for( i=y; i<=height+y; i++){	
		gotoxy( x, i );
		printf( "�" );
  }
}
void box(int x, int y, int width,int height){
  vLineDouble(x,y,height);
  vLineDouble(x+width,y,height);
  hLineDouble(x,y,width);
  hLineDouble(x,y+height,width);

  gotoxy( x, y );		printf( "�" );
  gotoxy( x+width, y );		printf( "�" );
  gotoxy( x, y+height );		printf( "�" );
  gotoxy( x+width, y+height );	printf( "�" );
 }

void clearScreen(void){
	int i;
	for(i=0;i<=80*25-2;i++){
		gotoxy(i,0);
		printf(" ");
	}
}
