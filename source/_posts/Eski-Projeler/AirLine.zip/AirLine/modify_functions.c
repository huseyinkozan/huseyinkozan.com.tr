/*			Modify Functions			*/
#include "main.h"
#include "structs.h"

FILE *fp;
FILE *fp_temp;

void addPassenger(){
	clearScreen();
	createList();
	getchar();
}

void delPassenger(){
	char buff[256] = "";
	struct struct_passenger passenger = {"","","","","","","",0};
	int pageCounter=0;
	int searchResult=0;
	int i=2;
	char c;

	clearScreen();
	gotoxy(1,2);
	printf("Please enter the Surname of passenger to delete :");
	getWord(buff,39);

	if((fp=fopen("passeng.txt","r"))==NULL){
		gotoxy(1,23);
		printf("File  could not be opened.\n");
		system("pause");
		clearScreen();
	}
	else{
		if((fp_temp=fopen("pass_tmp.txt","w"))==NULL){
			gotoxy(1,23);
			printf("File  could not be opened.\n");
			system("pause");
			clearScreen();
		}
		else{
			clearScreen();
			gotoxy(1,i);
			while( fread(&passenger,sizeof(passenger),1,fp)!=0 ){
				c="";
				fflush(stdout);
				if(strcmp(passenger.lastName,buff)==0){
					printf("%s  %s  %s  %s ->",passenger.lastName,passenger.firstName,passenger.passAge,passenger.passSex);
					printf("\t(Y) to delete,(enter) to dont :");
					scanf("%c",&c);
					if(islower(c))
						c = toupper(c);
				}
				if(!(c=='Y'))
					fwrite(&passenger,sizeof(passenger),1,fp_temp);
				searchResult++;
			}
			fclose(fp);
			fclose(fp_temp);
			if(searchResult){
				remove("passeng.txt");
				rename("pass_tmp.txt","passeng.txt");
			}
		}
	}
	getchar();
}

void displayPassenger(){
	char buff[256] = "";
	struct struct_passenger passenger = {"","","","","","","",0};
	int pageCounter=0;
	int searchResult=0;
	
	clearScreen();
	gotoxy(1,2);
	printf("Please enter the Surname of passenger to display information :");
	getWord(buff,39);

	if((fp=fopen("passeng.txt","r"))==NULL){
		gotoxy(1,23);
		printf("File  could not be opened.\n");
		system("pause");
		clearScreen();
	}
	else{
		clearScreen();
		gotoxy(1,2);
		while( fread(&passenger,sizeof(passenger),1,fp)!=0 ){
			if(strcmp(passenger.lastName,buff)==0){
				printf("\n%s  %s  %s  %s",passenger.lastName,passenger.firstName,passenger.passAge,passenger.passSex);
				searchResult++;
				pageCounter++;
				if(pageCounter>20){
					printf("\n");
					system("pause");
					pageCounter=0;
				}
			}				
			
		}
		if(searchResult==0){
			gotoxy(0,24);
			printf("The Passenger you entered \"%s\" can not found.",buff);
		}

	fclose(fp);
	}
	getchar();
}

void listPassenger(){
	char buff[256] = "";
	int j=0;
	struct struct_passenger passenger = {"","","","","","","",0};
	int pageCounter=0;

	if((fp=fopen("passeng.txt","r"))==NULL){
		gotoxy(1,23);
		printf("File  could not be opened.\n");
		system("pause");
		clearScreen();
	}
	else{
		clearScreen();
		gotoxy(0,1);
		printf("LastName FirstName FlightCode DepartureLoc ArrivalLoc DepartureDate ArrivalDate");
		while( fread(&passenger,sizeof(passenger),1,fp)!=0 ){
			printf("\n%s  %s  %s  %s  %s",passenger.lastName,passenger.firstName,passenger.passAge,passenger.passSex,
											passenger.flightCode);
			pageCounter++;
			if(pageCounter>20){
				printf("\n");
				system("pause");
				pageCounter=0;
			}

		}
	fclose(fp);	
	}
	getchar();
}

void flightAssign(){
	clearScreen();
	
	getchar();
}
