/*			CreateList			*/
#include "main.h"
#include "structs.h"

#define LEN_PASS 8
char arrLabelPassengers[LEN_PASS][25] = {	"Passenger Surname","Passenger Name","Age","Sex","Class",
											"Seat","Passenger ID","Flight Code"};

void createList(){
	int i;
	struct struct_passenger passenger = {"","","","","","","",0};
	char buff[40];
	char ch;

	FILE *fp;
	if((fp=fopen("passeng.txt","a+"))==NULL){
		gotoxy(1,23);
		printf("File  could not be opened.\n");
		system("pause");
		clearScreen();
	}
	else{
		do{
			clearScreen();
			for(i=0;i<LEN_PASS;i++){
				gotoxy(1,2+i);
				printf("%s",arrLabelPassengers[i]);
			}
			gotoxy(30,2);
			getWord(buff,39);
			strcpy(passenger.lastName,buff);
			gotoxy(30,3);
			getWord(buff,39);
			strcpy(passenger.firstName,buff);
			gotoxy(30,4);
			getWord(buff,9);
			strcpy(passenger.passAge,buff);
			gotoxy(30,5);
			getWord(buff,9);
			strcpy(passenger.passSex,buff);
			gotoxy(30,6);
			getWord(buff,9);
			strcpy(passenger.passClass,buff);
			gotoxy(30,7);
			getWord(buff,9);
			strcpy(passenger.passSeat,buff);
			gotoxy(30,8);
			getWord(buff,9);
			passenger.passID = atoi(buff);
			gotoxy(30,9);
			getWord(buff,19);
			strcpy(passenger.flightCode,buff);

			if(passenger.lastName[0] != '\0')
				fwrite(&passenger,sizeof(passenger),1,fp);

			gotoxy(1,23);
			printf("Do you want to continue ? (Y/N) :");
			gotoxy(35,23); ch = toupper(getche());
		}while(ch=='Y');
		fclose(fp);
		
	}
	getchar();
}