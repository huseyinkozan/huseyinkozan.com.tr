/* gerekli baslik dosyalari */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>

#define DEFAULTPORT 1216 /* onatimli port */
#define BACKLOG 10 /* kuyrukta bekleyecek dinleme sayisi */

/*
    turetilen cocuk islemlerin
    kapanmasini beklemek icin
    grekeli fonksiyon
*/
void sigchild_handler(int s)
{
    while(wait(NULL)>0);
}

/* fonksiyon on tanimlamalari */
void getcommand(int socket, char * command, size_t size);
void execcommand(int newfd, char * command, int size);
int processfile(int newfd, char * file, int size);
int getport(int argc, char * argv[]);

/* ana fonksiyon */
int main(int argc, char * argv[])
{
    int myport  = getport(argc, argv); /* dinlenecek port alinir */
    int sockfd, newfd; /* soket dosya tanimlayicilari */
    struct sockaddr_in my_addr; /* server in adres bilgisini tutacak yapi */
    struct sockaddr_in their_addr; /* baglananlarin adres bilgisini tutacak yapi */
    int sin_size; /* kabul edilen baglantinin adres bilgisi boyunu tutar */
    struct sigaction sa; /* sistem sinyal yapisi */
    int yes = 1; /* setsockopt fonksiyonu icin gerekli */

    /* tcp soketi acildi */
    if( (sockfd = socket(AF_INET, SOCK_STREAM, 0) ) == -1 )
    {
        perror("socket");
        return EXIT_FAILURE;
    }

    /* burasi programin tekrar ayni port u alabilmesi icin gerekli */
    if( (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int))) == -1 )
    {
        perror("setsockopt");
        return EXIT_FAILURE;
    }

    my_addr.sin_family = AF_INET; /* internet ailesinden */
    my_addr.sin_port = htons(myport); /* dinleyecegim port numarasi */
    my_addr.sin_addr.s_addr = INADDR_ANY; /* server in kendi IP adresi */
    memset(&(my_addr.sin_zero),'\0',8); /* yapi boyutunu sockadrr ile esitle */

    /*
        acilan soketin ayarlarini degistir ve
        dinlenecek portu belirt
     */
    if( bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1 )
    {
        perror("bind");
        return EXIT_FAILURE;
    }

    /* bind ile verilen soket i dinle */
    if( listen(sockfd, BACKLOG) == -1 )
    {
        perror("listen");
        return EXIT_FAILURE;
    }

    /* sinyal yapisini cocuklari bekleyecek sekilde ayarla */
    sa.sa_handler = sigchild_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;

    /* sinyal yapisini uygula */
    if( sigaction(SIGCHLD, &sa, NULL) == -1 )
    {
        perror("sigaction");
        return EXIT_FAILURE;
    }

    /* baglanti kobulu icin sonsuz dongu */
    while(1)
    {
        sin_size = sizeof(struct sockaddr_in); /* soket yapisinin boyunu ayarla */

        /* accep ile yeni baglantilari kabul et */
        if( (newfd = accept(sockfd, (struct sockaddr*) &their_addr, (socklen_t*)&sin_size)) == -1 )
        {
            perror("accept");
            continue;
        }

        /* gelen baglanti bilgisini server ekranına bastir */
        printf("Server got connection from %s\n", inet_ntoa(their_addr.sin_addr));

        pid_t pid = fork(); /* calisan programin bir kopyasini olustururarak cocuk islemi olustur */
        if( pid == 0 ) /* eger cocuk islemi icindeysek */
        {
            close(sockfd); /* cocuk isleminde baglanti kabul ettigimiz sokete ihtiyacimiz yok*/

            char command[1024] = {0}; /* gelen komutun saklanacagi alan */
            dup2(newfd, 2); /* calisan cocuk isleminin standart hatasini (stderr) kabul ettigimiz sokete bagladik */
            dup2(newfd, 1); /* calisan cocuk isleminin standart cikisini (stdout) kabul ettigimiz sokete bagladik */
            dup2(newfd, 0); /* calisan cocuk isleminin standart girisini (stdin) kabul ettigimiz sokete bagladik */

            /* kullanicidan kumutlari aldigimiz dongu */
            while(1)
            {
                send(newfd, ">", 1, 0); /* komut yazabilecegini bildiren isaret */
                getcommand(newfd, command, 1024); /* yeni bir komut al getir */
                if(strstr(command,"quit") == &command[0]) /* eger komut cikis ise komut dongusunden cik */
                    break;
                execcommand( newfd, command, 1024 ); /* alinan komutu islet */
            }

            close(newfd); /* baglantiyi kapat */

            exit(0); /* cocuk islemini sonlandir */

        }
        else
        {
            close(newfd); /* ana islemde yeni baglanti soketine ihtiyacimiz yok */
        }
    }

    return EXIT_SUCCESS; /* server programindan cikis */
}

/*
    kullanicidan komut alir ve aldigi karakter dizisine komutu yazar

    newfd : komut alinacak baglanti tanimlayicisi
    command : geri dondurulecek komut
    size : command dizisinin boyu
*/
void getcommand(int newfd, char * command, size_t size)
{
    size_t r; /* recv() in okudugu sayiyi gecici olarak tutar */
    int r_i = 0; /* recv() ile toplam okunan deger */
    char * commbuff = (char *) malloc(size); /* size boyunda gecici bir alan ayir */
    memset(commbuff, 0, size); /* ayrilan alani temizle */

    /* en az bir kez recv () ile deger al */
    do
    {
        r = recv(newfd, &commbuff[r_i], size-r_i, 0); /* baglantidan paket al */
        r_i += r; /* aldigim toplam paketleri say */

        if(r<0) /* r<0 ise recv() hata dondurmustur */
        {
            perror("recv");
            exit(1);
        }

        char * f_i; /* foud_index : satir sonu karakterinin (CRLF) gosterecegi isaretci */
        if((f_i = strstr(commbuff,"\r\n"))!=NULL) /* satir sonu karakteri bulunmussa */
        {
            memset(f_i, 0, (size_t)(&commbuff[size-1]-f_i)); /* satir sonu karakerini ve sonrasini temizle */
            break; /* komut alindi, paket almayi birak */
        }
    }
    while(r>0 && size-r_i>0); /* r==0 ise karsi taraf baglantiyi kapatmistir. size-r_i<=0 ise gelen komutlar dizime sigmaz */

    sprintf(command, "%s",commbuff); /* gecici bellekten parametreyle alinan diziye aktar */
    free( commbuff ); /* gecici bellegi serbers birak */
}

/* verilen komutu isler */
void execcommand(int newfd, char * command, int size)
{
    if(strstr(command,"help") == &command[0]) /* gelen komut help ise */
    {
        /* kullanim hakkinda bilgi ver */
        printf("Usage:\n\n"
        "  traceroute [destination] : will traceroute to destination address\n"
        "  traceroute [filename] : will traceroute to addresses in the specified file.\n"
        "  help : will print this menu\n"
        "  quit : closes the connection.\n"
        "\n");
    }
    else if(strstr(command,"traceroute") == &command[0]) /* gelen komut traceroute ise */
    {
        char * f_i; /* found_index : bosluk icin isaretci*/
        if((f_i = strstr(command," "))!=NULL) /* ilk boslugu isaret et */
        {
            char * file = (char *) malloc(size); /* dosya adi icin gecici yer ayir */
            memset(file, 0, size); /* ayrilan yeri temizle */

            sprintf(file, "%s",&f_i[1]); /* bosluktan sonra gelenleri dosya adina al */
            if ( processfile(newfd, file, size) == false ) /* eger file icinde dosya adinda bir dosya varsa ac ve islet*/
            {
                system(command); /* oyle bir dosya yoksa traceroute komutunu parametresiyle birlikte islet */
            }

            free(file); /*ayrilan bellegi serbest birak */
        }
    }
    else /* bunun disinda gelen komutlar icin uyari ver, yardimi isaret et */
    {
        printf("Wrong command. Try \"help\" to get allowed commands.\n");
    }
}

/* file dosyasi varsa acar isletir ve true dondurur, yoksa false dondurur */
int processfile(int newfd, char * file, int size)
{
    char command[1024] = {0}; /* dosyadan alinacak komutlar icin */
    FILE * f;

    if( (f = fopen(file,"r")) == NULL ) /* dosya okumak icin acilamiyorsa */
    {
        return false; /* false dondur */
    }
    else /* dosya acilabiliyorsa */
    {
        while (!feof(f)) /* dosya sonuna kadar oku */
        {
            fgets(command, 1024, f); /* bir satir al */
            if(strstr(command,"traceroute") == &command[0]) /* eger satirdaki komut traceroute ise */
            {
                system(command); /* komutu calistir */

                char m[] = "\n------------\n\n"; /* her traceroute islemini ayrac ile ayir */
                send(newfd, m, strlen(m), 0); /* ayraci baglantiya gonder */
            }
        }
        fclose (f); /* dosyayi kapat */

        return true; /* true dondur */
    }
}

/* server komut satirindan calisacagi portu alir */
int getport(int argc, char * argv[])
{
    int y = DEFAULTPORT; /* onatimli port */

    if(argc>2) /* eger 2 den cok arguman almissa */
    {
        for(int i = 0; i< argc; i++) /* her arguman icin */
        {
            if(strcasecmp(argv[i],"PORT") == 0) /* eger arguman PORT ya da port ise */
            {
                if(i+1<argc) /* port dan sonra arguman var ise */
                {
                    int x = atoi(argv[i+1]); /* porttan sonraki argumani int e cevir */
                    if(x != 0 && x > 1025 && x < 65536) /* eger cevrim yapilmis ve 1025-65536 araliginda ise */
                        return x; /* port olarak bu degeri dondur */
                }
            }
        }
    }

    return y; /* aksi halde onatimli port u dondur */
}

