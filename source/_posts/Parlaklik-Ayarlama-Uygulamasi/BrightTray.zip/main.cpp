#include <QtGui/QApplication>
#include <QSystemTrayIcon>
#include <QMessageBox>
#include <QProcess>
#include <QWheelEvent>
#include <QMenu>

class SystemTrayIcon : public QSystemTrayIcon
{
public:
  SystemTrayIcon(QObject * parent = 0)
    : QSystemTrayIcon(parent)
  {
  }
  bool event(QEvent * event)
  {
    if(event->type() == QEvent::Wheel)
    {
      QWheelEvent * we = static_cast<QWheelEvent*>(event);
      QString direction;
      if(we->delta() > 0)
        direction = "+10";
      else
        direction = "-10";
      QProcess cmd;
      cmd.start("nvclock", QStringList() << "-S" << direction);
      if ( ! cmd.waitForStarted())
      {
        // problem while starting
      }
      if ( ! cmd.waitForFinished())
      {
        // problem while running
      }
      return true;
    }
    else
    {
      return false;
    }
  }
};

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    if( ! QSystemTrayIcon::isSystemTrayAvailable())
    {
      QMessageBox::critical(0,
                            QObject::tr("No Tray !"),
                            QObject::tr("There is no available system tray. "
                                        "Please run program while the system tray available.\n"));
      return 1;
    }

    QMenu * trayMenu = new QMenu();
    trayMenu->addAction(QObject::tr("Exit"), &a, SLOT(quit()), QKeySequence());
    

    SystemTrayIcon * tray = new SystemTrayIcon;
    tray->setContextMenu(trayMenu);
    tray->setIcon(QIcon(":/trayIcon.png"));
    tray->show();

    return a.exec();
}
