#ifndef SLIDERBASEWIDGET_H
#define SLIDERBASEWIDGET_H

#include <QWidget>

class QSlider;

class SliderBaseWidget : public QWidget
{
    Q_OBJECT

private:
    QSlider * s;

public:
    SliderBaseWidget();
    void setSliderValue(int val);

private slots:
    void sValueChanged(int val);

signals:
    void sliderValueChanged(int);
};


#endif // SLIDERBASEWIDGET_H
