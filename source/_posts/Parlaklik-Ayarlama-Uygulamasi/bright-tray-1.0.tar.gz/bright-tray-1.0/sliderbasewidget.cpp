#include <QVBoxLayout>
#include <QSlider>
#include "sliderbasewidget.h"
#include "globals.h"

SliderBaseWidget::SliderBaseWidget()
{
    QVBoxLayout * l = new QVBoxLayout();
    s = new QSlider(Qt::Vertical, this);
    l->addWidget(s);
    setLayout(l);

    s->setMaximum(MAX_BIGHTNESS);
    s->setMinimum(MIN_BIGHTNESS);

    connect(s, SIGNAL(valueChanged(int)), this, SLOT(sValueChanged(int)));

    setFocusPolicy(Qt::WheelFocus);

    setWindowFlags(Qt::Popup);
}


void SliderBaseWidget::sValueChanged(int val)
{
    emit sliderValueChanged(val);
}


void SliderBaseWidget::setSliderValue(int val)
{
    s->setValue(val);
}
