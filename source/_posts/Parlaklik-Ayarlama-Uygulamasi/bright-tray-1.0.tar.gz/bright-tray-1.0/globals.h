#ifndef GLOBALS_H
#define GLOBALS_H

#define WHEEL_STEP 10
#define MIN_BIGHTNESS 15
#define MAX_BIGHTNESS 100

#endif // GLOBALS_H
