#include <QtGui/QApplication>
#include <QSystemTrayIcon>
#include <QMessageBox>
#include <QMenu>
#include "systemtrayicon.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    if( ! QSystemTrayIcon::isSystemTrayAvailable())
    {
      QMessageBox::critical(0,
                            QObject::tr("No Tray !"),
                            QObject::tr("There is no available system tray. "
                                        "Please run program while the system tray available.\n"));
      return 1;
    }
    QMenu * trayMenu = new QMenu();
    //QAction * aboutAction = trayMenu->addAction(QObject::tr("About"));
    //trayMenu->addSeparator();
    trayMenu->addAction(QObject::tr("Exit"), &a, SLOT(quit()), QKeySequence());
    SystemTrayIcon * tray = new SystemTrayIcon;
    //a.connect(aboutAction, SIGNAL(triggered()), tray, SLOT(about()));
    tray->setContextMenu(trayMenu);
    tray->setIcon(QIcon(":/trayIcon.png"));
    tray->setToolTip(QObject::tr("Prefer using wheel."));
    tray->show();
    return a.exec();
}
