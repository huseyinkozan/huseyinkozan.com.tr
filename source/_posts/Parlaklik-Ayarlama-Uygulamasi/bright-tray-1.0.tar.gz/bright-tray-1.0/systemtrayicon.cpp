#include <QEvent>
#include <QWheelEvent>
#include <QProcess>
#include <QApplication>
#include <QDesktopWidget>
#include <QDebug>
#include <QMessageBox>
#include "systemtrayicon.h"
#include "globals.h"

SystemTrayIcon::SystemTrayIcon(QObject * parent)
  : QSystemTrayIcon(parent),
  currentVal(100)
{
    sb = new SliderBaseWidget;
    connect(sb, SIGNAL(sliderValueChanged(int)), this, SLOT(updateBrightness(int)));
    connect(this, SIGNAL(activated(QSystemTrayIcon::ActivationReason)),
            this, SLOT(trayActivated(QSystemTrayIcon::ActivationReason)));

    QProcess cmd;
    // cmd.setProcessChannelMode(QProcess::ForwardedChannels);
    cmd.start("nvclock", QStringList() << "-i");
    if ( ! cmd.waitForStarted())
    {
      // problem while starting
    }
    if ( ! cmd.waitForFinished())
    {
      // problem while running
    }

    QList<QByteArray> byteList = cmd.readAllStandardOutput().split('\n');

    qDebug() << "liste boyu: " << byteList.size();

    for(int i=0; i< byteList.size(); ++i)
    {
        QString s = QString::fromAscii(byteList.at(i).data());
        qDebug() << "> " << s;
        if( s.contains( QString("Backlight level"), Qt::CaseInsensitive) )
        {
            QStringList wordList = s.split(' ');
            QString last = wordList.last();
            last.remove('%');
            qDebug() << "last: " << last;

            bool ok;
            int x = last.toInt(&ok);
            if(x)
                currentVal = x;
            else
                qDebug() << "Cannot convert: " << last;
            qDebug() << "okunan deger : " << x;
        }
    }

}

bool SystemTrayIcon::event(QEvent * event)
{
  if(event->type() == QEvent::Wheel)
  {
    QWheelEvent * we = static_cast<QWheelEvent*>(event);

    if(we->delta() > 0)
    {
        if(currentVal + WHEEL_STEP > MAX_BIGHTNESS)
            currentVal = MAX_BIGHTNESS;
        else
            currentVal += WHEEL_STEP;
    }
    else
    {
        if(currentVal - WHEEL_STEP < MIN_BIGHTNESS)
            currentVal = MIN_BIGHTNESS;
        else
            currentVal -= WHEEL_STEP;
    }

    updateBrightness( currentVal );

    return true;
  }
  else
  {
    return false;
  }
}

void SystemTrayIcon::trayActivated(QSystemTrayIcon::ActivationReason reason)
{
    if( reason == QSystemTrayIcon::Trigger )
    {
        QPoint p = QCursor::pos();
        QRect r = QApplication::desktop()->availableGeometry(p);

        sb->show();

        if(p.y() + sb->frameGeometry().height() > r.height())
            p.setY(p.y() - sb->frameGeometry().height());

        if(p.x() + sb->frameGeometry().width() > r.width())
            p.setX(p.x() - sb->frameGeometry().width());

        sb->move(p);

        // qDebug() <<  "sb height : " << sb->frameGeometry().height();

        sb->setSliderValue(currentVal);

    }
}

void SystemTrayIcon::updateBrightness(int val)
{
    currentVal = val;
    if(currentVal < MIN_BIGHTNESS)
        currentVal = MIN_BIGHTNESS;
    else if(currentVal >= MAX_BIGHTNESS)
        currentVal = MAX_BIGHTNESS;

    QProcess cmd;
    cmd.start("nvclock", QStringList() << "-S" << QString::number(currentVal));
    if ( ! cmd.waitForStarted())
    {
      // problem while starting
    }
    if ( ! cmd.waitForFinished())
    {
      // problem while running
    }
}

void SystemTrayIcon::about()
{
    QMessageBox::critical(0,
                          tr("About briht-tray"),
                          tr("birght-tray is a program that ease the setting brightness level with using nvclock.\n"
                                "Version : 1.0\n\n"
                                "Huseyin Kozan (posta@huseyinkozan.com.tr)"));
}
