#ifndef SYSTEMTRAYICON_H
#define SYSTEMTRAYICON_H

#include <QSystemTrayIcon>
#include "sliderbasewidget.h"

class SystemTrayIcon : public QSystemTrayIcon
{
    Q_OBJECT

private:
    SliderBaseWidget * sb;
    int currentVal;

public:
  SystemTrayIcon(QObject * parent = 0);
  bool event(QEvent * event);

public slots:
  void trayActivated(QSystemTrayIcon::ActivationReason reason);
  void updateBrightness(int val);
  void about();
};

#endif // SYSTEMTRAYICON_H
