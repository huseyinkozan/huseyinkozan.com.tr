#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# Licensed under the GNU General Public License, version 3.
# See the file http://www.gnu.org/copyleft/gpl.txt

from pisi.actionsapi import cmaketools
from pisi.actionsapi import pisitools
from pisi.actionsapi import shelltools
from pisi.actionsapi import get

def setup():
    shelltools.system("qmake-qt4")
    shelltools.system("lrelease-qt4 bright-tray.pro")

def build():
    cmaketools.make()

def install():
    cmaketools.install()
    pisitools.dobin("bright-tray")
